--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workers DROP CONSTRAINT IF EXISTS workers_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.workers DROP CONSTRAINT IF EXISTS workers_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.subscription_logs DROP CONSTRAINT IF EXISTS subscription_logs_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.provider_configs DROP CONSTRAINT IF EXISTS provider_configs_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.price_adjustments DROP CONSTRAINT IF EXISTS price_adjustments_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.price_adjustments DROP CONSTRAINT IF EXISTS price_adjustments_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_processed_by_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_customer_id_customers_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_batch_id_batches_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_assigned_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_service_id_services_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS notification_templates_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS notification_templates_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_messages DROP CONSTRAINT IF EXISTS notification_messages_template_id_notification_templates_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_messages DROP CONSTRAINT IF EXISTS notification_messages_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_messages DROP CONSTRAINT IF EXISTS notification_messages_event_id_notification_events_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_events DROP CONSTRAINT IF EXISTS notification_events_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_events DROP CONSTRAINT IF EXISTS notification_events_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_events DROP CONSTRAINT IF EXISTS notification_events_customer_id_customers_id_fk;
ALTER TABLE IF EXISTS ONLY public.notification_events DROP CONSTRAINT IF EXISTS notification_events_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.expense_categories DROP CONSTRAINT IF EXISTS expense_categories_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.expenditures DROP CONSTRAINT IF EXISTS expenditures_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_requested_by_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_customer_id_customers_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_assigned_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS conversation_participants_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS conversation_participants_conversation_id_conversations_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversation_messages DROP CONSTRAINT IF EXISTS conversation_messages_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversation_messages DROP CONSTRAINT IF EXISTS conversation_messages_conversation_id_conversations_id_fk;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_branch_id_branches_id_fk;
DROP INDEX IF EXISTS public.workers_phone_idx;
DROP INDEX IF EXISTS public.workers_laundry_id_idx;
DROP INDEX IF EXISTS public.workers_deleted_at_idx;
DROP INDEX IF EXISTS public.workers_branch_id_idx;
DROP INDEX IF EXISTS public.sub_logs_laundry_id_idx;
DROP INDEX IF EXISTS public.sub_logs_created_at_idx;
DROP INDEX IF EXISTS public.provider_configs_laundry_provider_uidx;
DROP INDEX IF EXISTS public.provider_configs_laundry_idx;
DROP INDEX IF EXISTS public.pickup_records_order_id_idx;
DROP INDEX IF EXISTS public.pickup_records_laundry_id_idx;
DROP INDEX IF EXISTS public.payment_records_recorded_at_idx;
DROP INDEX IF EXISTS public.payment_records_order_id_idx;
DROP INDEX IF EXISTS public.payment_records_laundry_id_idx;
DROP INDEX IF EXISTS public.payment_records_deleted_at_idx;
DROP INDEX IF EXISTS public.orders_status_idx;
DROP INDEX IF EXISTS public.orders_processing_due_idx;
DROP INDEX IF EXISTS public.orders_payment_status_idx;
DROP INDEX IF EXISTS public.orders_laundry_status_idx;
DROP INDEX IF EXISTS public.orders_laundry_id_idx;
DROP INDEX IF EXISTS public.orders_laundry_branch_idx;
DROP INDEX IF EXISTS public.orders_customer_id_idx;
DROP INDEX IF EXISTS public.orders_created_at_idx;
DROP INDEX IF EXISTS public.orders_branch_id_idx;
DROP INDEX IF EXISTS public.notif_templates_trigger_idx;
DROP INDEX IF EXISTS public.notif_templates_laundry_idx;
DROP INDEX IF EXISTS public.notif_templates_channel_idx;
DROP INDEX IF EXISTS public.notif_templates_active_idx;
DROP INDEX IF EXISTS public.notif_messages_template_id_idx;
DROP INDEX IF EXISTS public.notif_messages_status_idx;
DROP INDEX IF EXISTS public.notif_messages_recipient_idx;
DROP INDEX IF EXISTS public.notif_messages_queued_at_idx;
DROP INDEX IF EXISTS public.notif_messages_provider_msg_id_idx;
DROP INDEX IF EXISTS public.notif_messages_laundry_idx;
DROP INDEX IF EXISTS public.notif_messages_event_id_idx;
DROP INDEX IF EXISTS public.notif_messages_channel_idx;
DROP INDEX IF EXISTS public.notif_events_status_idx;
DROP INDEX IF EXISTS public.notif_events_order_id_idx;
DROP INDEX IF EXISTS public.notif_events_laundry_idx;
DROP INDEX IF EXISTS public.notif_events_event_type_idx;
DROP INDEX IF EXISTS public.notif_events_customer_id_idx;
DROP INDEX IF EXISTS public.notif_events_created_at_idx;
DROP INDEX IF EXISTS public.idempotency_keys_created_at_idx;
DROP INDEX IF EXISTS public.expenditures_laundry_id_idx;
DROP INDEX IF EXISTS public.expenditures_created_at_idx;
DROP INDEX IF EXISTS public.device_heartbeats_laundry_device_uniq;
DROP INDEX IF EXISTS public.customers_phone_idx;
DROP INDEX IF EXISTS public.customers_laundry_id_idx;
DROP INDEX IF EXISTS public.customers_deleted_at_idx;
DROP INDEX IF EXISTS public.customers_branch_id_idx;
DROP INDEX IF EXISTS public.conversations_status_idx;
DROP INDEX IF EXISTS public.conversations_phone_idx;
DROP INDEX IF EXISTS public.conversations_laundry_idx;
DROP INDEX IF EXISTS public.conversations_last_msg_idx;
DROP INDEX IF EXISTS public.conversations_customer_id_idx;
DROP INDEX IF EXISTS public.conversations_assigned_idx;
DROP INDEX IF EXISTS public.conv_participants_worker_idx;
DROP INDEX IF EXISTS public.conv_participants_conv_idx;
DROP INDEX IF EXISTS public.conv_messages_laundry_idx;
DROP INDEX IF EXISTS public.conv_messages_direction_idx;
DROP INDEX IF EXISTS public.conv_messages_created_at_idx;
DROP INDEX IF EXISTS public.conv_messages_conversation_idx;
DROP INDEX IF EXISTS public.audit_log_order_id_idx;
DROP INDEX IF EXISTS public.audit_log_laundry_id_idx;
DROP INDEX IF EXISTS public.audit_log_created_at_idx;
DROP INDEX IF EXISTS public.audit_log_action_idx;
DROP INDEX IF EXISTS public.alerts_status_idx;
DROP INDEX IF EXISTS public.alerts_severity_idx;
DROP INDEX IF EXISTS public.alerts_laundry_id_idx;
DROP INDEX IF EXISTS public.alerts_fingerprint_idx;
DROP INDEX IF EXISTS public.alerts_created_at_idx;
DROP INDEX IF EXISTS public.alerts_category_idx;
ALTER TABLE IF EXISTS ONLY public.workers DROP CONSTRAINT IF EXISTS workers_pkey;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_worker_id_unique;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_logs DROP CONSTRAINT IF EXISTS subscription_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_pkey;
ALTER TABLE IF EXISTS ONLY public.schema_snapshots DROP CONSTRAINT IF EXISTS schema_snapshots_pkey;
ALTER TABLE IF EXISTS ONLY public.receipt_number_counters DROP CONSTRAINT IF EXISTS receipt_number_counters_pkey;
ALTER TABLE IF EXISTS ONLY public.provider_configs DROP CONSTRAINT IF EXISTS provider_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.price_adjustments DROP CONSTRAINT IF EXISTS price_adjustments_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_admins DROP CONSTRAINT IF EXISTS platform_admins_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_admins DROP CONSTRAINT IF EXISTS platform_admins_email_unique;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_receipt_number_unique;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_order_id_unique;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS notification_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_messages DROP CONSTRAINT IF EXISTS notification_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_events DROP CONSTRAINT IF EXISTS notification_events_pkey;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.laundries DROP CONSTRAINT IF EXISTS laundries_pkey;
ALTER TABLE IF EXISTS ONLY public.laundries DROP CONSTRAINT IF EXISTS laundries_owner_email_unique;
ALTER TABLE IF EXISTS ONLY public.idempotency_keys DROP CONSTRAINT IF EXISTS idempotency_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.expense_categories DROP CONSTRAINT IF EXISTS expense_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.expenditures DROP CONSTRAINT IF EXISTS expenditures_pkey;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_pkey;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS conversation_participants_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_messages DROP CONSTRAINT IF EXISTS conversation_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_pkey;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_pkey;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_batch_code_unique;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_pkey;
ALTER TABLE IF EXISTS public.workers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.worker_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subscription_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.services ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.schema_snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.provider_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.price_adjustments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.platform_admins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pickup_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payment_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.order_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.message_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.laundries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expense_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expenditures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.discount_approvals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.device_heartbeats ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversation_participants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversation_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.branches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.batches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alerts ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.workers_id_seq;
DROP TABLE IF EXISTS public.workers;
DROP SEQUENCE IF EXISTS public.worker_permissions_id_seq;
DROP TABLE IF EXISTS public.worker_permissions;
DROP SEQUENCE IF EXISTS public.subscription_logs_id_seq;
DROP TABLE IF EXISTS public.subscription_logs;
DROP SEQUENCE IF EXISTS public.services_id_seq;
DROP TABLE IF EXISTS public.services;
DROP SEQUENCE IF EXISTS public.schema_snapshots_id_seq;
DROP TABLE IF EXISTS public.schema_snapshots;
DROP TABLE IF EXISTS public.receipt_number_counters;
DROP SEQUENCE IF EXISTS public.provider_configs_id_seq;
DROP TABLE IF EXISTS public.provider_configs;
DROP SEQUENCE IF EXISTS public.price_adjustments_id_seq;
DROP TABLE IF EXISTS public.price_adjustments;
DROP SEQUENCE IF EXISTS public.platform_admins_id_seq;
DROP TABLE IF EXISTS public.platform_admins;
DROP SEQUENCE IF EXISTS public.pickup_records_id_seq;
DROP TABLE IF EXISTS public.pickup_records;
DROP SEQUENCE IF EXISTS public.payment_records_id_seq;
DROP TABLE IF EXISTS public.payment_records;
DROP SEQUENCE IF EXISTS public.orders_id_seq;
DROP TABLE IF EXISTS public.orders;
DROP SEQUENCE IF EXISTS public.order_items_id_seq;
DROP TABLE IF EXISTS public.order_items;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notification_templates_id_seq;
DROP TABLE IF EXISTS public.notification_templates;
DROP SEQUENCE IF EXISTS public.notification_messages_id_seq;
DROP TABLE IF EXISTS public.notification_messages;
DROP SEQUENCE IF EXISTS public.notification_events_id_seq;
DROP TABLE IF EXISTS public.notification_events;
DROP SEQUENCE IF EXISTS public.message_templates_id_seq;
DROP TABLE IF EXISTS public.message_templates;
DROP SEQUENCE IF EXISTS public.laundries_id_seq;
DROP TABLE IF EXISTS public.laundries;
DROP TABLE IF EXISTS public.idempotency_keys;
DROP SEQUENCE IF EXISTS public.expense_categories_id_seq;
DROP TABLE IF EXISTS public.expense_categories;
DROP SEQUENCE IF EXISTS public.expenditures_id_seq;
DROP TABLE IF EXISTS public.expenditures;
DROP SEQUENCE IF EXISTS public.discount_approvals_id_seq;
DROP TABLE IF EXISTS public.discount_approvals;
DROP SEQUENCE IF EXISTS public.device_heartbeats_id_seq;
DROP TABLE IF EXISTS public.device_heartbeats;
DROP SEQUENCE IF EXISTS public.customers_id_seq;
DROP TABLE IF EXISTS public.customers;
DROP SEQUENCE IF EXISTS public.conversations_id_seq;
DROP TABLE IF EXISTS public.conversations;
DROP SEQUENCE IF EXISTS public.conversation_participants_id_seq;
DROP TABLE IF EXISTS public.conversation_participants;
DROP SEQUENCE IF EXISTS public.conversation_messages_id_seq;
DROP TABLE IF EXISTS public.conversation_messages;
DROP SEQUENCE IF EXISTS public.branches_id_seq;
DROP TABLE IF EXISTS public.branches;
DROP SEQUENCE IF EXISTS public.batches_id_seq;
DROP TABLE IF EXISTS public.batches;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP SEQUENCE IF EXISTS public.alerts_id_seq;
DROP TABLE IF EXISTS public.alerts;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    device_id text,
    severity text NOT NULL,
    category text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    fingerprint text,
    acknowledged_by text,
    acknowledged_at timestamp without time zone,
    resolved_by text,
    resolved_at timestamp without time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    laundry_id integer,
    actor_id integer,
    actor_type text NOT NULL,
    actor_name text NOT NULL,
    action text NOT NULL,
    order_id integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batches (
    id integer NOT NULL,
    laundry_id integer,
    batch_code text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    order_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batches_id_seq OWNED BY public.batches.id;


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    name text NOT NULL,
    address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text
);


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: conversation_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    laundry_id integer NOT NULL,
    direction text NOT NULL,
    body text NOT NULL,
    status text,
    provider_message_id text,
    sender_type text,
    sender_id integer,
    sender_name text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: conversation_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_messages_id_seq OWNED BY public.conversation_messages.id;


--
-- Name: conversation_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_participants (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    worker_id integer,
    is_active boolean DEFAULT true NOT NULL,
    joined_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: conversation_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_participants_id_seq OWNED BY public.conversation_participants.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    customer_id integer,
    channel text NOT NULL,
    customer_phone text NOT NULL,
    customer_name text,
    status text DEFAULT 'open'::text NOT NULL,
    assigned_worker_id integer,
    last_message_at timestamp without time zone,
    unread_count integer DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    full_name text NOT NULL,
    phone text NOT NULL,
    address text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: device_heartbeats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_heartbeats (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    worker_id integer,
    actor_type text DEFAULT 'worker'::text NOT NULL,
    worker_name text,
    device_id text NOT NULL,
    pending_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    conflict_count integer DEFAULT 0 NOT NULL,
    recovery_count integer DEFAULT 0 NOT NULL,
    is_online boolean DEFAULT true NOT NULL,
    app_version text,
    last_synced_at timestamp without time zone,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: device_heartbeats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_heartbeats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_heartbeats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_heartbeats_id_seq OWNED BY public.device_heartbeats.id;


--
-- Name: discount_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discount_approvals (
    id integer NOT NULL,
    laundry_id integer,
    order_id integer NOT NULL,
    requested_by integer,
    requested_by_name text NOT NULL,
    original_amount numeric(10,2) NOT NULL,
    requested_discount numeric(10,2) NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    resolved_by text,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: discount_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.discount_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: discount_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.discount_approvals_id_seq OWNED BY public.discount_approvals.id;


--
-- Name: expenditures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenditures (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    category text NOT NULL,
    amount numeric(12,2) NOT NULL,
    notes text,
    is_recurring boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expenditures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenditures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenditures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenditures_id_seq OWNED BY public.expenditures.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    key text NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    status_code integer DEFAULT 0 NOT NULL,
    response_body text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: laundries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.laundries (
    id integer NOT NULL,
    business_name text NOT NULL,
    owner_email text NOT NULL,
    password_hash text NOT NULL,
    phone text,
    is_active boolean DEFAULT true NOT NULL,
    subscription_tier text DEFAULT 'free'::text NOT NULL,
    subscription_status text DEFAULT 'trial'::text NOT NULL,
    trial_started_at timestamp without time zone,
    trial_ends_at timestamp without time zone,
    trial_duration_days integer DEFAULT 14 NOT NULL,
    converted_at timestamp without time zone,
    subscription_renews_at timestamp without time zone,
    standard_turnaround_hours integer DEFAULT 72 NOT NULL,
    express_turnaround_hours integer DEFAULT 24 NOT NULL,
    premium_turnaround_hours integer DEFAULT 48 NOT NULL,
    business_profile jsonb DEFAULT '{}'::jsonb,
    branding_settings jsonb DEFAULT '{}'::jsonb,
    operational_settings jsonb DEFAULT '{}'::jsonb,
    automation_settings jsonb DEFAULT '{}'::jsonb,
    dashboard_preferences jsonb DEFAULT '{}'::jsonb,
    discount_settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: laundries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.laundries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: laundries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.laundries_id_seq OWNED BY public.laundries.id;


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_templates (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    name text NOT NULL,
    subject text,
    body text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_templates_id_seq OWNED BY public.message_templates.id;


--
-- Name: notification_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_events (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    event_type text NOT NULL,
    order_id integer,
    customer_id integer,
    customer_phone text,
    customer_name text,
    status text DEFAULT 'pending'::text NOT NULL,
    skip_reason text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_events_id_seq OWNED BY public.notification_events.id;


--
-- Name: notification_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_messages (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    event_id integer,
    template_id integer,
    channel text NOT NULL,
    recipient_phone text NOT NULL,
    recipient_name text,
    rendered_body text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    provider_message_id text,
    retry_count integer DEFAULT 0 NOT NULL,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    queued_at timestamp without time zone DEFAULT now() NOT NULL,
    sent_at timestamp without time zone,
    delivered_at timestamp without time zone,
    read_at timestamp without time zone,
    failed_at timestamp without time zone
);


--
-- Name: notification_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_messages_id_seq OWNED BY public.notification_messages.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    event_trigger text NOT NULL,
    channel text NOT NULL,
    name text NOT NULL,
    body text NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    target_type text DEFAULT 'owner'::text NOT NULL,
    target_worker_id integer,
    event_type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    related_order_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    service_id integer,
    service_type text NOT NULL,
    name text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    quantity_picked_up integer DEFAULT 0 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    customer_id integer,
    order_id text NOT NULL,
    customer_name text NOT NULL,
    phone text NOT NULL,
    address text,
    service_type text DEFAULT 'standard'::text NOT NULL,
    shirts integer DEFAULT 0 NOT NULL,
    trousers integer DEFAULT 0 NOT NULL,
    shirts_picked_up integer DEFAULT 0 NOT NULL,
    trousers_picked_up integer DEFAULT 0 NOT NULL,
    additional_notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_status text DEFAULT 'unpaid'::text NOT NULL,
    price numeric(10,2),
    extra_charge numeric(10,2),
    discount numeric(10,2),
    amount_paid numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    verified_shirts integer,
    verified_trousers integer,
    is_verified boolean DEFAULT false NOT NULL,
    batch_id integer,
    assigned_worker_id integer,
    processing_due_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_records (
    id integer NOT NULL,
    order_id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    receipt_number text,
    amount numeric(10,2) NOT NULL,
    method text DEFAULT 'cash'::text NOT NULL,
    notes text,
    remaining_balance numeric(10,2) NOT NULL,
    recorded_by text,
    worker_id integer,
    recorded_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text,
    deletion_reason text
);


--
-- Name: payment_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_records_id_seq OWNED BY public.payment_records.id;


--
-- Name: pickup_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pickup_records (
    id integer NOT NULL,
    laundry_id integer,
    order_id integer NOT NULL,
    shirts_picked_up integer DEFAULT 0 NOT NULL,
    trousers_picked_up integer DEFAULT 0 NOT NULL,
    item_pickups json,
    notes text,
    processed_by integer,
    recorded_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: pickup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pickup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pickup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pickup_records_id_seq OWNED BY public.pickup_records.id;


--
-- Name: platform_admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_admins (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_admins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_admins_id_seq OWNED BY public.platform_admins.id;


--
-- Name: price_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_adjustments (
    id integer NOT NULL,
    order_id integer NOT NULL,
    laundry_id integer,
    type text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text NOT NULL,
    applied_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: price_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.price_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: price_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.price_adjustments_id_seq OWNED BY public.price_adjustments.id;


--
-- Name: provider_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_configs (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    provider text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    last_tested_at timestamp without time zone,
    last_test_result text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: provider_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.provider_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: provider_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.provider_configs_id_seq OWNED BY public.provider_configs.id;


--
-- Name: receipt_number_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_number_counters (
    date_part text NOT NULL,
    counter integer DEFAULT 0 NOT NULL
);


--
-- Name: schema_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_snapshots (
    id integer NOT NULL,
    snapshot_type text NOT NULL,
    triggered_by text,
    table_count integer,
    index_count integer,
    db_size_bytes bigint,
    table_list text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schema_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schema_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schema_snapshots_id_seq OWNED BY public.schema_snapshots.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    laundry_id integer,
    name text NOT NULL,
    category text NOT NULL,
    standard_price numeric(10,2) NOT NULL,
    express_price numeric(10,2),
    premium_price numeric(10,2),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: subscription_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_logs (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    from_status text,
    to_status text NOT NULL,
    from_plan text,
    to_plan text,
    reason text,
    changed_by text DEFAULT 'system'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_logs_id_seq OWNED BY public.subscription_logs.id;


--
-- Name: worker_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worker_permissions (
    id integer NOT NULL,
    worker_id integer NOT NULL,
    laundry_id integer NOT NULL,
    can_view_customers boolean DEFAULT true NOT NULL,
    can_create_customers boolean DEFAULT false NOT NULL,
    can_view_customer_balances boolean DEFAULT false NOT NULL,
    can_record_payments boolean DEFAULT false NOT NULL,
    can_record_pickups boolean DEFAULT true NOT NULL,
    can_view_orders boolean DEFAULT true NOT NULL,
    can_process_orders boolean DEFAULT true NOT NULL,
    can_assign_orders boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: worker_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.worker_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: worker_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.worker_permissions_id_seq OWNED BY public.worker_permissions.id;


--
-- Name: workers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workers (
    id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    name text NOT NULL,
    phone text,
    role text DEFAULT 'worker'::text NOT NULL,
    pin text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text
);


--
-- Name: workers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workers_id_seq OWNED BY public.workers.id;


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches ALTER COLUMN id SET DEFAULT nextval('public.batches_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: conversation_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages ALTER COLUMN id SET DEFAULT nextval('public.conversation_messages_id_seq'::regclass);


--
-- Name: conversation_participants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants ALTER COLUMN id SET DEFAULT nextval('public.conversation_participants_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: device_heartbeats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats ALTER COLUMN id SET DEFAULT nextval('public.device_heartbeats_id_seq'::regclass);


--
-- Name: discount_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals ALTER COLUMN id SET DEFAULT nextval('public.discount_approvals_id_seq'::regclass);


--
-- Name: expenditures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenditures ALTER COLUMN id SET DEFAULT nextval('public.expenditures_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: laundries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laundries ALTER COLUMN id SET DEFAULT nextval('public.laundries_id_seq'::regclass);


--
-- Name: message_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates ALTER COLUMN id SET DEFAULT nextval('public.message_templates_id_seq'::regclass);


--
-- Name: notification_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_events ALTER COLUMN id SET DEFAULT nextval('public.notification_events_id_seq'::regclass);


--
-- Name: notification_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_messages ALTER COLUMN id SET DEFAULT nextval('public.notification_messages_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payment_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records ALTER COLUMN id SET DEFAULT nextval('public.payment_records_id_seq'::regclass);


--
-- Name: pickup_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records ALTER COLUMN id SET DEFAULT nextval('public.pickup_records_id_seq'::regclass);


--
-- Name: platform_admins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_admins ALTER COLUMN id SET DEFAULT nextval('public.platform_admins_id_seq'::regclass);


--
-- Name: price_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments ALTER COLUMN id SET DEFAULT nextval('public.price_adjustments_id_seq'::regclass);


--
-- Name: provider_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_configs ALTER COLUMN id SET DEFAULT nextval('public.provider_configs_id_seq'::regclass);


--
-- Name: schema_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_snapshots ALTER COLUMN id SET DEFAULT nextval('public.schema_snapshots_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: subscription_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_logs ALTER COLUMN id SET DEFAULT nextval('public.subscription_logs_id_seq'::regclass);


--
-- Name: worker_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions ALTER COLUMN id SET DEFAULT nextval('public.worker_permissions_id_seq'::regclass);


--
-- Name: workers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers ALTER COLUMN id SET DEFAULT nextval('public.workers_id_seq'::regclass);


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, laundry_id, branch_id, device_id, severity, category, title, message, status, fingerprint, acknowledged_by, acknowledged_at, resolved_by, resolved_at, metadata, created_at) FROM stdin;
2	1	\N	\N	warning	system	Schema Checkpoint Overdue	No schema checkpoints recorded. Take a snapshot to enable safe migrations.	open	system:schema_checkpoint_overdue:1	\N	\N	\N	\N	{"thresholdDays": 7, "latestSnapshotAt": null}	2026-06-07 05:28:57.754291
3	1	\N	\N	warning	subscription	Order Limit at 85%	You've used 87 of 100 orders this month (87%). Consider upgrading soon.	open	usage:orders_85:1	\N	\N	\N	\N	{"pct": 87, "used": 87, "limit": 100}	2026-06-07 05:28:57.782742
4	1	\N	\N	critical	subscription	Worker Limit Reached	You have 20 active workers — the maximum for your plan (3). Upgrade to add more.	open	usage:workers_100:1	\N	\N	\N	\N	{"pct": 667, "used": 20, "limit": 3}	2026-06-07 05:28:57.788128
5	1	\N	\N	critical	subscription	Branch Limit Reached	You have 5 branches — the maximum for your plan (1). Upgrade to add more.	open	usage:branches_100:1	\N	\N	\N	\N	{"pct": 500, "used": 5, "limit": 1}	2026-06-07 05:28:57.799827
1	1	\N	\N	critical	backup	Backup Missing or Overdue	Last backup is 67 hours old — daily threshold (24h) exceeded.	resolved	backup:missing:1	\N	\N	system	2026-06-07 05:40:33.168	{"backupAgeHours": 66.86187305555555, "thresholdHours": 24}	2026-06-07 05:28:57.746828
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, laundry_id, actor_id, actor_type, actor_name, action, order_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batches (id, laundry_id, batch_code, status, order_count, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, laundry_id, name, address, created_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name) FROM stdin;
1	1	Lagos Island	14 Broad Street, Lagos Island	2026-06-07 05:28:34.813577	\N	\N	\N	\N
2	1	Ikeja	22 Allen Avenue, Ikeja	2026-06-07 05:28:34.813577	\N	\N	\N	\N
3	1	Victoria Island	5 Adeola Odeku Street, Victoria Island	2026-06-07 05:28:34.813577	\N	\N	\N	\N
4	1	Lekki	Plot 12, Admiralty Way, Lekki Phase 1	2026-06-07 05:28:34.813577	\N	\N	\N	\N
5	1	Surulere	88 Bode Thomas Street, Surulere	2026-06-07 05:28:34.813577	\N	\N	\N	\N
\.


--
-- Data for Name: conversation_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_messages (id, conversation_id, laundry_id, direction, body, status, provider_message_id, sender_type, sender_id, sender_name, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: conversation_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_participants (id, conversation_id, worker_id, is_active, joined_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, laundry_id, branch_id, customer_id, channel, customer_phone, customer_name, status, assigned_worker_id, last_message_at, unread_count, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, laundry_id, branch_id, full_name, phone, address, notes, created_at, last_activity_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name) FROM stdin;
1	1	1	Amaka Adeyemi	08075493651	130 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:34.892037	2026-06-07 05:28:34.892037	\N	\N	\N	\N
2	1	1	Ibrahim Alabi	08067982616	104 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.895519	2026-06-07 05:28:34.895519	\N	\N	\N	\N
3	1	1	Emeka Adeyemi	08088886674	196 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.899143	2026-06-07 05:28:34.899143	\N	\N	\N	\N
4	1	1	Emeka Abubakar	08072644757	126 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.902362	2026-06-07 05:28:34.902362	\N	\N	\N	\N
5	1	1	Kunle Usman	08059867953	151 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.905953	2026-06-07 05:28:34.905953	\N	\N	\N	\N
6	1	1	Tobi Adeyemi	08086792288	117 Market Rd, Lagos Island	\N	2026-06-07 05:28:34.909067	2026-06-07 05:28:34.909067	\N	\N	\N	\N
7	1	1	Ada Musa	08037503969	96 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.912892	2026-06-07 05:28:34.912892	\N	\N	\N	\N
8	1	1	Fatima Adeyemi	08073395153	78 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.915996	2026-06-07 05:28:34.915996	\N	\N	\N	\N
9	1	1	Chidi Danjuma	08070286285	176 Main St, Lagos Island	\N	2026-06-07 05:28:34.9195	2026-06-07 05:28:34.9195	\N	\N	\N	\N
10	1	1	Yusuf Abubakar	08094403256	183 Market Rd, Lagos Island	\N	2026-06-07 05:28:34.922065	2026-06-07 05:28:34.922065	\N	\N	\N	\N
11	1	1	Obinna Okafor	08017815381	113 Main St, Lagos Island	\N	2026-06-07 05:28:34.925011	2026-06-07 05:28:34.925011	\N	\N	\N	\N
12	1	1	Blessing Yusuf	08048555185	49 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:34.928142	2026-06-07 05:28:34.928142	\N	\N	\N	\N
13	1	1	Nneka Nwachukwu	08018585635	51 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.931928	2026-06-07 05:28:34.931928	\N	\N	\N	\N
14	1	1	Tunde Adeyemi	08023848910	186 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.936177	2026-06-07 05:28:34.936177	\N	\N	\N	\N
15	1	1	Ifeoma Alabi	08048741999	107 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.939559	2026-06-07 05:28:34.939559	\N	\N	\N	\N
16	1	1	Nkechi Okafor	08028383023	106 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.942842	2026-06-07 05:28:34.942842	\N	\N	\N	\N
17	1	1	Sule Okonkwo	08084694472	173 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.946913	2026-06-07 05:28:34.946913	\N	\N	\N	\N
18	1	1	Emeka Obi	08071569633	76 Market Rd, Lagos Island	\N	2026-06-07 05:28:34.94997	2026-06-07 05:28:34.94997	\N	\N	\N	\N
19	1	1	Amaka Nwosu	08029927239	108 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.954722	2026-06-07 05:28:34.954722	\N	\N	\N	\N
20	1	1	Chidi Babatunde	08032522120	134 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.958081	2026-06-07 05:28:34.958081	\N	\N	\N	\N
21	1	1	Nkechi Okonkwo	08097044521	83 Freedom Way, Lagos Island	\N	2026-06-07 05:28:34.961922	2026-06-07 05:28:34.961922	\N	\N	\N	\N
22	1	1	Nneka Yusuf	08034282716	155 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:34.965265	2026-06-07 05:28:34.965265	\N	\N	\N	\N
23	1	1	Tunde Babatunde	08068772425	39 Main St, Lagos Island	\N	2026-06-07 05:28:34.9684	2026-06-07 05:28:34.9684	\N	\N	\N	\N
24	1	1	Halima Bello	08061372450	167 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.971538	2026-06-07 05:28:34.971538	\N	\N	\N	\N
25	1	1	Damilola Musa	08055380232	149 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.975361	2026-06-07 05:28:34.975361	\N	\N	\N	\N
26	1	1	Ade Lawal	08086879964	133 Main St, Lagos Island	\N	2026-06-07 05:28:34.978606	2026-06-07 05:28:34.978606	\N	\N	\N	\N
27	1	1	Tunde Chukwu	08025640703	80 Market Rd, Lagos Island	\N	2026-06-07 05:28:34.9818	2026-06-07 05:28:34.9818	\N	\N	\N	\N
28	1	1	Chiamaka Eze	08095458818	33 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:34.98494	2026-06-07 05:28:34.98494	\N	\N	\N	\N
29	1	1	Nkechi Yusuf	08025745890	156 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:34.98855	2026-06-07 05:28:34.98855	\N	\N	\N	\N
30	1	1	Musa Obiora	08046404380	62 Market Rd, Lagos Island	\N	2026-06-07 05:28:34.992089	2026-06-07 05:28:34.992089	\N	\N	\N	\N
31	1	1	Chioma Nwachukwu	08042444264	34 Unity Close, Lagos Island	\N	2026-06-07 05:28:34.996939	2026-06-07 05:28:34.996939	\N	\N	\N	\N
32	1	1	Obinna Okafor	08079042007	159 Main St, Lagos Island	\N	2026-06-07 05:28:35.00033	2026-06-07 05:28:35.00033	\N	\N	\N	\N
33	1	1	Chiamaka Okonkwo	08062671217	139 Market Rd, Lagos Island	\N	2026-06-07 05:28:35.00639	2026-06-07 05:28:35.00639	\N	\N	\N	\N
34	1	1	Chioma Babatunde	08073964755	136 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:35.009732	2026-06-07 05:28:35.009732	\N	\N	\N	\N
35	1	1	Ibrahim Usman	08049086824	72 Freedom Way, Lagos Island	\N	2026-06-07 05:28:35.013063	2026-06-07 05:28:35.013063	\N	\N	\N	\N
36	1	1	Adaeze Obiora	08041964471	197 Commerce Ave, Lagos Island	\N	2026-06-07 05:28:35.016807	2026-06-07 05:28:35.016807	\N	\N	\N	\N
37	1	1	Chiamaka Okafor	08067605933	89 Main St, Lagos Island	\N	2026-06-07 05:28:35.020437	2026-06-07 05:28:35.020437	\N	\N	\N	\N
38	1	1	Halima Eze	08084775440	128 Freedom Way, Lagos Island	\N	2026-06-07 05:28:35.023541	2026-06-07 05:28:35.023541	\N	\N	\N	\N
39	1	1	Zainab Okonkwo	08011657214	24 Main St, Lagos Island	\N	2026-06-07 05:28:35.02675	2026-06-07 05:28:35.02675	\N	\N	\N	\N
40	1	1	Babajide Obiora	08049340297	6 Unity Close, Lagos Island	\N	2026-06-07 05:28:35.029622	2026-06-07 05:28:35.029622	\N	\N	\N	\N
41	1	2	Sule Alabi	08094647361	60 Unity Close, Ikeja	\N	2026-06-07 05:28:35.033556	2026-06-07 05:28:35.033556	\N	\N	\N	\N
42	1	2	Chidi Usman	08055963053	138 Freedom Way, Ikeja	\N	2026-06-07 05:28:35.037574	2026-06-07 05:28:35.037574	\N	\N	\N	\N
43	1	2	Olu Ogundele	08015800732	195 Market Rd, Ikeja	\N	2026-06-07 05:28:35.04071	2026-06-07 05:28:35.04071	\N	\N	\N	\N
44	1	2	Blessing Bello	08084652076	108 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.044322	2026-06-07 05:28:35.044322	\N	\N	\N	\N
45	1	2	Olu Ogundele	08090281268	170 Market Rd, Ikeja	\N	2026-06-07 05:28:35.050301	2026-06-07 05:28:35.050301	\N	\N	\N	\N
46	1	2	Nkechi Bello	08092319821	124 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.05417	2026-06-07 05:28:35.05417	\N	\N	\N	\N
47	1	2	Gbenga Abubakar	08094121458	155 Main St, Ikeja	\N	2026-06-07 05:28:35.058813	2026-06-07 05:28:35.058813	\N	\N	\N	\N
48	1	2	Tunde Bello	08023750820	80 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.062541	2026-06-07 05:28:35.062541	\N	\N	\N	\N
49	1	2	Olu Musa	08028020192	119 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.066658	2026-06-07 05:28:35.066658	\N	\N	\N	\N
50	1	2	Ibrahim Nwosu	08075039269	136 Market Rd, Ikeja	\N	2026-06-07 05:28:35.069823	2026-06-07 05:28:35.069823	\N	\N	\N	\N
51	1	2	Halima Musa	08011553725	160 Main St, Ikeja	\N	2026-06-07 05:28:35.073021	2026-06-07 05:28:35.073021	\N	\N	\N	\N
52	1	2	Yusuf Eze	08031855766	169 Freedom Way, Ikeja	\N	2026-06-07 05:28:35.076197	2026-06-07 05:28:35.076197	\N	\N	\N	\N
53	1	2	Musa Obi	08080235318	51 Market Rd, Ikeja	\N	2026-06-07 05:28:35.080744	2026-06-07 05:28:35.080744	\N	\N	\N	\N
54	1	2	Fatima Abubakar	08027092518	28 Market Rd, Ikeja	\N	2026-06-07 05:28:35.08495	2026-06-07 05:28:35.08495	\N	\N	\N	\N
55	1	2	Nkechi Musa	08054274568	118 Unity Close, Ikeja	\N	2026-06-07 05:28:35.088021	2026-06-07 05:28:35.088021	\N	\N	\N	\N
56	1	2	Damilola Okonkwo	08079323913	66 Market Rd, Ikeja	\N	2026-06-07 05:28:35.09129	2026-06-07 05:28:35.09129	\N	\N	\N	\N
57	1	2	Blessing Abubakar	08037354832	30 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.094486	2026-06-07 05:28:35.094486	\N	\N	\N	\N
58	1	2	Babajide Bello	08081020731	153 Market Rd, Ikeja	\N	2026-06-07 05:28:35.09782	2026-06-07 05:28:35.09782	\N	\N	\N	\N
59	1	2	Chidi Ogundele	08088400079	71 Market Rd, Ikeja	\N	2026-06-07 05:28:35.100594	2026-06-07 05:28:35.100594	\N	\N	\N	\N
60	1	2	Amaka Okonkwo	08079916348	149 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.103938	2026-06-07 05:28:35.103938	\N	\N	\N	\N
61	1	2	Sule Obiora	08043519463	44 Unity Close, Ikeja	\N	2026-06-07 05:28:35.10841	2026-06-07 05:28:35.10841	\N	\N	\N	\N
62	1	2	Gbenga Adeyemi	08061389499	187 Main St, Ikeja	\N	2026-06-07 05:28:35.111874	2026-06-07 05:28:35.111874	\N	\N	\N	\N
63	1	2	Nkechi Danjuma	08095946436	16 Main St, Ikeja	\N	2026-06-07 05:28:35.11661	2026-06-07 05:28:35.11661	\N	\N	\N	\N
64	1	2	Tobi Abubakar	08092902220	73 Main St, Ikeja	\N	2026-06-07 05:28:35.12106	2026-06-07 05:28:35.12106	\N	\N	\N	\N
65	1	2	Yusuf Alabi	08046579600	188 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.125301	2026-06-07 05:28:35.125301	\N	\N	\N	\N
66	1	2	Blessing Lawal	08025636217	46 Freedom Way, Ikeja	\N	2026-06-07 05:28:35.128443	2026-06-07 05:28:35.128443	\N	\N	\N	\N
67	1	2	Kunle Adeyemi	08015661222	55 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.131872	2026-06-07 05:28:35.131872	\N	\N	\N	\N
68	1	2	Chidi Obiora	08092428328	198 Market Rd, Ikeja	\N	2026-06-07 05:28:35.135752	2026-06-07 05:28:35.135752	\N	\N	\N	\N
69	1	2	Seun Musa	08031014683	107 Market Rd, Ikeja	\N	2026-06-07 05:28:35.140347	2026-06-07 05:28:35.140347	\N	\N	\N	\N
70	1	2	Gbenga Danjuma	08014398740	189 Unity Close, Ikeja	\N	2026-06-07 05:28:35.143822	2026-06-07 05:28:35.143822	\N	\N	\N	\N
71	1	2	Ifeoma Ogundele	08046268563	38 Freedom Way, Ikeja	\N	2026-06-07 05:28:35.147524	2026-06-07 05:28:35.147524	\N	\N	\N	\N
72	1	2	Obinna Babatunde	08030376043	112 Main St, Ikeja	\N	2026-06-07 05:28:35.150751	2026-06-07 05:28:35.150751	\N	\N	\N	\N
73	1	2	Blessing Chukwu	08084910590	51 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.154464	2026-06-07 05:28:35.154464	\N	\N	\N	\N
74	1	2	Chioma Nwosu	08068715571	62 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.158482	2026-06-07 05:28:35.158482	\N	\N	\N	\N
75	1	2	Chiamaka Eze	08097117142	150 Main St, Ikeja	\N	2026-06-07 05:28:35.161748	2026-06-07 05:28:35.161748	\N	\N	\N	\N
76	1	2	Fatima Adeyemi	08084024242	170 Market Rd, Ikeja	\N	2026-06-07 05:28:35.165393	2026-06-07 05:28:35.165393	\N	\N	\N	\N
77	1	2	Nkechi Okonkwo	08053565013	105 Main St, Ikeja	\N	2026-06-07 05:28:35.168782	2026-06-07 05:28:35.168782	\N	\N	\N	\N
78	1	2	Tobi Nwachukwu	08050293292	6 Commerce Ave, Ikeja	\N	2026-06-07 05:28:35.172609	2026-06-07 05:28:35.172609	\N	\N	\N	\N
79	1	2	Olu Alabi	08028712671	106 Market Rd, Ikeja	\N	2026-06-07 05:28:35.17606	2026-06-07 05:28:35.17606	\N	\N	\N	\N
80	1	2	Yusuf Musa	08017305332	152 Market Rd, Ikeja	\N	2026-06-07 05:28:35.180279	2026-06-07 05:28:35.180279	\N	\N	\N	\N
81	1	3	Damilola Nwosu	08054267690	61 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.184137	2026-06-07 05:28:35.184137	\N	\N	\N	\N
82	1	3	Tobi Nwosu	08029008888	165 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.187917	2026-06-07 05:28:35.187917	\N	\N	\N	\N
83	1	3	Ade Nwachukwu	08080430943	108 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.190998	2026-06-07 05:28:35.190998	\N	\N	\N	\N
84	1	3	Seun Nwosu	08045242521	125 Main St, Victoria Island	\N	2026-06-07 05:28:35.194771	2026-06-07 05:28:35.194771	\N	\N	\N	\N
85	1	3	Kunle Okonkwo	08079046258	84 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.198978	2026-06-07 05:28:35.198978	\N	\N	\N	\N
86	1	3	Yusuf Alabi	08071141375	102 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.205102	2026-06-07 05:28:35.205102	\N	\N	\N	\N
87	1	3	Olu Usman	08077341894	77 Main St, Victoria Island	\N	2026-06-07 05:28:35.208996	2026-06-07 05:28:35.208996	\N	\N	\N	\N
88	1	3	Chidi Okonkwo	08029638420	82 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.212159	2026-06-07 05:28:35.212159	\N	\N	\N	\N
89	1	3	Tunde Lawal	08066570684	124 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.21566	2026-06-07 05:28:35.21566	\N	\N	\N	\N
90	1	3	Emeka Abubakar	08084090992	128 Freedom Way, Victoria Island	\N	2026-06-07 05:28:35.219466	2026-06-07 05:28:35.219466	\N	\N	\N	\N
91	1	3	Kunle Nwachukwu	08036199277	42 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.222629	2026-06-07 05:28:35.222629	\N	\N	\N	\N
92	1	3	Zainab Isa	08061552632	25 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.225503	2026-06-07 05:28:35.225503	\N	\N	\N	\N
93	1	3	Yusuf Chukwu	08021507811	71 Freedom Way, Victoria Island	\N	2026-06-07 05:28:35.229494	2026-06-07 05:28:35.229494	\N	\N	\N	\N
94	1	3	Obinna Babatunde	08011182241	156 Freedom Way, Victoria Island	\N	2026-06-07 05:28:35.232918	2026-06-07 05:28:35.232918	\N	\N	\N	\N
95	1	3	Ade Usman	08034170688	72 Main St, Victoria Island	\N	2026-06-07 05:28:35.236192	2026-06-07 05:28:35.236192	\N	\N	\N	\N
96	1	3	Chioma Danjuma	08054336095	94 Main St, Victoria Island	\N	2026-06-07 05:28:35.239417	2026-06-07 05:28:35.239417	\N	\N	\N	\N
97	1	3	Adaeze Usman	08055732994	190 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.243031	2026-06-07 05:28:35.243031	\N	\N	\N	\N
98	1	3	Nneka Isa	08049531612	126 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.248274	2026-06-07 05:28:35.248274	\N	\N	\N	\N
99	1	3	Ada Nwosu	08049265561	108 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.251881	2026-06-07 05:28:35.251881	\N	\N	\N	\N
100	1	3	Chiamaka Babatunde	08080358858	91 Freedom Way, Victoria Island	\N	2026-06-07 05:28:35.255731	2026-06-07 05:28:35.255731	\N	\N	\N	\N
101	1	3	Gbenga Musa	08058346048	124 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.25976	2026-06-07 05:28:35.25976	\N	\N	\N	\N
102	1	3	Emeka Adeyemi	08069205726	127 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.263461	2026-06-07 05:28:35.263461	\N	\N	\N	\N
103	1	3	Babajide Obiora	08046922429	174 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.266287	2026-06-07 05:28:35.266287	\N	\N	\N	\N
104	1	3	Chioma Okafor	08096577880	86 Freedom Way, Victoria Island	\N	2026-06-07 05:28:35.268817	2026-06-07 05:28:35.268817	\N	\N	\N	\N
105	1	3	Obinna Babatunde	08068312074	77 Main St, Victoria Island	\N	2026-06-07 05:28:35.272149	2026-06-07 05:28:35.272149	\N	\N	\N	\N
106	1	3	Chiamaka Chukwu	08010534596	7 Main St, Victoria Island	\N	2026-06-07 05:28:35.274868	2026-06-07 05:28:35.274868	\N	\N	\N	\N
107	1	3	Musa Usman	08054251732	135 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.277557	2026-06-07 05:28:35.277557	\N	\N	\N	\N
108	1	3	Halima Danjuma	08013493888	105 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.280874	2026-06-07 05:28:35.280874	\N	\N	\N	\N
109	1	3	Blessing Lawal	08017990570	158 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.28398	2026-06-07 05:28:35.28398	\N	\N	\N	\N
110	1	3	Chiamaka Musa	08019769341	10 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.287499	2026-06-07 05:28:35.287499	\N	\N	\N	\N
111	1	3	Gbenga Nwachukwu	08053408656	124 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.291034	2026-06-07 05:28:35.291034	\N	\N	\N	\N
112	1	3	Obinna Okonkwo	08086425274	96 Unity Close, Victoria Island	\N	2026-06-07 05:28:35.294617	2026-06-07 05:28:35.294617	\N	\N	\N	\N
113	1	3	Amaka Danjuma	08040357645	60 Main St, Victoria Island	\N	2026-06-07 05:28:35.30199	2026-06-07 05:28:35.30199	\N	\N	\N	\N
114	1	3	Ngozi Yusuf	08048720977	106 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.306034	2026-06-07 05:28:35.306034	\N	\N	\N	\N
115	1	3	Yusuf Adeyemi	08079352598	46 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.309375	2026-06-07 05:28:35.309375	\N	\N	\N	\N
116	1	3	Ada Nwosu	08067603736	134 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.312561	2026-06-07 05:28:35.312561	\N	\N	\N	\N
117	1	3	Chiamaka Alabi	08068700195	101 Market Rd, Victoria Island	\N	2026-06-07 05:28:35.316453	2026-06-07 05:28:35.316453	\N	\N	\N	\N
118	1	3	Obinna Okafor	08080918373	37 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.319946	2026-06-07 05:28:35.319946	\N	\N	\N	\N
119	1	3	Aisha Nwosu	08012429984	30 Commerce Ave, Victoria Island	\N	2026-06-07 05:28:35.323002	2026-06-07 05:28:35.323002	\N	\N	\N	\N
120	1	3	Kunle Okonkwo	08089035865	194 Main St, Victoria Island	\N	2026-06-07 05:28:35.326412	2026-06-07 05:28:35.326412	\N	\N	\N	\N
121	1	4	Ade Obiora	08039919323	74 Market Rd, Lekki	\N	2026-06-07 05:28:35.330334	2026-06-07 05:28:35.330334	\N	\N	\N	\N
122	1	4	Nkechi Bello	08075507131	91 Main St, Lekki	\N	2026-06-07 05:28:35.333614	2026-06-07 05:28:35.333614	\N	\N	\N	\N
123	1	4	Tobi Obiora	08090767138	7 Commerce Ave, Lekki	\N	2026-06-07 05:28:35.337089	2026-06-07 05:28:35.337089	\N	\N	\N	\N
124	1	4	Adaeze Okafor	08061833781	85 Freedom Way, Lekki	\N	2026-06-07 05:28:35.340482	2026-06-07 05:28:35.340482	\N	\N	\N	\N
125	1	4	Chioma Nwachukwu	08046519602	197 Market Rd, Lekki	\N	2026-06-07 05:28:35.343885	2026-06-07 05:28:35.343885	\N	\N	\N	\N
126	1	4	Seun Yusuf	08034658823	4 Commerce Ave, Lekki	\N	2026-06-07 05:28:35.347278	2026-06-07 05:28:35.347278	\N	\N	\N	\N
127	1	4	Obinna Abubakar	08014057350	13 Commerce Ave, Lekki	\N	2026-06-07 05:28:35.350394	2026-06-07 05:28:35.350394	\N	\N	\N	\N
128	1	4	Ngozi Danjuma	08017811962	181 Freedom Way, Lekki	\N	2026-06-07 05:28:35.353465	2026-06-07 05:28:35.353465	\N	\N	\N	\N
129	1	4	Obinna Isa	08042459898	127 Freedom Way, Lekki	\N	2026-06-07 05:28:35.357636	2026-06-07 05:28:35.357636	\N	\N	\N	\N
130	1	4	Ifeoma Adeyemi	08024091314	36 Unity Close, Lekki	\N	2026-06-07 05:28:35.360772	2026-06-07 05:28:35.360772	\N	\N	\N	\N
131	1	4	Fatima Abubakar	08014900020	69 Market Rd, Lekki	\N	2026-06-07 05:28:35.364685	2026-06-07 05:28:35.364685	\N	\N	\N	\N
132	1	4	Chioma Adeyemi	08031115790	190 Unity Close, Lekki	\N	2026-06-07 05:28:35.367162	2026-06-07 05:28:35.367162	\N	\N	\N	\N
133	1	4	Chidi Ogundele	08036563927	48 Unity Close, Lekki	\N	2026-06-07 05:28:35.370378	2026-06-07 05:28:35.370378	\N	\N	\N	\N
134	1	4	Obinna Adeyemi	08097105120	132 Market Rd, Lekki	\N	2026-06-07 05:28:35.37347	2026-06-07 05:28:35.37347	\N	\N	\N	\N
135	1	4	Fatima Alabi	08096074419	34 Commerce Ave, Lekki	\N	2026-06-07 05:28:35.376608	2026-06-07 05:28:35.376608	\N	\N	\N	\N
136	1	4	Musa Obi	08030707134	29 Market Rd, Lekki	\N	2026-06-07 05:28:35.379568	2026-06-07 05:28:35.379568	\N	\N	\N	\N
137	1	4	Sule Musa	08061440233	186 Main St, Lekki	\N	2026-06-07 05:28:35.383426	2026-06-07 05:28:35.383426	\N	\N	\N	\N
138	1	4	Sule Bello	08057696941	66 Unity Close, Lekki	\N	2026-06-07 05:28:35.386981	2026-06-07 05:28:35.386981	\N	\N	\N	\N
139	1	4	Kunle Obi	08055367578	3 Main St, Lekki	\N	2026-06-07 05:28:35.390965	2026-06-07 05:28:35.390965	\N	\N	\N	\N
140	1	4	Adaeze Danjuma	08095011255	177 Commerce Ave, Lekki	\N	2026-06-07 05:28:35.394484	2026-06-07 05:28:35.394484	\N	\N	\N	\N
141	1	4	Blessing Nwosu	08082580604	35 Freedom Way, Lekki	\N	2026-06-07 05:28:35.406096	2026-06-07 05:28:35.406096	\N	\N	\N	\N
142	1	4	Blessing Obi	08034305120	85 Unity Close, Lekki	\N	2026-06-07 05:28:35.409612	2026-06-07 05:28:35.409612	\N	\N	\N	\N
143	1	4	Chioma Ogundele	08092145379	157 Unity Close, Lekki	\N	2026-06-07 05:28:35.413256	2026-06-07 05:28:35.413256	\N	\N	\N	\N
144	1	4	Adaeze Yusuf	08072273375	25 Unity Close, Lekki	\N	2026-06-07 05:28:35.415891	2026-06-07 05:28:35.415891	\N	\N	\N	\N
145	1	4	Nkechi Isa	08072052162	192 Market Rd, Lekki	\N	2026-06-07 05:28:35.419446	2026-06-07 05:28:35.419446	\N	\N	\N	\N
146	1	4	Damilola Nwachukwu	08041295494	121 Main St, Lekki	\N	2026-06-07 05:28:35.422413	2026-06-07 05:28:35.422413	\N	\N	\N	\N
147	1	4	Ada Obiora	08018524555	10 Commerce Ave, Lekki	\N	2026-06-07 05:28:35.426508	2026-06-07 05:28:35.426508	\N	\N	\N	\N
148	1	4	Yusuf Obiora	08069077275	57 Market Rd, Lekki	\N	2026-06-07 05:28:35.429291	2026-06-07 05:28:35.429291	\N	\N	\N	\N
149	1	4	Ngozi Alabi	08083898605	135 Main St, Lekki	\N	2026-06-07 05:28:35.431856	2026-06-07 05:28:35.431856	\N	\N	\N	\N
150	1	4	Ibrahim Lawal	08020290227	16 Main St, Lekki	\N	2026-06-07 05:28:35.434491	2026-06-07 05:28:35.434491	\N	\N	\N	\N
151	1	4	Obinna Danjuma	08036655329	175 Main St, Lekki	\N	2026-06-07 05:28:35.438504	2026-06-07 05:28:35.438504	\N	\N	\N	\N
152	1	4	Nkechi Ogundele	08041396289	159 Market Rd, Lekki	\N	2026-06-07 05:28:35.441694	2026-06-07 05:28:35.441694	\N	\N	\N	\N
153	1	4	Seun Obiora	08089855224	166 Market Rd, Lekki	\N	2026-06-07 05:28:35.445094	2026-06-07 05:28:35.445094	\N	\N	\N	\N
154	1	4	Aisha Isa	08064997562	164 Main St, Lekki	\N	2026-06-07 05:28:35.448298	2026-06-07 05:28:35.448298	\N	\N	\N	\N
155	1	4	Adaeze Babatunde	08026202752	103 Market Rd, Lekki	\N	2026-06-07 05:28:35.451796	2026-06-07 05:28:35.451796	\N	\N	\N	\N
156	1	4	Yusuf Abubakar	08078005912	85 Unity Close, Lekki	\N	2026-06-07 05:28:35.454826	2026-06-07 05:28:35.454826	\N	\N	\N	\N
157	1	4	Tunde Nwosu	08080658899	191 Unity Close, Lekki	\N	2026-06-07 05:28:35.457501	2026-06-07 05:28:35.457501	\N	\N	\N	\N
158	1	4	Fatima Obiora	08045416657	129 Unity Close, Lekki	\N	2026-06-07 05:28:35.460322	2026-06-07 05:28:35.460322	\N	\N	\N	\N
159	1	4	Blessing Nwosu	08017410283	151 Unity Close, Lekki	\N	2026-06-07 05:28:35.463685	2026-06-07 05:28:35.463685	\N	\N	\N	\N
160	1	4	Aisha Bello	08092491205	3 Freedom Way, Lekki	\N	2026-06-07 05:28:35.466721	2026-06-07 05:28:35.466721	\N	\N	\N	\N
161	1	5	Ibrahim Eze	08010576660	161 Unity Close, Surulere	\N	2026-06-07 05:28:35.46973	2026-06-07 05:28:35.46973	\N	\N	\N	\N
162	1	5	Adaeze Bello	08026219065	52 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.47274	2026-06-07 05:28:35.47274	\N	\N	\N	\N
163	1	5	Kunle Usman	08033482932	160 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.476917	2026-06-07 05:28:35.476917	\N	\N	\N	\N
164	1	5	Nkechi Ogundele	08056305833	61 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.479912	2026-06-07 05:28:35.479912	\N	\N	\N	\N
165	1	5	Kunle Obi	08033158761	85 Market Rd, Surulere	\N	2026-06-07 05:28:35.48289	2026-06-07 05:28:35.48289	\N	\N	\N	\N
166	1	5	Zainab Babatunde	08049614566	54 Freedom Way, Surulere	\N	2026-06-07 05:28:35.485902	2026-06-07 05:28:35.485902	\N	\N	\N	\N
167	1	5	Kunle Danjuma	08089275674	96 Unity Close, Surulere	\N	2026-06-07 05:28:35.489458	2026-06-07 05:28:35.489458	\N	\N	\N	\N
168	1	5	Yusuf Yusuf	08047630361	87 Unity Close, Surulere	\N	2026-06-07 05:28:35.492952	2026-06-07 05:28:35.492952	\N	\N	\N	\N
169	1	5	Yusuf Nwosu	08081055103	10 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.495919	2026-06-07 05:28:35.495919	\N	\N	\N	\N
170	1	5	Ade Bello	08093905925	123 Main St, Surulere	\N	2026-06-07 05:28:35.498606	2026-06-07 05:28:35.498606	\N	\N	\N	\N
171	1	5	Nneka Ogundele	08087732519	195 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.502004	2026-06-07 05:28:35.502004	\N	\N	\N	\N
172	1	5	Damilola Bello	08043980356	3 Freedom Way, Surulere	\N	2026-06-07 05:28:35.50517	2026-06-07 05:28:35.50517	\N	\N	\N	\N
173	1	5	Musa Lawal	08074336026	142 Freedom Way, Surulere	\N	2026-06-07 05:28:35.50768	2026-06-07 05:28:35.50768	\N	\N	\N	\N
174	1	5	Ngozi Ogundele	08087238328	74 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.510471	2026-06-07 05:28:35.510471	\N	\N	\N	\N
175	1	5	Amaka Chukwu	08035042054	37 Market Rd, Surulere	\N	2026-06-07 05:28:35.515313	2026-06-07 05:28:35.515313	\N	\N	\N	\N
176	1	5	Zainab Isa	08052587089	119 Unity Close, Surulere	\N	2026-06-07 05:28:35.518237	2026-06-07 05:28:35.518237	\N	\N	\N	\N
177	1	5	Nkechi Danjuma	08077427116	31 Market Rd, Surulere	\N	2026-06-07 05:28:35.520992	2026-06-07 05:28:35.520992	\N	\N	\N	\N
178	1	5	Tunde Ogundele	08044376215	108 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.523789	2026-06-07 05:28:35.523789	\N	\N	\N	\N
179	1	5	Seun Babatunde	08044178474	167 Freedom Way, Surulere	\N	2026-06-07 05:28:35.527364	2026-06-07 05:28:35.527364	\N	\N	\N	\N
180	1	5	Nkechi Lawal	08047580009	29 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.530272	2026-06-07 05:28:35.530272	\N	\N	\N	\N
181	1	5	Obinna Bello	08035799549	12 Unity Close, Surulere	\N	2026-06-07 05:28:35.533282	2026-06-07 05:28:35.533282	\N	\N	\N	\N
182	1	5	Yusuf Abubakar	08081054640	114 Unity Close, Surulere	\N	2026-06-07 05:28:35.536163	2026-06-07 05:28:35.536163	\N	\N	\N	\N
183	1	5	Seun Nwosu	08054361022	5 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.541065	2026-06-07 05:28:35.541065	\N	\N	\N	\N
184	1	5	Amaka Babatunde	08037261442	55 Freedom Way, Surulere	\N	2026-06-07 05:28:35.544286	2026-06-07 05:28:35.544286	\N	\N	\N	\N
185	1	5	Amaka Usman	08075158960	193 Market Rd, Surulere	\N	2026-06-07 05:28:35.549289	2026-06-07 05:28:35.549289	\N	\N	\N	\N
186	1	5	Babajide Nwachukwu	08036315726	24 Freedom Way, Surulere	\N	2026-06-07 05:28:35.55201	2026-06-07 05:28:35.55201	\N	\N	\N	\N
187	1	5	Kunle Chukwu	08081914480	82 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.555044	2026-06-07 05:28:35.555044	\N	\N	\N	\N
188	1	5	Ngozi Yusuf	08031288283	87 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.5576	2026-06-07 05:28:35.5576	\N	\N	\N	\N
189	1	5	Halima Okafor	08083663184	71 Market Rd, Surulere	\N	2026-06-07 05:28:35.559958	2026-06-07 05:28:35.559958	\N	\N	\N	\N
190	1	5	Chidi Okafor	08037832910	152 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.562625	2026-06-07 05:28:35.562625	\N	\N	\N	\N
191	1	5	Fatima Babatunde	08079841604	159 Unity Close, Surulere	\N	2026-06-07 05:28:35.565746	2026-06-07 05:28:35.565746	\N	\N	\N	\N
192	1	5	Obinna Yusuf	08066331422	147 Main St, Surulere	\N	2026-06-07 05:28:35.568792	2026-06-07 05:28:35.568792	\N	\N	\N	\N
193	1	5	Damilola Musa	08036658409	59 Unity Close, Surulere	\N	2026-06-07 05:28:35.571593	2026-06-07 05:28:35.571593	\N	\N	\N	\N
194	1	5	Yusuf Nwachukwu	08050231307	85 Freedom Way, Surulere	\N	2026-06-07 05:28:35.576276	2026-06-07 05:28:35.576276	\N	\N	\N	\N
195	1	5	Kunle Chukwu	08099811347	159 Main St, Surulere	\N	2026-06-07 05:28:35.579935	2026-06-07 05:28:35.579935	\N	\N	\N	\N
196	1	5	Blessing Adeyemi	08041267520	107 Main St, Surulere	\N	2026-06-07 05:28:35.582971	2026-06-07 05:28:35.582971	\N	\N	\N	\N
197	1	5	Zainab Ogundele	08087548400	139 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.58555	2026-06-07 05:28:35.58555	\N	\N	\N	\N
198	1	5	Ade Nwachukwu	08066938509	101 Freedom Way, Surulere	\N	2026-06-07 05:28:35.588544	2026-06-07 05:28:35.588544	\N	\N	\N	\N
199	1	5	Obinna Adeyemi	08065868029	122 Commerce Ave, Surulere	\N	2026-06-07 05:28:35.592322	2026-06-07 05:28:35.592322	\N	\N	\N	\N
200	1	5	Ifeoma Chukwu	08092117040	136 Freedom Way, Surulere	\N	2026-06-07 05:28:35.594794	2026-06-07 05:28:35.594794	\N	\N	\N	\N
\.


--
-- Data for Name: device_heartbeats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_heartbeats (id, laundry_id, branch_id, worker_id, actor_type, worker_name, device_id, pending_count, failed_count, conflict_count, recovery_count, is_online, app_version, last_synced_at, last_seen_at, created_at) FROM stdin;
1	1	\N	\N	owner	CleanTrack Demo Laundry	b985d3ca-167d-4067-af72-cba751c92e72	0	0	0	0	t	1.1.0	\N	2026-06-07 05:40:05.299	2026-06-07 05:36:22.824064
\.


--
-- Data for Name: discount_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_approvals (id, laundry_id, order_id, requested_by, requested_by_name, original_amount, requested_discount, reason, status, resolved_by, resolved_at, created_at) FROM stdin;
1	1	7	2	Musa Nwosu	12600.00	1724.00	Worker error claim	rejected	Owner	2026-03-18 09:28:35.638	2026-03-18 05:28:35.638
2	1	13	1	Babajide Danjuma	11400.00	837.00	Item delay compensation	approved	Owner	2026-03-16 12:28:35.682	2026-03-16 05:28:35.682
3	1	22	3	Ifeoma Nwachukwu	10000.00	3297.00	Customer demanded large discount	rejected	Owner	2026-06-02 00:28:35.755	2026-06-01 05:28:35.755
4	1	23	1	Babajide Danjuma	3600.00	1335.00	Customer demanded large discount	rejected	Owner	2026-04-15 16:28:35.764	2026-04-15 05:28:35.764
5	1	52	2	Musa Nwosu	7200.00	623.00	Bulk order discount	pending	\N	\N	2026-05-16 05:28:35.97
6	1	62	4	Gbenga Nwosu	5100.00	1179.00	Disputed pricing	rejected	Owner	2026-04-17 10:28:36.041	2026-04-17 05:28:36.041
7	1	67	4	Gbenga Nwosu	15500.00	529.00	Item delay compensation	approved	Owner	2026-04-02 19:28:36.074	2026-04-02 05:28:36.074
8	1	69	3	Ifeoma Nwachukwu	17500.00	1518.00	Major complaint	pending	\N	\N	2026-05-31 05:28:36.095
9	1	89	1	Babajide Danjuma	13000.00	1081.00	Major complaint	pending	\N	\N	2026-03-27 05:28:36.233
10	1	100	4	Gbenga Nwosu	5200.00	966.00	VIP customer	pending	\N	\N	2026-04-26 05:28:36.311
11	1	104	4	Gbenga Nwosu	7800.00	1242.00	Management approval	approved	Owner	2026-04-12 01:28:36.343	2026-04-11 05:28:36.343
12	1	108	1	Babajide Danjuma	7200.00	1851.00	VIP customer	pending	\N	\N	2026-05-09 05:28:36.383
13	1	111	2	Musa Nwosu	11000.00	1179.00	VIP customer	pending	\N	\N	2026-03-18 05:28:36.408
14	1	120	1	Babajide Danjuma	14100.00	1972.00	VIP customer	pending	\N	\N	2026-05-05 05:28:36.469
15	1	126	2	Musa Nwosu	12500.00	658.00	Item delay compensation	approved	Owner	2026-03-30 14:28:36.505	2026-03-30 05:28:36.505
16	1	150	2	Musa Nwosu	7000.00	884.00	VIP customer	pending	\N	\N	2026-04-04 05:28:36.685
17	1	182	2	Musa Nwosu	9300.00	1449.00	Management approval	approved	Owner	2026-04-10 19:28:36.902	2026-04-10 05:28:36.902
18	1	184	1	Babajide Danjuma	15900.00	1641.00	Customer demanded large discount	rejected	Owner	2026-05-15 19:28:36.924	2026-05-15 05:28:36.924
19	1	191	2	Musa Nwosu	1200.00	580.00	Bulk order discount	pending	\N	\N	2026-05-30 05:28:36.977
20	1	194	1	Babajide Danjuma	13200.00	653.00	Management approval	approved	Owner	2026-05-30 03:28:36.998	2026-05-29 05:28:36.998
21	1	195	2	Musa Nwosu	7500.00	1149.00	VIP customer	pending	\N	\N	2026-03-16 05:28:37.013
22	1	208	5	Ibrahim Bello	16500.00	1955.00	Major complaint	pending	\N	\N	2026-04-01 05:28:37.169
23	1	214	5	Ibrahim Bello	7200.00	1539.00	Worker error claim	rejected	Owner	2026-04-03 01:28:37.22	2026-04-02 05:28:37.22
24	1	218	8	Ifeoma Musa	14400.00	1416.00	Damaged item compensation	pending	\N	\N	2026-04-02 05:28:37.254
25	1	223	8	Ifeoma Musa	6200.00	1502.00	Major complaint	pending	\N	\N	2026-04-19 05:28:37.294
26	1	226	7	Ibrahim Nwosu	12500.00	1331.00	Management approval	approved	Owner	2026-03-29 07:28:37.312	2026-03-29 05:28:37.312
27	1	228	5	Ibrahim Bello	7200.00	1032.00	Major complaint	pending	\N	\N	2026-06-01 05:28:37.331
28	1	230	6	Amaka Eze	11700.00	1043.00	VIP customer	pending	\N	\N	2026-05-03 05:28:37.348
29	1	236	6	Amaka Eze	8400.00	686.00	Item delay compensation	approved	Owner	2026-03-16 00:28:37.394	2026-03-15 05:28:37.394
30	1	247	6	Amaka Eze	10600.00	972.00	Customer escalation resolved	approved	Owner	2026-03-31 21:28:37.471	2026-03-31 05:28:37.471
31	1	249	6	Amaka Eze	10500.00	620.00	Item delay compensation	approved	Owner	2026-05-05 23:28:37.489	2026-05-05 05:28:37.489
32	1	254	6	Amaka Eze	13000.00	1047.00	Customer escalation resolved	approved	Owner	2026-04-12 10:28:37.544	2026-04-12 05:28:37.544
33	1	260	8	Ifeoma Musa	9400.00	3970.00	Customer demanded large discount	rejected	Owner	2026-03-28 18:28:37.591	2026-03-28 05:28:37.591
34	1	272	5	Ibrahim Bello	8600.00	944.00	Management approval	approved	Owner	2026-05-24 22:28:37.665	2026-05-24 05:28:37.665
35	1	274	5	Ibrahim Bello	6400.00	708.00	Major complaint	pending	\N	\N	2026-06-03 05:28:37.683
36	1	276	7	Ibrahim Nwosu	8200.00	3991.00	Disputed pricing	rejected	Owner	2026-05-15 22:28:37.7	2026-05-15 05:28:37.7
37	1	278	7	Ibrahim Nwosu	9000.00	1395.00	VIP customer	pending	\N	\N	2026-04-24 05:28:37.717
38	1	282	6	Amaka Eze	12000.00	956.00	Major complaint	pending	\N	\N	2026-06-03 05:28:37.742
39	1	296	5	Ibrahim Bello	6400.00	530.00	Customer escalation resolved	approved	Owner	2026-04-10 16:28:37.831	2026-04-10 05:28:37.831
40	1	318	6	Amaka Eze	7000.00	733.00	Major complaint	pending	\N	\N	2026-05-06 05:28:37.993
41	1	320	5	Ibrahim Bello	5100.00	1777.00	VIP customer	pending	\N	\N	2026-03-14 05:28:38.008
42	1	326	7	Ibrahim Nwosu	8600.00	768.00	Management approval	approved	Owner	2026-04-28 22:28:38.054	2026-04-28 05:28:38.054
43	1	328	5	Ibrahim Bello	7200.00	983.00	Customer escalation resolved	approved	Owner	2026-06-06 18:28:38.077	2026-06-06 05:28:38.077
44	1	330	5	Ibrahim Bello	800.00	996.00	Major complaint	pending	\N	\N	2026-06-06 05:28:38.102
45	1	332	7	Ibrahim Nwosu	12000.00	1724.00	Worker error claim	rejected	Owner	2026-04-29 02:28:38.118	2026-04-28 05:28:38.118
46	1	343	5	Ibrahim Bello	11100.00	726.00	Item delay compensation	approved	Owner	2026-04-08 01:28:38.203	2026-04-07 05:28:38.203
47	1	345	8	Ifeoma Musa	9900.00	884.00	Item delay compensation	approved	Owner	2026-03-19 01:28:38.222	2026-03-18 05:28:38.222
48	1	361	6	Amaka Eze	18000.00	2079.00	Worker error claim	rejected	Owner	2026-04-13 22:28:38.311	2026-04-13 05:28:38.311
49	1	363	7	Ibrahim Nwosu	9600.00	701.00	VIP customer	pending	\N	\N	2026-04-21 05:28:38.326
50	1	365	7	Ibrahim Nwosu	4500.00	993.00	Damaged item compensation	pending	\N	\N	2026-05-09 05:28:38.343
51	1	366	5	Ibrahim Bello	13000.00	1966.00	Damaged item compensation	pending	\N	\N	2026-04-17 05:28:38.352
52	1	371	8	Ifeoma Musa	8500.00	753.00	Management approval	approved	Owner	2026-04-04 18:28:38.396	2026-04-04 05:28:38.396
53	1	381	8	Ifeoma Musa	15900.00	1078.00	Customer escalation resolved	approved	Owner	2026-04-15 09:28:38.468	2026-04-15 05:28:38.468
54	1	384	6	Amaka Eze	14700.00	992.00	Item delay compensation	approved	Owner	2026-04-19 21:28:38.497	2026-04-19 05:28:38.497
55	1	413	12	Ngozi Eze	3900.00	1071.00	Customer escalation resolved	approved	Owner	2026-04-23 03:28:38.77	2026-04-22 05:28:38.77
56	1	415	12	Ngozi Eze	18500.00	804.00	Customer escalation resolved	approved	Owner	2026-04-02 17:28:38.792	2026-04-02 05:28:38.792
57	1	422	11	Babajide Bello	16000.00	1857.00	Major complaint	pending	\N	\N	2026-04-13 05:28:38.855
58	1	429	10	Halima Abubakar	16000.00	881.00	Damaged item compensation	pending	\N	\N	2026-04-06 05:28:38.908
59	1	434	9	Zainab Lawal	14500.00	764.00	Item delay compensation	approved	Owner	2026-05-09 11:28:38.934	2026-05-09 05:28:38.934
60	1	436	12	Ngozi Eze	3800.00	537.00	Major complaint	pending	\N	\N	2026-05-30 05:28:38.957
61	1	452	10	Halima Abubakar	13500.00	845.00	Management approval	approved	Owner	2026-05-08 02:28:39.061	2026-05-07 05:28:39.061
62	1	453	10	Halima Abubakar	16500.00	894.00	VIP customer	pending	\N	\N	2026-04-01 05:28:39.077
63	1	455	12	Ngozi Eze	1200.00	2765.00	Disputed pricing	rejected	Owner	2026-05-28 03:28:39.095	2026-05-27 05:28:39.095
64	1	458	12	Ngozi Eze	6600.00	1977.00	Bulk order discount	pending	\N	\N	2026-03-20 05:28:39.112
65	1	477	10	Halima Abubakar	3200.00	873.00	Bulk order discount	pending	\N	\N	2026-06-04 05:28:39.227
66	1	482	11	Babajide Bello	15900.00	541.00	Management approval	approved	Owner	2026-05-12 06:28:39.256	2026-05-12 05:28:39.256
67	1	501	9	Zainab Lawal	18500.00	727.00	Bulk order discount	pending	\N	\N	2026-04-16 05:28:39.38
68	1	503	10	Halima Abubakar	6200.00	919.00	Item delay compensation	approved	Owner	2026-03-17 14:28:39.396	2026-03-17 05:28:39.396
69	1	504	9	Zainab Lawal	8000.00	1704.00	Damaged item compensation	pending	\N	\N	2026-05-22 05:28:39.411
70	1	506	9	Zainab Lawal	16500.00	3514.00	Disputed pricing	rejected	Owner	2026-04-25 12:28:39.427	2026-04-25 05:28:39.427
71	1	512	11	Babajide Bello	15900.00	597.00	Item delay compensation	approved	Owner	2026-05-13 20:28:39.463	2026-05-13 05:28:39.463
72	1	513	9	Zainab Lawal	11400.00	1486.00	Item delay compensation	approved	Owner	2026-06-04 08:28:39.475	2026-06-04 05:28:39.475
73	1	518	12	Ngozi Eze	1600.00	1014.00	Bulk order discount	pending	\N	\N	2026-04-28 05:28:39.518
74	1	522	10	Halima Abubakar	9000.00	1979.00	VIP customer	pending	\N	\N	2026-05-05 05:28:39.543
75	1	537	10	Halima Abubakar	12000.00	1051.00	Bulk order discount	pending	\N	\N	2026-03-10 05:28:39.628
76	1	542	11	Babajide Bello	14500.00	1203.00	Item delay compensation	approved	Owner	2026-05-20 05:28:39.665	2026-05-19 05:28:39.665
77	1	544	11	Babajide Bello	9600.00	1562.00	Bulk order discount	pending	\N	\N	2026-05-01 05:28:39.685
78	1	561	12	Ngozi Eze	3200.00	1054.00	Management approval	approved	Owner	2026-04-26 04:28:39.783	2026-04-25 05:28:39.783
79	1	576	9	Zainab Lawal	12600.00	820.00	Item delay compensation	approved	Owner	2026-04-22 13:28:39.879	2026-04-22 05:28:39.879
80	1	585	10	Halima Abubakar	14100.00	1853.00	Bulk order discount	pending	\N	\N	2026-05-02 05:28:39.934
81	1	587	10	Halima Abubakar	4800.00	1440.00	Item delay compensation	approved	Owner	2026-04-14 23:28:39.952	2026-04-14 05:28:39.952
82	1	594	11	Babajide Bello	6600.00	1961.00	Bulk order discount	pending	\N	\N	2026-04-22 05:28:40.018
83	1	612	14	Adaeze Babatunde	4600.00	1547.00	Bulk order discount	pending	\N	\N	2026-05-15 05:28:40.204
84	1	616	16	Gbenga Bello	3400.00	1317.00	Management approval	approved	Owner	2026-06-05 19:28:40.236	2026-06-05 05:28:40.236
85	1	618	13	Olu Okonkwo	13500.00	922.00	Customer escalation resolved	approved	Owner	2026-04-21 13:28:40.257	2026-04-21 05:28:40.257
86	1	620	15	Tobi Okafor	8500.00	1109.00	Customer escalation resolved	approved	Owner	2026-04-29 05:28:40.277	2026-04-28 05:28:40.277
87	1	634	14	Adaeze Babatunde	11400.00	1857.00	Bulk order discount	pending	\N	\N	2026-04-07 05:28:40.367
88	1	643	16	Gbenga Bello	4200.00	2005.00	Disputed pricing	rejected	Owner	2026-04-12 06:28:40.43	2026-04-12 05:28:40.43
89	1	651	15	Tobi Okafor	14400.00	1266.00	Damaged item compensation	pending	\N	\N	2026-03-13 05:28:40.499
90	1	654	15	Tobi Okafor	1800.00	901.00	Major complaint	pending	\N	\N	2026-05-29 05:28:40.528
91	1	669	13	Olu Okonkwo	9500.00	1212.00	Customer demanded large discount	rejected	Owner	2026-04-14 07:28:40.633	2026-04-14 05:28:40.633
92	1	698	14	Adaeze Babatunde	12900.00	2401.00	Disputed pricing	rejected	Owner	2026-03-31 19:28:40.839	2026-03-31 05:28:40.839
93	1	704	13	Olu Okonkwo	12500.00	1176.00	VIP customer	pending	\N	\N	2026-06-02 05:28:40.89
94	1	707	14	Adaeze Babatunde	15600.00	570.00	Damaged item compensation	pending	\N	\N	2026-04-29 05:28:40.915
95	1	708	13	Olu Okonkwo	5800.00	1258.00	Major complaint	pending	\N	\N	2026-03-20 05:28:40.925
96	1	724	15	Tobi Okafor	7400.00	1471.00	Customer escalation resolved	approved	Owner	2026-03-14 03:28:41.03	2026-03-13 05:28:41.03
97	1	728	15	Tobi Okafor	4800.00	2582.00	Customer demanded large discount	rejected	Owner	2026-03-11 18:28:41.066	2026-03-11 05:28:41.066
98	1	733	14	Adaeze Babatunde	6000.00	1221.00	Management approval	approved	Owner	2026-06-07 18:28:41.104	2026-06-07 05:28:41.104
99	1	734	16	Gbenga Bello	15600.00	676.00	Customer escalation resolved	approved	Owner	2026-03-10 19:28:41.117	2026-03-10 05:28:41.117
100	1	744	15	Tobi Okafor	1500.00	1048.00	Item delay compensation	approved	Owner	2026-05-20 09:28:41.2	2026-05-20 05:28:41.2
101	1	745	13	Olu Okonkwo	17000.00	2091.00	Worker error claim	rejected	Owner	2026-06-08 02:28:41.212	2026-06-07 05:28:41.212
102	1	750	16	Gbenga Bello	10500.00	1791.00	Major complaint	pending	\N	\N	2026-04-27 05:28:41.247
103	1	752	15	Tobi Okafor	5100.00	623.00	Customer escalation resolved	approved	Owner	2026-06-05 09:28:41.262	2026-06-05 05:28:41.262
104	1	756	13	Olu Okonkwo	9400.00	1213.00	VIP customer	pending	\N	\N	2026-04-06 05:28:41.297
105	1	764	16	Gbenga Bello	9300.00	1535.00	Worker error claim	rejected	Owner	2026-04-27 15:28:41.345	2026-04-27 05:28:41.345
106	1	766	15	Tobi Okafor	1200.00	1689.00	Major complaint	pending	\N	\N	2026-03-24 05:28:41.359
107	1	783	16	Gbenga Bello	12000.00	1172.00	Damaged item compensation	pending	\N	\N	2026-05-13 05:28:41.464
108	1	785	14	Adaeze Babatunde	8600.00	3604.00	Customer demanded large discount	rejected	Owner	2026-04-23 23:28:41.476	2026-04-23 05:28:41.476
109	1	792	14	Adaeze Babatunde	20000.00	1145.00	VIP customer	pending	\N	\N	2026-03-30 05:28:41.525
110	1	793	14	Adaeze Babatunde	5000.00	720.00	Customer escalation resolved	approved	Owner	2026-05-11 02:28:41.532	2026-05-10 05:28:41.532
111	1	810	18	Sule Adeyemi	8100.00	1278.00	Customer escalation resolved	approved	Owner	2026-05-07 22:28:41.708	2026-05-07 05:28:41.708
112	1	815	18	Sule Adeyemi	8400.00	543.00	Customer escalation resolved	approved	Owner	2026-04-30 22:28:41.742	2026-04-30 05:28:41.742
113	1	816	20	Sule Nwachukwu	4800.00	1259.00	Damaged item compensation	pending	\N	\N	2026-04-21 05:28:41.757
114	1	843	17	Sule Danjuma	9000.00	1394.00	Management approval	approved	Owner	2026-05-01 11:28:41.949	2026-05-01 05:28:41.949
115	1	848	17	Sule Danjuma	12900.00	939.00	Customer escalation resolved	approved	Owner	2026-03-18 16:28:41.988	2026-03-18 05:28:41.988
116	1	856	19	Yusuf Alabi	13500.00	523.00	Management approval	approved	Owner	2026-06-03 23:28:42.055	2026-06-03 05:28:42.055
117	1	859	17	Sule Danjuma	12500.00	525.00	Bulk order discount	pending	\N	\N	2026-04-12 05:28:42.083
118	1	872	18	Sule Adeyemi	9600.00	1408.00	VIP customer	pending	\N	\N	2026-04-13 05:28:42.173
119	1	876	17	Sule Danjuma	4400.00	1268.00	Item delay compensation	approved	Owner	2026-04-28 22:28:42.196	2026-04-28 05:28:42.196
120	1	877	20	Sule Nwachukwu	1800.00	604.00	Major complaint	pending	\N	\N	2026-05-10 05:28:42.21
121	1	891	17	Sule Danjuma	7500.00	1722.00	Bulk order discount	pending	\N	\N	2026-03-31 05:28:42.305
122	1	905	20	Sule Nwachukwu	9600.00	1301.00	VIP customer	pending	\N	\N	2026-05-26 05:28:42.399
123	1	910	18	Sule Adeyemi	14500.00	1599.00	Damaged item compensation	pending	\N	\N	2026-04-14 05:28:42.429
124	1	918	20	Sule Nwachukwu	9300.00	1720.00	Bulk order discount	pending	\N	\N	2026-03-31 05:28:42.619
125	1	926	17	Sule Danjuma	3000.00	1649.00	Bulk order discount	pending	\N	\N	2026-04-06 05:28:42.707
126	1	929	17	Sule Danjuma	2600.00	1732.00	VIP customer	pending	\N	\N	2026-04-23 05:28:42.729
127	1	930	17	Sule Danjuma	4200.00	1553.00	Major complaint	pending	\N	\N	2026-05-05 05:28:42.738
128	1	931	18	Sule Adeyemi	15600.00	1860.00	Damaged item compensation	pending	\N	\N	2026-04-19 05:28:42.746
129	1	934	18	Sule Adeyemi	7600.00	783.00	Customer escalation resolved	approved	Owner	2026-05-18 09:28:42.761	2026-05-18 05:28:42.761
130	1	935	17	Sule Danjuma	8400.00	1292.00	Bulk order discount	pending	\N	\N	2026-03-12 05:28:42.773
131	1	937	17	Sule Danjuma	5800.00	771.00	Bulk order discount	pending	\N	\N	2026-05-17 05:28:42.784
132	1	943	18	Sule Adeyemi	11000.00	1113.00	Damaged item compensation	pending	\N	\N	2026-03-25 05:28:42.818
133	1	948	18	Sule Adeyemi	7400.00	1675.00	Bulk order discount	pending	\N	\N	2026-05-01 05:28:42.845
\.


--
-- Data for Name: expenditures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenditures (id, laundry_id, category, amount, notes, is_recurring, created_at, updated_at) FROM stdin;
1	1	electricity	18268.00	Lagos Island — electricity expense	t	2026-05-10 05:28:37.052	2026-06-07 05:28:37.053569
2	1	detergent	35939.00	Lagos Island — detergent expense	f	2026-06-05 05:28:37.056	2026-06-07 05:28:37.057087
3	1	water	63477.00	Lagos Island — water expense	t	2026-05-14 05:28:37.059	2026-06-07 05:28:37.060027
4	1	salaries	19937.00	Lagos Island — salaries expense	t	2026-05-11 05:28:37.062	2026-06-07 05:28:37.062961
5	1	transport	33319.00	Lagos Island — transport expense	f	2026-05-24 05:28:37.065	2026-06-07 05:28:37.066038
6	1	maintenance	49758.00	Lagos Island — maintenance expense	f	2026-06-03 05:28:37.068	2026-06-07 05:28:37.068907
7	1	packaging	20228.00	Lagos Island — packaging expense	f	2026-05-25 05:28:37.071	2026-06-07 05:28:37.071563
8	1	miscellaneous	77629.00	Lagos Island — miscellaneous expense	f	2026-06-01 05:28:37.073	2026-06-07 05:28:37.074358
9	1	electricity	18543.00	Lagos Island — electricity expense	t	2026-05-06 05:28:37.076	2026-06-07 05:28:37.076814
10	1	detergent	76738.00	Lagos Island — detergent expense	f	2026-05-01 05:28:37.079	2026-06-07 05:28:37.079666
11	1	water	26467.00	Lagos Island — water expense	t	2026-04-14 05:28:37.082	2026-06-07 05:28:37.082692
12	1	salaries	41761.00	Lagos Island — salaries expense	t	2026-04-18 05:28:37.085	2026-06-07 05:28:37.085478
13	1	transport	14431.00	Lagos Island — transport expense	f	2026-04-23 05:28:37.088	2026-06-07 05:28:37.088505
14	1	maintenance	60543.00	Lagos Island — maintenance expense	f	2026-04-15 05:28:37.09	2026-06-07 05:28:37.090848
15	1	packaging	30486.00	Lagos Island — packaging expense	f	2026-05-07 05:28:37.093	2026-06-07 05:28:37.093882
16	1	miscellaneous	10428.00	Lagos Island — miscellaneous expense	f	2026-04-15 05:28:37.096	2026-06-07 05:28:37.096584
17	1	electricity	59092.00	Lagos Island — electricity expense	t	2026-03-17 05:28:37.098	2026-06-07 05:28:37.099189
18	1	detergent	11438.00	Lagos Island — detergent expense	f	2026-03-25 05:28:37.101	2026-06-07 05:28:37.101828
19	1	water	55532.00	Lagos Island — water expense	t	2026-04-04 05:28:37.103	2026-06-07 05:28:37.105456
20	1	salaries	37731.00	Lagos Island — salaries expense	t	2026-04-05 05:28:37.107	2026-06-07 05:28:37.108462
21	1	transport	20972.00	Lagos Island — transport expense	f	2026-03-29 05:28:37.11	2026-06-07 05:28:37.111272
22	1	maintenance	78024.00	Lagos Island — maintenance expense	f	2026-03-31 05:28:37.113	2026-06-07 05:28:37.114008
23	1	packaging	15131.00	Lagos Island — packaging expense	f	2026-04-02 05:28:37.116	2026-06-07 05:28:37.116701
24	1	miscellaneous	23565.00	Lagos Island — miscellaneous expense	f	2026-03-23 05:28:37.118	2026-06-07 05:28:37.11938
25	1	electricity	6321.00	Ikeja — electricity expense	t	2026-05-28 05:28:38.616	2026-06-07 05:28:38.6168
26	1	detergent	29756.00	Ikeja — detergent expense	f	2026-05-13 05:28:38.618	2026-06-07 05:28:38.61951
27	1	water	75107.00	Ikeja — water expense	t	2026-06-06 05:28:38.621	2026-06-07 05:28:38.622189
28	1	salaries	45131.00	Ikeja — salaries expense	t	2026-05-20 05:28:38.624	2026-06-07 05:28:38.624933
29	1	transport	20641.00	Ikeja — transport expense	f	2026-05-20 05:28:38.627	2026-06-07 05:28:38.627737
30	1	maintenance	17539.00	Ikeja — maintenance expense	f	2026-06-07 05:28:38.63	2026-06-07 05:28:38.63057
31	1	packaging	72353.00	Ikeja — packaging expense	f	2026-06-03 05:28:38.632	2026-06-07 05:28:38.633487
32	1	miscellaneous	43362.00	Ikeja — miscellaneous expense	f	2026-05-23 05:28:38.636	2026-06-07 05:28:38.636515
33	1	electricity	32294.00	Ikeja — electricity expense	t	2026-05-07 05:28:38.638	2026-06-07 05:28:38.639325
34	1	detergent	54327.00	Ikeja — detergent expense	f	2026-05-05 05:28:38.641	2026-06-07 05:28:38.642154
35	1	water	55032.00	Ikeja — water expense	t	2026-05-06 05:28:38.644	2026-06-07 05:28:38.644878
36	1	salaries	62086.00	Ikeja — salaries expense	t	2026-05-08 05:28:38.647	2026-06-07 05:28:38.64789
37	1	transport	5036.00	Ikeja — transport expense	f	2026-04-30 05:28:38.65	2026-06-07 05:28:38.651184
38	1	maintenance	69672.00	Ikeja — maintenance expense	f	2026-05-06 05:28:38.653	2026-06-07 05:28:38.654045
39	1	packaging	40947.00	Ikeja — packaging expense	f	2026-04-11 05:28:38.657	2026-06-07 05:28:38.657673
40	1	miscellaneous	14925.00	Ikeja — miscellaneous expense	f	2026-05-02 05:28:38.66	2026-06-07 05:28:38.660776
41	1	electricity	9077.00	Ikeja — electricity expense	t	2026-03-12 05:28:38.663	2026-06-07 05:28:38.663611
42	1	detergent	27465.00	Ikeja — detergent expense	f	2026-03-12 05:28:38.665	2026-06-07 05:28:38.666272
43	1	water	70505.00	Ikeja — water expense	t	2026-04-07 05:28:38.668	2026-06-07 05:28:38.66915
44	1	salaries	34307.00	Ikeja — salaries expense	t	2026-03-13 05:28:38.671	2026-06-07 05:28:38.672186
45	1	transport	69652.00	Ikeja — transport expense	f	2026-03-12 05:28:38.674	2026-06-07 05:28:38.675017
46	1	maintenance	61103.00	Ikeja — maintenance expense	f	2026-03-27 05:28:38.677	2026-06-07 05:28:38.677972
47	1	packaging	64361.00	Ikeja — packaging expense	f	2026-03-11 05:28:38.68	2026-06-07 05:28:38.680893
48	1	miscellaneous	51347.00	Ikeja — miscellaneous expense	f	2026-03-10 05:28:38.683	2026-06-07 05:28:38.684362
49	1	electricity	46642.00	Victoria Island — electricity expense	t	2026-05-29 05:28:40.063	2026-06-07 05:28:40.06391
50	1	detergent	10993.00	Victoria Island — detergent expense	f	2026-05-18 05:28:40.067	2026-06-07 05:28:40.068432
51	1	water	55409.00	Victoria Island — water expense	t	2026-05-16 05:28:40.071	2026-06-07 05:28:40.072379
52	1	salaries	38269.00	Victoria Island — salaries expense	t	2026-05-17 05:28:40.075	2026-06-07 05:28:40.075627
53	1	transport	60272.00	Victoria Island — transport expense	f	2026-05-26 05:28:40.078	2026-06-07 05:28:40.078824
54	1	maintenance	66449.00	Victoria Island — maintenance expense	f	2026-05-13 05:28:40.081	2026-06-07 05:28:40.081524
55	1	packaging	11036.00	Victoria Island — packaging expense	f	2026-05-21 05:28:40.084	2026-06-07 05:28:40.084906
56	1	miscellaneous	32388.00	Victoria Island — miscellaneous expense	f	2026-05-11 05:28:40.087	2026-06-07 05:28:40.087977
57	1	electricity	7633.00	Victoria Island — electricity expense	t	2026-04-09 05:28:40.091	2026-06-07 05:28:40.091809
58	1	detergent	14676.00	Victoria Island — detergent expense	f	2026-04-28 05:28:40.094	2026-06-07 05:28:40.094975
59	1	water	61372.00	Victoria Island — water expense	t	2026-04-09 05:28:40.097	2026-06-07 05:28:40.097696
60	1	salaries	22744.00	Victoria Island — salaries expense	t	2026-04-15 05:28:40.1	2026-06-07 05:28:40.100599
61	1	transport	42538.00	Victoria Island — transport expense	f	2026-05-08 05:28:40.102	2026-06-07 05:28:40.103488
62	1	maintenance	7745.00	Victoria Island — maintenance expense	f	2026-04-21 05:28:40.105	2026-06-07 05:28:40.106332
63	1	packaging	66307.00	Victoria Island — packaging expense	f	2026-05-06 05:28:40.108	2026-06-07 05:28:40.109177
64	1	miscellaneous	69214.00	Victoria Island — miscellaneous expense	f	2026-04-30 05:28:40.111	2026-06-07 05:28:40.111942
65	1	electricity	20988.00	Victoria Island — electricity expense	t	2026-03-19 05:28:40.114	2026-06-07 05:28:40.114901
66	1	detergent	62818.00	Victoria Island — detergent expense	f	2026-03-19 05:28:40.117	2026-06-07 05:28:40.1178
67	1	water	45527.00	Victoria Island — water expense	t	2026-04-02 05:28:40.12	2026-06-07 05:28:40.120681
68	1	salaries	77385.00	Victoria Island — salaries expense	t	2026-03-21 05:28:40.122	2026-06-07 05:28:40.123488
69	1	transport	29629.00	Victoria Island — transport expense	f	2026-03-14 05:28:40.125	2026-06-07 05:28:40.126446
70	1	maintenance	44349.00	Victoria Island — maintenance expense	f	2026-04-08 05:28:40.128	2026-06-07 05:28:40.128882
71	1	packaging	57107.00	Victoria Island — packaging expense	f	2026-03-30 05:28:40.131	2026-06-07 05:28:40.131616
72	1	miscellaneous	10769.00	Victoria Island — miscellaneous expense	f	2026-03-27 05:28:40.134	2026-06-07 05:28:40.134704
73	1	electricity	14889.00	Lekki — electricity expense	t	2026-05-16 05:28:41.583	2026-06-07 05:28:41.584025
74	1	detergent	77088.00	Lekki — detergent expense	f	2026-06-07 05:28:41.586	2026-06-07 05:28:41.587188
75	1	water	57488.00	Lekki — water expense	t	2026-05-18 05:28:41.589	2026-06-07 05:28:41.58955
76	1	salaries	10028.00	Lekki — salaries expense	t	2026-06-04 05:28:41.591	2026-06-07 05:28:41.592203
77	1	transport	55229.00	Lekki — transport expense	f	2026-05-22 05:28:41.594	2026-06-07 05:28:41.594797
78	1	maintenance	60473.00	Lekki — maintenance expense	f	2026-05-24 05:28:41.597	2026-06-07 05:28:41.597784
79	1	packaging	35001.00	Lekki — packaging expense	f	2026-06-03 05:28:41.6	2026-06-07 05:28:41.600638
80	1	miscellaneous	5688.00	Lekki — miscellaneous expense	f	2026-05-28 05:28:41.602	2026-06-07 05:28:41.603385
81	1	electricity	5467.00	Lekki — electricity expense	t	2026-04-22 05:28:41.605	2026-06-07 05:28:41.606003
82	1	detergent	69615.00	Lekki — detergent expense	f	2026-04-16 05:28:41.608	2026-06-07 05:28:41.608669
83	1	water	50400.00	Lekki — water expense	t	2026-04-23 05:28:41.61	2026-06-07 05:28:41.611399
84	1	salaries	52339.00	Lekki — salaries expense	t	2026-04-11 05:28:41.613	2026-06-07 05:28:41.613938
85	1	transport	34488.00	Lekki — transport expense	f	2026-04-16 05:28:41.616	2026-06-07 05:28:41.616825
86	1	maintenance	7212.00	Lekki — maintenance expense	f	2026-04-25 05:28:41.619	2026-06-07 05:28:41.619648
87	1	packaging	43935.00	Lekki — packaging expense	f	2026-04-14 05:28:41.621	2026-06-07 05:28:41.622311
88	1	miscellaneous	58592.00	Lekki — miscellaneous expense	f	2026-04-12 05:28:41.624	2026-06-07 05:28:41.625023
89	1	electricity	45789.00	Lekki — electricity expense	t	2026-03-16 05:28:41.627	2026-06-07 05:28:41.627834
90	1	detergent	79064.00	Lekki — detergent expense	f	2026-04-03 05:28:41.63	2026-06-07 05:28:41.630495
91	1	water	72729.00	Lekki — water expense	t	2026-03-10 05:28:41.632	2026-06-07 05:28:41.633321
92	1	salaries	18264.00	Lekki — salaries expense	t	2026-03-13 05:28:41.635	2026-06-07 05:28:41.63583
93	1	transport	75037.00	Lekki — transport expense	f	2026-03-28 05:28:41.638	2026-06-07 05:28:41.63869
94	1	maintenance	57603.00	Lekki — maintenance expense	f	2026-04-02 05:28:41.641	2026-06-07 05:28:41.641556
95	1	packaging	36456.00	Lekki — packaging expense	f	2026-03-22 05:28:41.644	2026-06-07 05:28:41.64485
96	1	miscellaneous	23973.00	Lekki — miscellaneous expense	f	2026-04-05 05:28:41.647	2026-06-07 05:28:41.648479
97	1	electricity	55002.00	Surulere — electricity expense	t	2026-05-12 05:28:43.193	2026-06-07 05:28:43.193639
98	1	detergent	74633.00	Surulere — detergent expense	f	2026-05-19 05:28:43.195	2026-06-07 05:28:43.195955
99	1	water	12577.00	Surulere — water expense	t	2026-06-04 05:28:43.198	2026-06-07 05:28:43.198398
100	1	salaries	44690.00	Surulere — salaries expense	t	2026-05-25 05:28:43.202	2026-06-07 05:28:43.202882
101	1	transport	53541.00	Surulere — transport expense	f	2026-05-26 05:28:43.205	2026-06-07 05:28:43.205596
102	1	maintenance	40905.00	Surulere — maintenance expense	f	2026-05-15 05:28:43.207	2026-06-07 05:28:43.208261
103	1	packaging	48638.00	Surulere — packaging expense	f	2026-06-04 05:28:43.21	2026-06-07 05:28:43.210851
104	1	miscellaneous	52788.00	Surulere — miscellaneous expense	f	2026-05-16 05:28:43.213	2026-06-07 05:28:43.213662
105	1	electricity	14032.00	Surulere — electricity expense	t	2026-04-24 05:28:43.215	2026-06-07 05:28:43.216012
106	1	detergent	71248.00	Surulere — detergent expense	f	2026-04-27 05:28:43.218	2026-06-07 05:28:43.2185
107	1	water	21253.00	Surulere — water expense	t	2026-05-05 05:28:43.22	2026-06-07 05:28:43.221017
108	1	salaries	35724.00	Surulere — salaries expense	t	2026-05-07 05:28:43.222	2026-06-07 05:28:43.223418
109	1	transport	24145.00	Surulere — transport expense	f	2026-05-08 05:28:43.226	2026-06-07 05:28:43.226599
110	1	maintenance	16407.00	Surulere — maintenance expense	f	2026-05-08 05:28:43.228	2026-06-07 05:28:43.228978
111	1	packaging	70346.00	Surulere — packaging expense	f	2026-04-25 05:28:43.231	2026-06-07 05:28:43.231636
112	1	miscellaneous	39332.00	Surulere — miscellaneous expense	f	2026-04-11 05:28:43.233	2026-06-07 05:28:43.23393
113	1	electricity	64383.00	Surulere — electricity expense	t	2026-04-06 05:28:43.236	2026-06-07 05:28:43.236476
114	1	detergent	43078.00	Surulere — detergent expense	f	2026-04-07 05:28:43.238	2026-06-07 05:28:43.238949
115	1	water	67581.00	Surulere — water expense	t	2026-03-23 05:28:43.241	2026-06-07 05:28:43.241426
116	1	salaries	10805.00	Surulere — salaries expense	t	2026-03-29 05:28:43.243	2026-06-07 05:28:43.243552
117	1	transport	36325.00	Surulere — transport expense	f	2026-03-24 05:28:43.245	2026-06-07 05:28:43.245733
118	1	maintenance	27246.00	Surulere — maintenance expense	f	2026-04-08 05:28:43.247	2026-06-07 05:28:43.248102
119	1	packaging	64969.00	Surulere — packaging expense	f	2026-03-30 05:28:43.25	2026-06-07 05:28:43.250633
120	1	miscellaneous	29347.00	Surulere — miscellaneous expense	f	2026-03-17 05:28:43.252	2026-06-07 05:28:43.252941
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, laundry_id, name, is_default, is_active, created_at, updated_at) FROM stdin;
1	1	electricity	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
2	1	detergent	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
3	1	water	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
4	1	salaries	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
5	1	transport	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
6	1	maintenance	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
7	1	packaging	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
8	1	miscellaneous	t	t	2026-06-07 05:28:34.790843	2026-06-07 05:28:34.790843
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idempotency_keys (key, status, status_code, response_body, created_at) FROM stdin;
\.


--
-- Data for Name: laundries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.laundries (id, business_name, owner_email, password_hash, phone, is_active, subscription_tier, subscription_status, trial_started_at, trial_ends_at, trial_duration_days, converted_at, subscription_renews_at, standard_turnaround_hours, express_turnaround_hours, premium_turnaround_hours, business_profile, branding_settings, operational_settings, automation_settings, dashboard_preferences, discount_settings, created_at, updated_at) FROM stdin;
1	CleanTrack Demo Laundry	demo@cleantrack.ng	$2a$12$4Br4WZ1gSIE9IiP8W5eB8eRhb1L2SlEAsP4o8ztn9SpIGJEQpYLpm	08012345678	t	free	trial	\N	\N	14	\N	\N	72	24	48	{"email": "demo@cleantrack.ng", "address": "1 Demo Close, Lagos"}	{"receiptFooterText": "Thank you for your business!", "receiptHeaderName": "CleanTrack Demo"}	{}	{}	{}	{"maxDiscountPerOrder": 5000, "autoApprovalThreshold": 500, "maxDiscountPercentage": 20}	2026-06-07 05:28:34.782042	2026-06-07 05:28:34.782042
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_templates (id, laundry_id, name, subject, body, is_default, is_active, created_at, updated_at) FROM stdin;
1	1	Order Ready	Your laundry is ready!	Hi {{customerName}}, your order #{{orderId}} is ready for pickup. Thank you for choosing {{businessName}}!	t	t	2026-06-07 05:28:34.795724	2026-06-07 05:28:34.795724
2	1	Payment Reminder	Payment reminder	Hi {{customerName}}, you have an outstanding balance of ₦{{balance}} for order #{{orderId}}. Please settle at your earliest convenience.	t	t	2026-06-07 05:28:34.795724	2026-06-07 05:28:34.795724
\.


--
-- Data for Name: notification_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_events (id, laundry_id, branch_id, event_type, order_id, customer_id, customer_phone, customer_name, status, skip_reason, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: notification_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_messages (id, laundry_id, event_id, template_id, channel, recipient_phone, recipient_name, rendered_body, status, provider_message_id, retry_count, error_message, metadata, queued_at, sent_at, delivered_at, read_at, failed_at) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, laundry_id, branch_id, event_trigger, channel, name, body, variables, is_active, is_default, created_at, updated_at) FROM stdin;
1	1	\N	order_received	whatsapp	Order Received (WhatsApp)	Hi {{customer_name}} 👋\n\nYour laundry order *#{{order_number}}* has been received at *{{branch_name}}*.\n\nService: {{service_type}}\nTotal: {{total_due}}\n\nWe'll notify you as soon as it's ready. Thank you for choosing {{business_name}}! 🧺	["customer_name", "order_number", "branch_name", "service_type", "total_due", "business_name"]	t	t	2026-06-07 05:38:16.082957	2026-06-07 05:38:16.082957
2	1	\N	order_ready	whatsapp	Order Ready (WhatsApp)	Hi {{customer_name}} ✅\n\nGreat news! Your laundry order *#{{order_number}}* is ready for pickup at *{{branch_name}}*.\n\nBalance Due: *{{balance}}*\n\nPlease come in at your earliest convenience. See you soon! 🎉	["customer_name", "order_number", "branch_name", "balance"]	t	t	2026-06-07 05:38:16.082957	2026-06-07 05:38:16.082957
3	1	\N	order_delivered	whatsapp	Order Delivered (WhatsApp)	Hi {{customer_name}} 🎊\n\nYour laundry order *#{{order_number}}* has been successfully picked up.\n\nThank you for choosing *{{business_name}}*! We look forward to serving you again.	["customer_name", "order_number", "business_name"]	t	t	2026-06-07 05:38:16.082957	2026-06-07 05:38:16.082957
4	1	\N	pickup_reminder	whatsapp	Pickup Reminder (WhatsApp)	Hi {{customer_name}} ⏰\n\nFriendly reminder — your laundry order *#{{order_number}}* has been ready at *{{branch_name}}* and is still awaiting pickup.\n\nBalance: *{{balance}}*\n\nPlease collect your items at your earliest convenience. Thank you!	["customer_name", "order_number", "branch_name", "balance"]	t	t	2026-06-07 05:38:16.082957	2026-06-07 05:38:16.082957
5	1	\N	payment_reminder	whatsapp	Payment Reminder (WhatsApp)	Hi {{customer_name}} 💳\n\nThis is a gentle reminder that you have an outstanding balance of *{{balance}}* for order *#{{order_number}}* at *{{branch_name}}*.\n\nAmount Paid: {{amount_paid}}\nTotal Due: {{total_due}}\n\nPlease make payment at your earliest convenience. Thank you!	["customer_name", "order_number", "branch_name", "balance", "amount_paid", "total_due"]	t	t	2026-06-07 05:38:16.082957	2026-06-07 05:38:16.082957
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, laundry_id, target_type, target_worker_id, event_type, title, message, severity, is_read, related_order_id, created_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, service_id, service_type, name, quantity, quantity_picked_up, unit_price, total_price, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, laundry_id, branch_id, customer_id, order_id, customer_name, phone, address, service_type, shirts, trousers, shirts_picked_up, trousers_picked_up, additional_notes, status, payment_status, price, extra_charge, discount, amount_paid, verified_shirts, verified_trousers, is_verified, batch_id, assigned_worker_id, processing_due_at, created_at, updated_at) FROM stdin;
1	1	1	25	DEMO0001	Damilola Musa	08055380232	\N	premium	4	1	0	0	\N	ready	unpaid	8000.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-04-14 05:28:35.6	2026-04-14 05:28:35.6
2	1	1	5	DEMO0002	Kunle Usman	08059867953	\N	express	3	5	0	0	\N	processing	unpaid	11100.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-04-14 05:28:35.606	2026-04-14 05:28:35.606
3	1	1	13	DEMO0003	Nneka Nwachukwu	08018585635	\N	standard	1	4	1	4	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	3	\N	2026-03-24 05:28:35.61	2026-03-24 05:28:35.61
4	1	1	28	DEMO0004	Chiamaka Eze	08095458818	\N	premium	2	0	0	0	\N	processing	partial	3000.00	\N	\N	1530.00	\N	\N	f	\N	3	\N	2026-04-08 05:28:35.618	2026-04-08 05:28:35.618
5	1	1	22	DEMO0005	Nneka Yusuf	08034282716	\N	premium	1	3	0	0	\N	ready	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	2	\N	2026-05-29 05:28:35.624	2026-05-29 05:28:35.624
6	1	1	36	DEMO0006	Adaeze Obiora	08041964471	\N	premium	4	3	4	3	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	1	\N	2026-03-11 05:28:35.632	2026-03-11 05:28:35.632
7	1	1	13	DEMO0007	Nneka Nwachukwu	08018585635	\N	express	8	2	8	2	\N	completed	paid	12600.00	\N	\N	12600.00	\N	\N	f	\N	2	\N	2026-03-18 05:28:35.638	2026-03-18 05:28:35.638
8	1	1	22	DEMO0008	Nneka Yusuf	08034282716	\N	premium	3	5	3	5	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	1	\N	2026-03-19 05:28:35.65	2026-03-19 05:28:35.65
9	1	1	19	DEMO0009	Amaka Nwosu	08029927239	\N	express	3	3	0	0	\N	ready	paid	8100.00	\N	\N	8100.00	\N	\N	f	\N	4	\N	2026-05-01 05:28:35.657	2026-05-01 05:28:35.657
10	1	1	15	DEMO0010	Ifeoma Alabi	08048741999	\N	standard	3	4	0	0	\N	ready	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	3	\N	2026-05-12 05:28:35.663	2026-05-12 05:28:35.663
11	1	1	11	DEMO0011	Obinna Okafor	08017815381	\N	express	8	1	0	0	\N	ready	partial	11100.00	\N	\N	7215.00	\N	\N	f	\N	2	\N	2026-05-25 05:28:35.67	2026-05-25 05:28:35.67
12	1	1	38	DEMO0012	Halima Eze	08084775440	\N	express	4	0	4	0	\N	completed	partial	4800.00	\N	\N	1776.00	\N	\N	f	\N	1	\N	2026-04-17 05:28:35.676	2026-04-17 05:28:35.676
13	1	1	26	DEMO0013	Ade Lawal	08086879964	\N	standard	8	5	8	5	\N	completed	paid	11400.00	\N	837.00	11400.00	\N	\N	f	\N	1	\N	2026-03-16 05:28:35.682	2026-03-16 05:28:35.682
14	1	1	39	DEMO0014	Zainab Okonkwo	08011657214	\N	premium	8	1	0	0	\N	processing	partial	14000.00	\N	\N	5040.00	\N	\N	f	\N	4	\N	2026-04-16 05:28:35.698	2026-04-16 05:28:35.698
15	1	1	37	DEMO0015	Chiamaka Okafor	08067605933	\N	standard	5	0	0	0	\N	ready	unpaid	4000.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-04-23 05:28:35.705	2026-04-23 05:28:35.705
16	1	1	35	DEMO0016	Ibrahim Usman	08049086824	\N	standard	6	2	0	0	\N	ready	partial	6800.00	\N	314.00	3944.00	\N	\N	f	\N	2	\N	2026-05-20 05:28:35.708	2026-05-20 05:28:35.708
17	1	1	23	DEMO0017	Tunde Babatunde	08068772425	\N	premium	3	4	3	4	\N	completed	paid	12500.00	\N	219.00	12500.00	\N	\N	f	\N	4	\N	2026-04-03 05:28:35.719	2026-04-03 05:28:35.719
18	1	1	22	DEMO0018	Nneka Yusuf	08034282716	\N	express	8	3	8	3	\N	completed	paid	14100.00	\N	\N	14100.00	\N	\N	f	\N	1	\N	2026-03-31 05:28:35.73	2026-03-31 05:28:35.73
19	1	1	11	DEMO0019	Obinna Okafor	08017815381	\N	standard	2	0	0	0	\N	ready	partial	1600.00	\N	\N	1024.00	\N	\N	f	\N	3	\N	2026-05-18 05:28:35.737	2026-05-18 05:28:35.737
20	1	1	11	DEMO0020	Obinna Okafor	08017815381	\N	standard	2	0	0	0	\N	pending	paid	1600.00	\N	\N	1600.00	\N	\N	f	\N	1	\N	2026-05-08 05:28:35.744	2026-05-08 05:28:35.744
21	1	1	39	DEMO0021	Zainab Okonkwo	08011657214	\N	standard	4	4	4	4	\N	completed	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	3	\N	2026-04-02 05:28:35.748	2026-04-02 05:28:35.748
22	1	1	33	DEMO0022	Chiamaka Okonkwo	08062671217	\N	premium	4	2	0	0	\N	processing	partial	10000.00	\N	\N	3700.00	\N	\N	f	\N	3	\N	2026-06-01 05:28:35.755	2026-06-01 05:28:35.755
23	1	1	20	DEMO0023	Chidi Babatunde	08032522120	\N	standard	2	2	0	0	\N	processing	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	1	\N	2026-04-15 05:28:35.764	2026-04-15 05:28:35.764
24	1	1	21	DEMO0024	Nkechi Okonkwo	08097044521	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	281.00	15500.00	\N	\N	f	\N	3	\N	2026-03-15 05:28:35.774	2026-03-15 05:28:35.774
25	1	1	29	DEMO0025	Nkechi Yusuf	08025745890	\N	express	3	4	3	4	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	2	\N	2026-03-17 05:28:35.786	2026-03-17 05:28:35.786
26	1	1	24	DEMO0026	Halima Bello	08061372450	\N	premium	4	1	0	0	\N	pending	unpaid	8000.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-06-03 05:28:35.792	2026-06-03 05:28:35.792
27	1	1	27	DEMO0027	Tunde Chukwu	08025640703	\N	express	5	4	5	4	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	4	\N	2026-03-13 05:28:35.796	2026-03-13 05:28:35.796
28	1	1	28	DEMO0028	Chiamaka Eze	08095458818	\N	express	7	0	7	0	\N	completed	paid	8400.00	\N	234.00	8400.00	\N	\N	f	\N	3	\N	2026-03-26 05:28:35.803	2026-03-26 05:28:35.803
29	1	1	9	DEMO0029	Chidi Danjuma	08070286285	\N	premium	8	0	0	0	\N	processing	partial	12000.00	\N	\N	5040.00	\N	\N	f	\N	3	\N	2026-05-20 05:28:35.813	2026-05-20 05:28:35.813
30	1	1	31	DEMO0030	Chioma Nwachukwu	08042444264	\N	premium	6	5	0	0	\N	ready	partial	19000.00	\N	\N	10260.00	\N	\N	f	\N	1	\N	2026-05-10 05:28:35.818	2026-05-10 05:28:35.818
31	1	1	7	DEMO0031	Ada Musa	08037503969	\N	premium	1	0	0	0	\N	processing	partial	1500.00	\N	\N	720.00	\N	\N	f	\N	2	\N	2026-06-04 05:28:35.825	2026-06-04 05:28:35.825
32	1	1	8	DEMO0032	Fatima Adeyemi	08073395153	\N	express	2	2	2	2	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	3	\N	2026-04-28 05:28:35.832	2026-04-28 05:28:35.832
33	1	1	24	DEMO0033	Halima Bello	08061372450	\N	premium	8	2	0	0	\N	pending	unpaid	16000.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-05-27 05:28:35.838	2026-05-27 05:28:35.838
34	1	1	37	DEMO0034	Chiamaka Okafor	08067605933	\N	standard	8	4	8	4	\N	completed	partial	10400.00	\N	\N	5512.00	\N	\N	f	\N	1	\N	2026-03-22 05:28:35.841	2026-03-22 05:28:35.841
35	1	1	25	DEMO0035	Damilola Musa	08055380232	\N	express	1	5	0	0	\N	processing	unpaid	8700.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-05-04 05:28:35.851	2026-05-04 05:28:35.851
36	1	1	34	DEMO0036	Chioma Babatunde	08073964755	\N	standard	1	5	0	0	\N	pending	paid	5800.00	\N	\N	5800.00	\N	\N	f	\N	4	\N	2026-05-31 05:28:35.854	2026-05-31 05:28:35.854
37	1	1	8	DEMO0037	Fatima Adeyemi	08073395153	\N	premium	5	1	0	0	\N	ready	partial	9500.00	\N	\N	3040.00	\N	\N	f	\N	1	\N	2026-05-08 05:28:35.86	2026-05-08 05:28:35.86
38	1	1	37	DEMO0038	Chiamaka Okafor	08067605933	\N	standard	7	0	0	0	\N	ready	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	2	\N	2026-05-01 05:28:35.867	2026-05-01 05:28:35.867
39	1	1	1	DEMO0039	Amaka Adeyemi	08075493651	\N	standard	8	0	0	0	\N	processing	unpaid	6400.00	\N	407.00	0.00	\N	\N	f	\N	1	\N	2026-05-04 05:28:35.874	2026-05-04 05:28:35.874
40	1	1	25	DEMO0040	Damilola Musa	08055380232	\N	express	1	2	1	2	\N	completed	paid	4200.00	\N	\N	4200.00	\N	\N	f	\N	4	\N	2026-03-25 05:28:35.884	2026-03-25 05:28:35.884
41	1	1	26	DEMO0041	Ade Lawal	08086879964	\N	premium	1	4	1	4	\N	completed	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	2	\N	2026-03-09 05:28:35.891	2026-03-09 05:28:35.891
42	1	1	12	DEMO0042	Blessing Yusuf	08048555185	\N	premium	8	2	8	2	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	1	\N	2026-03-26 05:28:35.897	2026-03-26 05:28:35.897
43	1	1	12	DEMO0043	Blessing Yusuf	08048555185	\N	standard	4	2	0	0	\N	ready	paid	5200.00	\N	\N	5200.00	\N	\N	f	\N	4	\N	2026-05-09 05:28:35.907	2026-05-09 05:28:35.907
44	1	1	8	DEMO0044	Fatima Adeyemi	08073395153	\N	standard	8	5	8	5	\N	completed	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	3	\N	2026-04-11 05:28:35.913	2026-04-11 05:28:35.913
45	1	1	23	DEMO0045	Tunde Babatunde	08068772425	\N	express	6	5	0	0	\N	ready	paid	14700.00	\N	239.00	14700.00	\N	\N	f	\N	1	\N	2026-05-21 05:28:35.918	2026-05-21 05:28:35.918
46	1	1	4	DEMO0046	Emeka Abubakar	08072644757	\N	express	4	0	4	0	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	2	\N	2026-04-10 05:28:35.931	2026-04-10 05:28:35.931
47	1	1	19	DEMO0047	Amaka Nwosu	08029927239	\N	standard	3	5	3	5	\N	completed	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	4	\N	2026-04-21 05:28:35.937	2026-04-21 05:28:35.937
48	1	1	30	DEMO0048	Musa Obiora	08046404380	\N	standard	3	0	3	0	\N	completed	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	4	\N	2026-03-20 05:28:35.944	2026-03-20 05:28:35.944
49	1	1	10	DEMO0049	Yusuf Abubakar	08094403256	\N	premium	6	4	0	0	\N	processing	paid	17000.00	\N	\N	17000.00	\N	\N	f	\N	2	\N	2026-05-23 05:28:35.951	2026-05-23 05:28:35.951
50	1	1	27	DEMO0050	Tunde Chukwu	08025640703	\N	express	4	1	4	1	\N	completed	paid	6300.00	\N	\N	6300.00	\N	\N	f	\N	2	\N	2026-03-14 05:28:35.957	2026-03-14 05:28:35.957
51	1	1	14	DEMO0051	Tunde Adeyemi	08023848910	\N	premium	3	0	0	0	\N	processing	paid	4500.00	\N	\N	4500.00	\N	\N	f	\N	4	\N	2026-05-17 05:28:35.964	2026-05-17 05:28:35.964
52	1	1	39	DEMO0052	Zainab Okonkwo	08011657214	\N	standard	4	4	0	0	\N	processing	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	2	\N	2026-05-16 05:28:35.97	2026-05-16 05:28:35.97
53	1	1	20	DEMO0053	Chidi Babatunde	08032522120	\N	express	2	3	2	3	\N	completed	paid	6900.00	\N	\N	6900.00	\N	\N	f	\N	3	\N	2026-03-26 05:28:35.98	2026-03-26 05:28:35.98
54	1	1	28	DEMO0054	Chiamaka Eze	08095458818	\N	standard	7	2	7	2	\N	completed	paid	7600.00	\N	\N	7600.00	\N	\N	f	\N	2	\N	2026-03-15 05:28:35.986	2026-03-15 05:28:35.986
55	1	1	33	DEMO0055	Chiamaka Okonkwo	08062671217	\N	standard	4	5	0	0	\N	ready	partial	8200.00	\N	\N	4756.00	\N	\N	f	\N	2	\N	2026-04-21 05:28:35.992	2026-04-21 05:28:35.992
56	1	1	11	DEMO0056	Obinna Okafor	08017815381	\N	standard	4	2	4	2	\N	completed	paid	5200.00	\N	\N	5200.00	\N	\N	f	\N	4	\N	2026-03-27 05:28:35.998	2026-03-27 05:28:35.998
57	1	1	12	DEMO0057	Blessing Yusuf	08048555185	\N	express	4	4	0	0	\N	processing	paid	10800.00	\N	\N	10800.00	\N	\N	f	\N	1	\N	2026-05-13 05:28:36.004	2026-05-13 05:28:36.004
58	1	1	13	DEMO0058	Nneka Nwachukwu	08018585635	\N	standard	5	5	5	5	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	3	\N	2026-03-12 05:28:36.011	2026-03-12 05:28:36.011
59	1	1	31	DEMO0059	Chioma Nwachukwu	08042444264	\N	express	7	5	7	5	\N	completed	paid	15900.00	\N	\N	15900.00	\N	\N	f	\N	4	\N	2026-03-23 05:28:36.017	2026-03-23 05:28:36.017
60	1	1	20	DEMO0060	Chidi Babatunde	08032522120	\N	express	3	5	3	5	\N	completed	paid	11100.00	\N	436.00	11100.00	\N	\N	f	\N	2	\N	2026-03-23 05:28:36.025	2026-03-23 05:28:36.025
61	1	1	18	DEMO0061	Emeka Obi	08071569633	\N	premium	8	4	0	0	\N	processing	unpaid	20000.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-04-30 05:28:36.038	2026-04-30 05:28:36.038
62	1	1	7	DEMO0062	Ada Musa	08037503969	\N	express	3	1	3	1	\N	completed	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	4	\N	2026-04-17 05:28:36.041	2026-04-17 05:28:36.041
63	1	1	26	DEMO0063	Ade Lawal	08086879964	\N	premium	1	0	0	0	\N	pending	unpaid	1500.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-05-26 05:28:36.052	2026-05-26 05:28:36.052
64	1	1	29	DEMO0064	Nkechi Yusuf	08025745890	\N	express	8	0	0	0	\N	pending	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	3	\N	2026-05-24 05:28:36.056	2026-05-24 05:28:36.056
65	1	1	1	DEMO0065	Amaka Adeyemi	08075493651	\N	express	6	4	6	4	\N	completed	paid	13200.00	\N	\N	13200.00	\N	\N	f	\N	4	\N	2026-04-19 05:28:36.063	2026-04-19 05:28:36.063
66	1	1	16	DEMO0066	Nkechi Okafor	08028383023	\N	premium	5	2	0	0	\N	processing	unpaid	11500.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-04-24 05:28:36.07	2026-04-24 05:28:36.07
67	1	1	9	DEMO0067	Chidi Danjuma	08070286285	\N	premium	5	4	5	4	\N	completed	partial	15500.00	\N	529.00	10540.00	\N	\N	f	\N	4	\N	2026-04-02 05:28:36.074	2026-04-02 05:28:36.074
68	1	1	18	DEMO0068	Emeka Obi	08071569633	\N	standard	3	4	0	0	\N	processing	unpaid	6400.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-04-13 05:28:36.091	2026-04-13 05:28:36.091
69	1	1	32	DEMO0069	Obinna Okafor	08079042007	\N	premium	5	5	0	0	\N	processing	partial	17500.00	\N	\N	7525.00	\N	\N	f	\N	3	\N	2026-05-31 05:28:36.095	2026-05-31 05:28:36.095
70	1	1	37	DEMO0070	Chiamaka Okafor	08067605933	\N	premium	5	2	0	0	\N	pending	partial	11500.00	\N	\N	5980.00	\N	\N	f	\N	2	\N	2026-05-20 05:28:36.105	2026-05-20 05:28:36.105
71	1	1	40	DEMO0071	Babajide Obiora	08049340297	\N	standard	8	2	0	0	\N	processing	unpaid	8400.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-05-28 05:28:36.111	2026-05-28 05:28:36.111
72	1	1	27	DEMO0072	Tunde Chukwu	08025640703	\N	standard	4	4	0	0	\N	processing	unpaid	7200.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-04-20 05:28:36.115	2026-04-20 05:28:36.115
73	1	1	9	DEMO0073	Chidi Danjuma	08070286285	\N	premium	5	4	0	0	\N	processing	unpaid	15500.00	\N	498.00	0.00	\N	\N	f	\N	1	\N	2026-04-27 05:28:36.118	2026-04-27 05:28:36.118
74	1	1	27	DEMO0074	Tunde Chukwu	08025640703	\N	premium	1	2	0	0	\N	processing	paid	5500.00	\N	\N	5500.00	\N	\N	f	\N	4	\N	2026-05-25 05:28:36.127	2026-05-25 05:28:36.127
75	1	1	33	DEMO0075	Chiamaka Okonkwo	08062671217	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	3	\N	2026-04-05 05:28:36.134	2026-04-05 05:28:36.134
76	1	1	6	DEMO0076	Tobi Adeyemi	08086792288	\N	premium	3	5	0	0	\N	ready	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	4	\N	2026-04-18 05:28:36.141	2026-04-18 05:28:36.141
77	1	1	7	DEMO0077	Ada Musa	08037503969	\N	standard	7	2	0	0	\N	ready	unpaid	7600.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-04-24 05:28:36.148	2026-04-24 05:28:36.148
78	1	1	31	DEMO0078	Chioma Nwachukwu	08042444264	\N	express	4	2	0	0	\N	ready	unpaid	7800.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-05-20 05:28:36.151	2026-05-20 05:28:36.151
79	1	1	7	DEMO0079	Ada Musa	08037503969	\N	premium	7	2	0	0	\N	processing	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	2	\N	2026-04-12 05:28:36.157	2026-04-12 05:28:36.157
80	1	1	23	DEMO0080	Tunde Babatunde	08068772425	\N	standard	4	2	4	2	\N	completed	paid	5200.00	\N	\N	5200.00	\N	\N	f	\N	4	\N	2026-04-03 05:28:36.165	2026-04-03 05:28:36.165
81	1	1	6	DEMO0081	Tobi Adeyemi	08086792288	\N	express	7	3	7	3	\N	completed	paid	12900.00	\N	\N	12900.00	\N	\N	f	\N	1	\N	2026-04-02 05:28:36.17	2026-04-02 05:28:36.17
82	1	1	5	DEMO0082	Kunle Usman	08059867953	\N	express	5	2	5	2	\N	completed	paid	9000.00	\N	347.00	9000.00	\N	\N	f	\N	4	\N	2026-03-15 05:28:36.176	2026-03-15 05:28:36.176
83	1	1	24	DEMO0083	Halima Bello	08061372450	\N	express	7	5	7	5	\N	completed	paid	15900.00	\N	\N	15900.00	\N	\N	f	\N	3	\N	2026-03-23 05:28:36.188	2026-03-23 05:28:36.188
84	1	1	3	DEMO0084	Emeka Adeyemi	08088886674	\N	premium	3	4	0	0	\N	ready	partial	12500.00	\N	\N	4375.00	\N	\N	f	\N	1	\N	2026-05-17 05:28:36.194	2026-05-17 05:28:36.194
85	1	1	8	DEMO0085	Fatima Adeyemi	08073395153	\N	express	5	4	5	4	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	2	\N	2026-03-31 05:28:36.201	2026-03-31 05:28:36.201
86	1	1	5	DEMO0086	Kunle Usman	08059867953	\N	standard	3	5	0	0	\N	processing	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	1	\N	2026-06-05 05:28:36.209	2026-06-05 05:28:36.209
87	1	1	29	DEMO0087	Nkechi Yusuf	08025745890	\N	express	3	0	3	0	\N	completed	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	3	\N	2026-03-25 05:28:36.218	2026-03-25 05:28:36.218
88	1	1	10	DEMO0088	Yusuf Abubakar	08094403256	\N	premium	7	1	7	1	\N	completed	partial	12500.00	\N	\N	6000.00	\N	\N	f	\N	2	\N	2026-03-22 05:28:36.225	2026-03-22 05:28:36.225
89	1	1	2	DEMO0089	Ibrahim Alabi	08067982616	\N	premium	6	2	6	2	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	1	\N	2026-03-27 05:28:36.233	2026-03-27 05:28:36.233
90	1	1	16	DEMO0090	Nkechi Okafor	08028383023	\N	express	3	5	0	0	\N	pending	unpaid	11100.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-05-26 05:28:36.244	2026-05-26 05:28:36.244
91	1	1	18	DEMO0091	Emeka Obi	08071569633	\N	standard	7	0	7	0	\N	completed	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	3	\N	2026-03-09 05:28:36.248	2026-03-09 05:28:36.248
92	1	1	14	DEMO0092	Tunde Adeyemi	08023848910	\N	express	6	4	0	0	\N	ready	partial	13200.00	\N	\N	5808.00	\N	\N	f	\N	4	\N	2026-05-17 05:28:36.254	2026-05-17 05:28:36.254
93	1	1	10	DEMO0093	Yusuf Abubakar	08094403256	\N	premium	8	0	8	0	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	4	\N	2026-03-13 05:28:36.262	2026-03-13 05:28:36.262
94	1	1	11	DEMO0094	Obinna Okafor	08017815381	\N	express	3	5	0	0	\N	ready	unpaid	11100.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-05-30 05:28:36.269	2026-05-30 05:28:36.269
95	1	1	31	DEMO0095	Chioma Nwachukwu	08042444264	\N	express	1	0	0	0	\N	pending	unpaid	1200.00	\N	425.00	0.00	\N	\N	f	\N	2	\N	2026-05-28 05:28:36.272	2026-05-28 05:28:36.272
96	1	1	35	DEMO0096	Ibrahim Usman	08049086824	\N	express	1	2	0	0	\N	processing	paid	4200.00	\N	\N	4200.00	\N	\N	f	\N	1	\N	2026-05-19 05:28:36.281	2026-05-19 05:28:36.281
97	1	1	24	DEMO0097	Halima Bello	08061372450	\N	premium	7	5	7	5	\N	completed	paid	20500.00	\N	\N	20500.00	\N	\N	f	\N	2	\N	2026-03-09 05:28:36.288	2026-03-09 05:28:36.288
98	1	1	40	DEMO0098	Babajide Obiora	08049340297	\N	express	7	2	7	2	\N	completed	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	4	\N	2026-04-28 05:28:36.295	2026-04-28 05:28:36.295
99	1	1	27	DEMO0099	Tunde Chukwu	08025640703	\N	premium	4	5	4	5	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	4	\N	2026-03-16 05:28:36.303	2026-03-16 05:28:36.303
100	1	1	15	DEMO0100	Ifeoma Alabi	08048741999	\N	standard	4	2	0	0	\N	processing	partial	5200.00	\N	\N	1560.00	\N	\N	f	\N	4	\N	2026-04-26 05:28:36.311	2026-04-26 05:28:36.311
101	1	1	19	DEMO0101	Amaka Nwosu	08029927239	\N	express	7	4	0	0	\N	ready	unpaid	14400.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-04-16 05:28:36.322	2026-04-16 05:28:36.322
102	1	1	22	DEMO0102	Nneka Yusuf	08034282716	\N	standard	8	3	0	0	\N	processing	paid	9400.00	\N	\N	9400.00	\N	\N	f	\N	3	\N	2026-04-16 05:28:36.327	2026-04-16 05:28:36.327
103	1	1	15	DEMO0103	Ifeoma Alabi	08048741999	\N	express	6	4	0	0	\N	ready	unpaid	13200.00	\N	202.00	0.00	\N	\N	f	\N	1	\N	2026-05-25 05:28:36.334	2026-05-25 05:28:36.334
104	1	1	37	DEMO0104	Chiamaka Okafor	08067605933	\N	express	4	2	0	0	\N	ready	unpaid	7800.00	\N	1242.00	0.00	\N	\N	f	\N	4	\N	2026-04-11 05:28:36.343	2026-04-11 05:28:36.343
105	1	1	1	DEMO0105	Amaka Adeyemi	08075493651	\N	standard	8	0	0	0	\N	processing	partial	6400.00	\N	473.00	4160.00	\N	\N	f	\N	3	\N	2026-05-01 05:28:36.358	2026-05-01 05:28:36.358
106	1	1	38	DEMO0106	Halima Eze	08084775440	\N	premium	7	5	0	0	\N	pending	unpaid	20500.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-06-04 05:28:36.372	2026-06-04 05:28:36.372
107	1	1	19	DEMO0107	Amaka Nwosu	08029927239	\N	premium	6	2	0	0	\N	ready	partial	13000.00	\N	\N	4290.00	\N	\N	f	\N	4	\N	2026-05-26 05:28:36.376	2026-05-26 05:28:36.376
108	1	1	37	DEMO0108	Chiamaka Okafor	08067605933	\N	express	1	4	0	0	\N	pending	partial	7200.00	\N	\N	3024.00	\N	\N	f	\N	1	\N	2026-05-09 05:28:36.383	2026-05-09 05:28:36.383
109	1	1	28	DEMO0109	Chiamaka Eze	08095458818	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	3	\N	2026-04-15 05:28:36.391	2026-04-15 05:28:36.391
110	1	1	12	DEMO0110	Blessing Yusuf	08048555185	\N	premium	1	4	1	4	\N	completed	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	4	\N	2026-03-09 05:28:36.399	2026-03-09 05:28:36.399
111	1	1	33	DEMO0111	Chiamaka Okonkwo	08062671217	\N	premium	2	4	2	4	\N	completed	paid	11000.00	\N	\N	11000.00	\N	\N	f	\N	2	\N	2026-03-18 05:28:36.408	2026-03-18 05:28:36.408
112	1	1	19	DEMO0112	Amaka Nwosu	08029927239	\N	standard	3	2	0	0	\N	pending	partial	4400.00	\N	\N	2156.00	\N	\N	f	\N	4	\N	2026-05-31 05:28:36.42	2026-05-31 05:28:36.42
113	1	1	32	DEMO0113	Obinna Okafor	08079042007	\N	express	2	0	2	0	\N	completed	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	2	\N	2026-03-16 05:28:36.426	2026-03-16 05:28:36.426
114	1	1	2	DEMO0114	Ibrahim Alabi	08067982616	\N	standard	1	3	0	0	\N	pending	partial	3800.00	\N	\N	1254.00	\N	\N	f	\N	3	\N	2026-05-27 05:28:36.433	2026-05-27 05:28:36.433
115	1	1	10	DEMO0115	Yusuf Abubakar	08094403256	\N	premium	4	5	0	0	\N	ready	unpaid	16000.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-04-18 05:28:36.439	2026-04-18 05:28:36.439
116	1	1	32	DEMO0116	Obinna Okafor	08079042007	\N	premium	8	5	0	0	\N	processing	paid	22000.00	\N	\N	22000.00	\N	\N	f	\N	3	\N	2026-04-22 05:28:36.442	2026-04-22 05:28:36.442
117	1	1	25	DEMO0117	Damilola Musa	08055380232	\N	premium	8	4	8	4	\N	completed	paid	20000.00	\N	\N	20000.00	\N	\N	f	\N	4	\N	2026-03-11 05:28:36.449	2026-03-11 05:28:36.449
118	1	1	8	DEMO0118	Fatima Adeyemi	08073395153	\N	express	4	3	0	0	\N	ready	paid	9300.00	\N	\N	9300.00	\N	\N	f	\N	1	\N	2026-05-18 05:28:36.456	2026-05-18 05:28:36.456
119	1	1	26	DEMO0119	Ade Lawal	08086879964	\N	premium	2	0	0	0	\N	processing	partial	3000.00	\N	\N	1680.00	\N	\N	f	\N	4	\N	2026-05-25 05:28:36.462	2026-05-25 05:28:36.462
120	1	1	1	DEMO0120	Amaka Adeyemi	08075493651	\N	express	8	3	0	0	\N	processing	unpaid	14100.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-05-05 05:28:36.469	2026-05-05 05:28:36.469
121	1	1	7	DEMO0121	Ada Musa	08037503969	\N	standard	3	4	3	4	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	2	\N	2026-03-26 05:28:36.475	2026-03-26 05:28:36.475
122	1	1	36	DEMO0122	Adaeze Obiora	08041964471	\N	express	1	2	0	0	\N	ready	unpaid	4200.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-05-12 05:28:36.481	2026-05-12 05:28:36.481
123	1	1	26	DEMO0123	Ade Lawal	08086879964	\N	standard	6	5	6	5	\N	completed	paid	9800.00	\N	\N	9800.00	\N	\N	f	\N	2	\N	2026-03-11 05:28:36.484	2026-03-11 05:28:36.484
124	1	1	37	DEMO0124	Chiamaka Okafor	08067605933	\N	premium	5	4	0	0	\N	processing	partial	15500.00	\N	193.00	6975.00	\N	\N	f	\N	2	\N	2026-05-15 05:28:36.49	2026-05-15 05:28:36.49
125	1	1	11	DEMO0125	Obinna Okafor	08017815381	\N	standard	4	5	0	0	\N	ready	unpaid	8200.00	\N	\N	0.00	\N	\N	f	\N	1	\N	2026-04-09 05:28:36.502	2026-04-09 05:28:36.502
126	1	1	8	DEMO0126	Fatima Adeyemi	08073395153	\N	premium	7	1	7	1	\N	completed	paid	12500.00	\N	658.00	12500.00	\N	\N	f	\N	2	\N	2026-03-30 05:28:36.505	2026-03-30 05:28:36.505
127	1	1	19	DEMO0127	Amaka Nwosu	08029927239	\N	express	1	5	1	5	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	2	\N	2026-03-17 05:28:36.523	2026-03-17 05:28:36.523
128	1	1	1	DEMO0128	Amaka Adeyemi	08075493651	\N	premium	8	5	0	0	\N	processing	unpaid	22000.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-04-11 05:28:36.53	2026-04-11 05:28:36.53
129	1	1	26	DEMO0129	Ade Lawal	08086879964	\N	premium	2	5	0	0	\N	processing	partial	13000.00	\N	\N	8190.00	\N	\N	f	\N	4	\N	2026-04-22 05:28:36.533	2026-04-22 05:28:36.533
130	1	1	14	DEMO0130	Tunde Adeyemi	08023848910	\N	premium	4	2	0	0	\N	ready	partial	10000.00	\N	179.00	5900.00	\N	\N	f	\N	1	\N	2026-04-30 05:28:36.541	2026-04-30 05:28:36.541
131	1	1	31	DEMO0131	Chioma Nwachukwu	08042444264	\N	premium	4	2	0	0	\N	processing	unpaid	10000.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-06-07 05:28:36.554	2026-06-07 05:28:36.554
132	1	1	35	DEMO0132	Ibrahim Usman	08049086824	\N	standard	6	5	0	0	\N	processing	paid	9800.00	\N	\N	9800.00	\N	\N	f	\N	3	\N	2026-06-01 05:28:36.559	2026-06-01 05:28:36.559
133	1	1	26	DEMO0133	Ade Lawal	08086879964	\N	express	1	3	1	3	\N	completed	paid	5700.00	\N	\N	5700.00	\N	\N	f	\N	1	\N	2026-03-12 05:28:36.567	2026-03-12 05:28:36.567
134	1	1	16	DEMO0134	Nkechi Okafor	08028383023	\N	premium	7	1	0	0	\N	processing	partial	12500.00	\N	\N	7500.00	\N	\N	f	\N	1	\N	2026-05-16 05:28:36.574	2026-05-16 05:28:36.574
135	1	1	6	DEMO0135	Tobi Adeyemi	08086792288	\N	premium	3	2	0	0	\N	ready	partial	8500.00	\N	\N	4505.00	\N	\N	f	\N	1	\N	2026-04-12 05:28:36.582	2026-04-12 05:28:36.582
136	1	1	11	DEMO0136	Obinna Okafor	08017815381	\N	express	6	1	6	1	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	3	\N	2026-04-29 05:28:36.59	2026-04-29 05:28:36.59
137	1	1	13	DEMO0137	Nneka Nwachukwu	08018585635	\N	premium	1	4	0	0	\N	processing	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	3	\N	2026-05-03 05:28:36.6	2026-05-03 05:28:36.6
138	1	1	19	DEMO0138	Amaka Nwosu	08029927239	\N	express	2	0	0	0	\N	ready	unpaid	2400.00	\N	477.00	0.00	\N	\N	f	\N	2	\N	2026-05-07 05:28:36.607	2026-05-07 05:28:36.607
139	1	1	12	DEMO0139	Blessing Yusuf	08048555185	\N	standard	5	5	5	5	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	1	\N	2026-03-21 05:28:36.616	2026-03-21 05:28:36.616
140	1	1	38	DEMO0140	Halima Eze	08084775440	\N	express	4	1	0	0	\N	pending	unpaid	6300.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-06-01 05:28:36.622	2026-06-01 05:28:36.622
141	1	1	15	DEMO0141	Ifeoma Alabi	08048741999	\N	premium	5	5	0	0	\N	ready	unpaid	17500.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-05-09 05:28:36.626	2026-05-09 05:28:36.626
142	1	1	5	DEMO0142	Kunle Usman	08059867953	\N	standard	1	0	1	0	\N	completed	paid	800.00	\N	\N	800.00	\N	\N	f	\N	1	\N	2026-04-07 05:28:36.63	2026-04-07 05:28:36.63
143	1	1	25	DEMO0143	Damilola Musa	08055380232	\N	express	7	3	0	0	\N	ready	unpaid	12900.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-05-02 05:28:36.636	2026-05-02 05:28:36.636
144	1	1	38	DEMO0144	Halima Eze	08084775440	\N	standard	2	5	2	5	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	1	\N	2026-03-11 05:28:36.639	2026-03-11 05:28:36.639
145	1	1	1	DEMO0145	Amaka Adeyemi	08075493651	\N	standard	4	3	4	3	\N	completed	paid	6200.00	\N	450.00	6200.00	\N	\N	f	\N	1	\N	2026-03-24 05:28:36.645	2026-03-24 05:28:36.645
146	1	1	29	DEMO0146	Nkechi Yusuf	08025745890	\N	premium	2	0	0	0	\N	processing	paid	3000.00	\N	\N	3000.00	\N	\N	f	\N	2	\N	2026-04-22 05:28:36.657	2026-04-22 05:28:36.657
147	1	1	5	DEMO0147	Kunle Usman	08059867953	\N	standard	7	2	7	2	\N	completed	paid	7600.00	\N	\N	7600.00	\N	\N	f	\N	4	\N	2026-04-01 05:28:36.664	2026-04-01 05:28:36.664
148	1	1	4	DEMO0148	Emeka Abubakar	08072644757	\N	express	7	3	7	3	\N	completed	paid	12900.00	\N	\N	12900.00	\N	\N	f	\N	1	\N	2026-03-25 05:28:36.671	2026-03-25 05:28:36.671
149	1	1	7	DEMO0149	Ada Musa	08037503969	\N	standard	3	3	0	0	\N	ready	partial	5400.00	\N	\N	2646.00	\N	\N	f	\N	4	\N	2026-04-22 05:28:36.678	2026-04-22 05:28:36.678
150	1	1	14	DEMO0150	Tunde Adeyemi	08023848910	\N	standard	5	3	5	3	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	2	\N	2026-04-04 05:28:36.685	2026-04-04 05:28:36.685
151	1	1	29	DEMO0151	Nkechi Yusuf	08025745890	\N	premium	2	3	0	0	\N	ready	partial	9000.00	\N	\N	4860.00	\N	\N	f	\N	1	\N	2026-05-04 05:28:36.696	2026-05-04 05:28:36.696
152	1	1	5	DEMO0152	Kunle Usman	08059867953	\N	premium	5	3	0	0	\N	pending	unpaid	13500.00	\N	291.00	0.00	\N	\N	f	\N	3	\N	2026-06-06 05:28:36.703	2026-06-06 05:28:36.703
153	1	1	7	DEMO0153	Ada Musa	08037503969	\N	premium	6	1	0	0	\N	ready	partial	11000.00	\N	\N	7150.00	\N	\N	f	\N	1	\N	2026-05-16 05:28:36.712	2026-05-16 05:28:36.712
154	1	1	28	DEMO0154	Chiamaka Eze	08095458818	\N	standard	5	3	5	3	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	4	\N	2026-04-29 05:28:36.719	2026-04-29 05:28:36.719
155	1	1	38	DEMO0155	Halima Eze	08084775440	\N	standard	5	3	5	3	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	3	\N	2026-04-10 05:28:36.727	2026-04-10 05:28:36.727
156	1	1	30	DEMO0156	Musa Obiora	08046404380	\N	standard	7	2	7	2	\N	completed	paid	7600.00	\N	279.00	7600.00	\N	\N	f	\N	2	\N	2026-05-04 05:28:36.734	2026-05-04 05:28:36.734
157	1	1	27	DEMO0157	Tunde Chukwu	08025640703	\N	express	2	3	0	0	\N	processing	unpaid	6900.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-04-13 05:28:36.747	2026-04-13 05:28:36.747
158	1	1	10	DEMO0158	Yusuf Abubakar	08094403256	\N	premium	5	5	5	5	\N	completed	partial	17500.00	\N	\N	8575.00	\N	\N	f	\N	1	\N	2026-03-09 05:28:36.751	2026-03-09 05:28:36.751
159	1	1	2	DEMO0159	Ibrahim Alabi	08067982616	\N	standard	7	0	7	0	\N	completed	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	4	\N	2026-03-23 05:28:36.757	2026-03-23 05:28:36.757
160	1	1	2	DEMO0160	Ibrahim Alabi	08067982616	\N	premium	1	4	0	0	\N	processing	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	2	\N	2026-06-05 05:28:36.765	2026-06-05 05:28:36.765
161	1	1	39	DEMO0161	Zainab Okonkwo	08011657214	\N	standard	3	5	0	0	\N	ready	partial	7400.00	\N	\N	2220.00	\N	\N	f	\N	2	\N	2026-05-13 05:28:36.771	2026-05-13 05:28:36.771
162	1	1	25	DEMO0162	Damilola Musa	08055380232	\N	express	6	4	0	0	\N	processing	unpaid	13200.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-06-06 05:28:36.778	2026-06-06 05:28:36.778
163	1	1	24	DEMO0163	Halima Bello	08061372450	\N	standard	4	1	0	0	\N	processing	unpaid	4200.00	\N	\N	0.00	\N	\N	f	\N	2	\N	2026-04-08 05:28:36.782	2026-04-08 05:28:36.782
164	1	1	10	DEMO0164	Yusuf Abubakar	08094403256	\N	express	4	4	0	0	\N	pending	paid	10800.00	\N	\N	10800.00	\N	\N	f	\N	4	\N	2026-05-12 05:28:36.786	2026-05-12 05:28:36.786
165	1	1	22	DEMO0165	Nneka Yusuf	08034282716	\N	premium	3	5	0	0	\N	pending	unpaid	14500.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-06-07 05:28:36.792	2026-06-07 05:28:36.792
166	1	1	10	DEMO0166	Yusuf Abubakar	08094403256	\N	premium	7	5	0	0	\N	processing	unpaid	20500.00	\N	\N	0.00	\N	\N	f	\N	4	\N	2026-04-19 05:28:36.796	2026-04-19 05:28:36.796
167	1	1	20	DEMO0167	Chidi Babatunde	08032522120	\N	standard	6	3	6	3	\N	completed	paid	7800.00	\N	\N	7800.00	\N	\N	f	\N	4	\N	2026-03-25 05:28:36.799	2026-03-25 05:28:36.799
168	1	1	30	DEMO0168	Musa Obiora	08046404380	\N	premium	7	1	7	1	\N	completed	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	4	\N	2026-03-22 05:28:36.806	2026-03-22 05:28:36.806
169	1	1	5	DEMO0169	Kunle Usman	08059867953	\N	premium	1	0	0	0	\N	processing	partial	1500.00	\N	\N	855.00	\N	\N	f	\N	2	\N	2026-05-26 05:28:36.813	2026-05-26 05:28:36.813
170	1	1	18	DEMO0170	Emeka Obi	08071569633	\N	express	3	2	3	2	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	2	\N	2026-04-05 05:28:36.82	2026-04-05 05:28:36.82
171	1	1	36	DEMO0171	Adaeze Obiora	08041964471	\N	premium	8	2	8	2	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	3	\N	2026-04-18 05:28:36.827	2026-04-18 05:28:36.827
172	1	1	6	DEMO0172	Tobi Adeyemi	08086792288	\N	express	5	5	5	5	\N	completed	partial	13500.00	\N	\N	4860.00	\N	\N	f	\N	4	\N	2026-05-03 05:28:36.833	2026-05-03 05:28:36.833
173	1	1	13	DEMO0173	Nneka Nwachukwu	08018585635	\N	premium	4	1	0	0	\N	ready	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	1	\N	2026-04-12 05:28:36.84	2026-04-12 05:28:36.84
174	1	1	28	DEMO0174	Chiamaka Eze	08095458818	\N	standard	6	5	0	0	\N	pending	partial	9800.00	\N	\N	4998.00	\N	\N	f	\N	3	\N	2026-05-16 05:28:36.846	2026-05-16 05:28:36.846
175	1	1	3	DEMO0175	Emeka Adeyemi	08088886674	\N	standard	6	2	6	2	\N	completed	paid	6800.00	\N	\N	6800.00	\N	\N	f	\N	4	\N	2026-03-11 05:28:36.853	2026-03-11 05:28:36.853
176	1	1	16	DEMO0176	Nkechi Okafor	08028383023	\N	standard	5	1	5	1	\N	completed	paid	5000.00	\N	\N	5000.00	\N	\N	f	\N	1	\N	2026-04-11 05:28:36.859	2026-04-11 05:28:36.859
177	1	1	32	DEMO0177	Obinna Okafor	08079042007	\N	express	2	0	0	0	\N	ready	partial	2400.00	\N	\N	840.00	\N	\N	f	\N	2	\N	2026-04-20 05:28:36.866	2026-04-20 05:28:36.866
178	1	1	30	DEMO0178	Musa Obiora	08046404380	\N	express	5	2	5	2	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	3	\N	2026-04-08 05:28:36.873	2026-04-08 05:28:36.873
179	1	1	17	DEMO0179	Sule Okonkwo	08084694472	\N	standard	8	3	0	0	\N	pending	partial	9400.00	\N	\N	4418.00	\N	\N	f	\N	1	\N	2026-06-03 05:28:36.881	2026-06-03 05:28:36.881
180	1	1	8	DEMO0180	Fatima Adeyemi	08073395153	\N	premium	5	1	0	0	\N	pending	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	3	\N	2026-05-26 05:28:36.887	2026-05-26 05:28:36.887
181	1	1	27	DEMO0181	Tunde Chukwu	08025640703	\N	premium	4	0	4	0	\N	completed	paid	6000.00	\N	\N	6000.00	\N	\N	f	\N	4	\N	2026-03-27 05:28:36.896	2026-03-27 05:28:36.896
182	1	1	10	DEMO0182	Yusuf Abubakar	08094403256	\N	express	4	3	0	0	\N	ready	partial	9300.00	\N	1449.00	4836.00	\N	\N	f	\N	2	\N	2026-04-10 05:28:36.902	2026-04-10 05:28:36.902
183	1	1	23	DEMO0183	Tunde Babatunde	08068772425	\N	express	8	2	0	0	\N	processing	paid	12600.00	\N	\N	12600.00	\N	\N	f	\N	3	\N	2026-04-18 05:28:36.918	2026-04-18 05:28:36.918
184	1	1	8	DEMO0184	Fatima Adeyemi	08073395153	\N	express	7	5	0	0	\N	pending	partial	15900.00	\N	\N	10017.00	\N	\N	f	\N	1	\N	2026-05-15 05:28:36.924	2026-05-15 05:28:36.924
185	1	1	31	DEMO0185	Chioma Nwachukwu	08042444264	\N	standard	5	2	5	2	\N	completed	paid	6000.00	\N	\N	6000.00	\N	\N	f	\N	2	\N	2026-03-13 05:28:36.933	2026-03-13 05:28:36.933
186	1	1	29	DEMO0186	Nkechi Yusuf	08025745890	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	2	\N	2026-03-11 05:28:36.939	2026-03-11 05:28:36.939
187	1	1	37	DEMO0187	Chiamaka Okafor	08067605933	\N	standard	2	5	2	5	\N	completed	partial	6600.00	\N	\N	4092.00	\N	\N	f	\N	1	\N	2026-04-03 05:28:36.946	2026-04-03 05:28:36.946
188	1	1	23	DEMO0188	Tunde Babatunde	08068772425	\N	express	7	2	0	0	\N	processing	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	2	\N	2026-05-13 05:28:36.952	2026-05-13 05:28:36.952
189	1	1	36	DEMO0189	Adaeze Obiora	08041964471	\N	standard	7	3	0	0	\N	pending	paid	8600.00	\N	489.00	8600.00	\N	\N	f	\N	3	\N	2026-05-09 05:28:36.96	2026-05-09 05:28:36.96
190	1	1	10	DEMO0190	Yusuf Abubakar	08094403256	\N	express	2	2	2	2	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	3	\N	2026-03-20 05:28:36.971	2026-03-20 05:28:36.971
191	1	1	13	DEMO0191	Nneka Nwachukwu	08018585635	\N	express	1	0	0	0	\N	pending	paid	1200.00	\N	\N	1200.00	\N	\N	f	\N	2	\N	2026-05-30 05:28:36.977	2026-05-30 05:28:36.977
192	1	1	38	DEMO0192	Halima Eze	08084775440	\N	express	1	1	0	0	\N	pending	partial	2700.00	\N	\N	1782.00	\N	\N	f	\N	1	\N	2026-05-24 05:28:36.986	2026-05-24 05:28:36.986
193	1	1	32	DEMO0193	Obinna Okafor	08079042007	\N	standard	6	2	6	2	\N	completed	paid	6800.00	\N	\N	6800.00	\N	\N	f	\N	1	\N	2026-04-02 05:28:36.992	2026-04-02 05:28:36.992
194	1	1	36	DEMO0194	Adaeze Obiora	08041964471	\N	express	6	4	0	0	\N	pending	partial	13200.00	\N	653.00	4092.00	\N	\N	f	\N	1	\N	2026-05-29 05:28:36.998	2026-05-29 05:28:36.998
195	1	1	33	DEMO0195	Chiamaka Okonkwo	08062671217	\N	express	5	1	5	1	\N	completed	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	2	\N	2026-03-16 05:28:37.013	2026-03-16 05:28:37.013
196	1	1	4	DEMO0196	Emeka Abubakar	08072644757	\N	standard	8	5	0	0	\N	processing	partial	11400.00	\N	\N	4560.00	\N	\N	f	\N	3	\N	2026-04-29 05:28:37.022	2026-04-29 05:28:37.022
197	1	1	14	DEMO0197	Tunde Adeyemi	08023848910	\N	standard	6	3	0	0	\N	pending	unpaid	7800.00	\N	\N	0.00	\N	\N	f	\N	3	\N	2026-06-05 05:28:37.028	2026-06-05 05:28:37.028
198	1	1	7	DEMO0198	Ada Musa	08037503969	\N	premium	6	0	6	0	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	1	\N	2026-04-10 05:28:37.032	2026-04-10 05:28:37.032
199	1	1	25	DEMO0199	Damilola Musa	08055380232	\N	express	4	1	4	1	\N	completed	paid	6300.00	\N	\N	6300.00	\N	\N	f	\N	2	\N	2026-03-30 05:28:37.038	2026-03-30 05:28:37.038
200	1	1	27	DEMO0200	Tunde Chukwu	08025640703	\N	standard	2	4	2	4	\N	completed	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	2	\N	2026-03-27 05:28:37.045	2026-03-27 05:28:37.045
201	1	2	41	DEMO0201	Sule Alabi	08094647361	\N	express	4	5	4	5	\N	completed	paid	12300.00	\N	\N	12300.00	\N	\N	f	\N	8	\N	2026-03-22 05:28:37.121	2026-03-22 05:28:37.121
202	1	2	51	DEMO0202	Halima Musa	08011553725	\N	express	4	3	4	3	\N	completed	paid	9300.00	\N	\N	9300.00	\N	\N	f	\N	6	\N	2026-03-12 05:28:37.127	2026-03-12 05:28:37.127
203	1	2	76	DEMO0203	Fatima Adeyemi	08084024242	\N	standard	5	2	5	2	\N	completed	paid	6000.00	\N	\N	6000.00	\N	\N	f	\N	7	\N	2026-04-04 05:28:37.132	2026-04-04 05:28:37.132
204	1	2	55	DEMO0204	Nkechi Musa	08054274568	\N	premium	5	5	0	0	\N	processing	partial	17500.00	\N	\N	7000.00	\N	\N	f	\N	6	\N	2026-05-28 05:28:37.139	2026-05-28 05:28:37.139
205	1	2	79	DEMO0205	Olu Alabi	08028712671	\N	premium	8	1	8	1	\N	completed	paid	14000.00	\N	\N	14000.00	\N	\N	f	\N	6	\N	2026-03-23 05:28:37.145	2026-03-23 05:28:37.145
206	1	2	66	DEMO0206	Blessing Lawal	08025636217	\N	express	4	0	0	0	\N	processing	partial	4800.00	\N	\N	2688.00	\N	\N	f	\N	6	\N	2026-04-11 05:28:37.152	2026-04-11 05:28:37.152
207	1	2	60	DEMO0207	Amaka Okonkwo	08079916348	\N	express	3	0	0	0	\N	ready	paid	3600.00	\N	252.00	3600.00	\N	\N	f	\N	7	\N	2026-05-30 05:28:37.158	2026-05-30 05:28:37.158
208	1	2	43	DEMO0208	Olu Ogundele	08015800732	\N	premium	7	3	7	3	\N	completed	paid	16500.00	\N	\N	16500.00	\N	\N	f	\N	5	\N	2026-04-01 05:28:37.169	2026-04-01 05:28:37.169
209	1	2	44	DEMO0209	Blessing Bello	08084652076	\N	express	2	1	0	0	\N	ready	unpaid	3900.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-04-15 05:28:37.178	2026-04-15 05:28:37.178
210	1	2	67	DEMO0210	Kunle Adeyemi	08015661222	\N	premium	2	1	0	0	\N	pending	partial	5000.00	\N	\N	1900.00	\N	\N	f	\N	6	\N	2026-05-09 05:28:37.182	2026-05-09 05:28:37.182
211	1	2	58	DEMO0211	Babajide Bello	08081020731	\N	express	8	5	8	5	\N	completed	paid	17100.00	\N	439.00	17100.00	\N	\N	f	\N	8	\N	2026-04-03 05:28:37.188	2026-04-03 05:28:37.188
212	1	2	42	DEMO0212	Chidi Usman	08055963053	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	\N	15500.00	\N	\N	f	\N	6	\N	2026-05-05 05:28:37.203	2026-05-05 05:28:37.203
213	1	2	49	DEMO0213	Olu Musa	08028020192	\N	standard	6	4	6	4	\N	completed	paid	8800.00	\N	\N	8800.00	\N	\N	f	\N	7	\N	2026-03-30 05:28:37.213	2026-03-30 05:28:37.213
214	1	2	59	DEMO0214	Chidi Ogundele	08088400079	\N	express	1	4	1	4	\N	completed	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	5	\N	2026-04-02 05:28:37.22	2026-04-02 05:28:37.22
215	1	2	54	DEMO0215	Fatima Abubakar	08027092518	\N	standard	3	3	3	3	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	6	\N	2026-03-14 05:28:37.235	2026-03-14 05:28:37.235
216	1	2	62	DEMO0216	Gbenga Adeyemi	08061389499	\N	express	5	5	0	0	\N	processing	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	6	\N	2026-04-10 05:28:37.242	2026-04-10 05:28:37.242
217	1	2	46	DEMO0217	Nkechi Bello	08092319821	\N	premium	3	3	0	0	\N	processing	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	8	\N	2026-05-17 05:28:37.248	2026-05-17 05:28:37.248
218	1	2	48	DEMO0218	Tunde Bello	08023750820	\N	express	7	4	7	4	\N	completed	paid	14400.00	\N	\N	14400.00	\N	\N	f	\N	8	\N	2026-04-02 05:28:37.254	2026-04-02 05:28:37.254
219	1	2	75	DEMO0219	Chiamaka Eze	08097117142	\N	standard	8	4	8	4	\N	completed	paid	10400.00	\N	\N	10400.00	\N	\N	f	\N	5	\N	2026-03-17 05:28:37.267	2026-03-17 05:28:37.267
220	1	2	79	DEMO0220	Olu Alabi	08028712671	\N	express	2	4	0	0	\N	ready	paid	8400.00	\N	\N	8400.00	\N	\N	f	\N	5	\N	2026-05-25 05:28:37.274	2026-05-25 05:28:37.274
221	1	2	69	DEMO0221	Seun Musa	08031014683	\N	express	3	0	3	0	\N	completed	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	7	\N	2026-03-27 05:28:37.281	2026-03-27 05:28:37.281
222	1	2	74	DEMO0222	Chioma Nwosu	08068715571	\N	express	4	4	0	0	\N	processing	paid	10800.00	\N	\N	10800.00	\N	\N	f	\N	7	\N	2026-05-27 05:28:37.288	2026-05-27 05:28:37.288
223	1	2	52	DEMO0223	Yusuf Eze	08031855766	\N	standard	4	3	0	0	\N	ready	unpaid	6200.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-04-19 05:28:37.294	2026-04-19 05:28:37.294
224	1	2	72	DEMO0224	Obinna Babatunde	08030376043	\N	premium	1	0	1	0	\N	completed	paid	1500.00	\N	\N	1500.00	\N	\N	f	\N	5	\N	2026-03-23 05:28:37.301	2026-03-23 05:28:37.301
225	1	2	69	DEMO0225	Seun Musa	08031014683	\N	premium	8	5	0	0	\N	processing	partial	22000.00	\N	\N	7040.00	\N	\N	f	\N	6	\N	2026-05-18 05:28:37.306	2026-05-18 05:28:37.306
226	1	2	42	DEMO0226	Chidi Usman	08055963053	\N	premium	3	4	3	4	\N	completed	paid	12500.00	\N	1331.00	12500.00	\N	\N	f	\N	7	\N	2026-03-29 05:28:37.312	2026-03-29 05:28:37.312
227	1	2	79	DEMO0227	Olu Alabi	08028712671	\N	standard	7	4	0	0	\N	processing	unpaid	9600.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-04-20 05:28:37.327	2026-04-20 05:28:37.327
228	1	2	77	DEMO0228	Nkechi Okonkwo	08053565013	\N	standard	4	4	0	0	\N	pending	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	5	\N	2026-06-01 05:28:37.331	2026-06-01 05:28:37.331
229	1	2	44	DEMO0229	Blessing Bello	08084652076	\N	express	3	0	3	0	\N	completed	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	5	\N	2026-03-10 05:28:37.341	2026-03-10 05:28:37.341
230	1	2	52	DEMO0230	Yusuf Eze	08031855766	\N	express	6	3	6	3	\N	completed	paid	11700.00	\N	\N	11700.00	\N	\N	f	\N	6	\N	2026-05-03 05:28:37.348	2026-05-03 05:28:37.348
231	1	2	79	DEMO0231	Olu Alabi	08028712671	\N	standard	5	0	0	0	\N	pending	paid	4000.00	\N	\N	4000.00	\N	\N	f	\N	7	\N	2026-05-25 05:28:37.357	2026-05-25 05:28:37.357
232	1	2	52	DEMO0232	Yusuf Eze	08031855766	\N	express	1	2	0	0	\N	pending	paid	4200.00	\N	\N	4200.00	\N	\N	f	\N	5	\N	2026-05-15 05:28:37.364	2026-05-15 05:28:37.364
233	1	2	65	DEMO0233	Yusuf Alabi	08046579600	\N	express	8	0	8	0	\N	completed	partial	9600.00	\N	\N	5952.00	\N	\N	f	\N	7	\N	2026-04-04 05:28:37.369	2026-04-04 05:28:37.369
234	1	2	50	DEMO0234	Ibrahim Nwosu	08075039269	\N	standard	7	1	7	1	\N	completed	partial	6600.00	\N	\N	3102.00	\N	\N	f	\N	8	\N	2026-03-20 05:28:37.375	2026-03-20 05:28:37.375
235	1	2	58	DEMO0235	Babajide Bello	08081020731	\N	premium	4	0	4	0	\N	completed	paid	6000.00	\N	191.00	6000.00	\N	\N	f	\N	6	\N	2026-04-28 05:28:37.382	2026-04-28 05:28:37.382
236	1	2	47	DEMO0236	Gbenga Abubakar	08094121458	\N	express	7	0	7	0	\N	completed	paid	8400.00	\N	686.00	8400.00	\N	\N	f	\N	6	\N	2026-03-15 05:28:37.394	2026-03-15 05:28:37.394
237	1	2	44	DEMO0237	Blessing Bello	08084652076	\N	premium	7	0	0	0	\N	ready	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	5	\N	2026-04-19 05:28:37.408	2026-04-19 05:28:37.408
238	1	2	72	DEMO0238	Obinna Babatunde	08030376043	\N	premium	6	4	0	0	\N	processing	paid	17000.00	\N	\N	17000.00	\N	\N	f	\N	7	\N	2026-04-23 05:28:37.415	2026-04-23 05:28:37.415
239	1	2	66	DEMO0239	Blessing Lawal	08025636217	\N	premium	7	5	0	0	\N	processing	paid	20500.00	\N	\N	20500.00	\N	\N	f	\N	6	\N	2026-05-26 05:28:37.422	2026-05-26 05:28:37.422
240	1	2	48	DEMO0240	Tunde Bello	08023750820	\N	standard	6	1	0	0	\N	ready	paid	5800.00	\N	\N	5800.00	\N	\N	f	\N	5	\N	2026-05-09 05:28:37.428	2026-05-09 05:28:37.428
241	1	2	56	DEMO0241	Damilola Okonkwo	08079323913	\N	standard	5	5	0	0	\N	ready	unpaid	9000.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-05-14 05:28:37.434	2026-05-14 05:28:37.434
242	1	2	42	DEMO0242	Chidi Usman	08055963053	\N	premium	5	3	0	0	\N	pending	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	8	\N	2026-06-04 05:28:37.438	2026-06-04 05:28:37.438
243	1	2	45	DEMO0243	Olu Ogundele	08090281268	\N	standard	1	2	0	0	\N	ready	unpaid	2800.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-04-21 05:28:37.444	2026-04-21 05:28:37.444
244	1	2	52	DEMO0244	Yusuf Eze	08031855766	\N	standard	2	0	2	0	\N	completed	partial	1600.00	\N	410.00	928.00	\N	\N	f	\N	6	\N	2026-04-04 05:28:37.447	2026-04-04 05:28:37.447
245	1	2	76	DEMO0245	Fatima Adeyemi	08084024242	\N	premium	1	4	0	0	\N	ready	partial	9500.00	\N	\N	4845.00	\N	\N	f	\N	5	\N	2026-04-22 05:28:37.459	2026-04-22 05:28:37.459
246	1	2	56	DEMO0246	Damilola Okonkwo	08079323913	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	\N	15500.00	\N	\N	f	\N	8	\N	2026-04-05 05:28:37.465	2026-04-05 05:28:37.465
247	1	2	46	DEMO0247	Nkechi Bello	08092319821	\N	standard	7	5	7	5	\N	completed	partial	10600.00	\N	972.00	7208.00	\N	\N	f	\N	6	\N	2026-03-31 05:28:37.471	2026-03-31 05:28:37.471
248	1	2	74	DEMO0248	Chioma Nwosu	08068715571	\N	standard	8	4	0	0	\N	processing	unpaid	10400.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-04-19 05:28:37.486	2026-04-19 05:28:37.486
249	1	2	63	DEMO0249	Nkechi Danjuma	08095946436	\N	premium	3	3	0	0	\N	ready	paid	10500.00	\N	620.00	10500.00	\N	\N	f	\N	6	\N	2026-05-05 05:28:37.489	2026-05-05 05:28:37.489
250	1	2	80	DEMO0250	Yusuf Musa	08017305332	\N	standard	1	1	0	0	\N	processing	paid	1800.00	\N	\N	1800.00	\N	\N	f	\N	7	\N	2026-04-24 05:28:37.504	2026-04-24 05:28:37.504
251	1	2	79	DEMO0251	Olu Alabi	08028712671	\N	express	1	3	1	3	\N	completed	paid	5700.00	\N	270.00	5700.00	\N	\N	f	\N	5	\N	2026-03-09 05:28:37.51	2026-03-09 05:28:37.51
252	1	2	73	DEMO0252	Blessing Chukwu	08084910590	\N	standard	8	0	0	0	\N	pending	paid	6400.00	\N	281.00	6400.00	\N	\N	f	\N	6	\N	2026-05-16 05:28:37.525	2026-05-16 05:28:37.525
253	1	2	60	DEMO0253	Amaka Okonkwo	08079916348	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	\N	15500.00	\N	\N	f	\N	6	\N	2026-05-05 05:28:37.538	2026-05-05 05:28:37.538
254	1	2	44	DEMO0254	Blessing Bello	08084652076	\N	premium	6	2	6	2	\N	completed	paid	13000.00	\N	1047.00	13000.00	\N	\N	f	\N	6	\N	2026-04-12 05:28:37.544	2026-04-12 05:28:37.544
255	1	2	68	DEMO0255	Chidi Obiora	08092428328	\N	express	8	5	0	0	\N	ready	partial	17100.00	\N	\N	7524.00	\N	\N	f	\N	8	\N	2026-04-29 05:28:37.559	2026-04-29 05:28:37.559
256	1	2	59	DEMO0256	Chidi Ogundele	08088400079	\N	premium	1	1	0	0	\N	processing	paid	3500.00	\N	\N	3500.00	\N	\N	f	\N	6	\N	2026-04-29 05:28:37.565	2026-04-29 05:28:37.565
257	1	2	54	DEMO0257	Fatima Abubakar	08027092518	\N	standard	7	1	7	1	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	5	\N	2026-03-19 05:28:37.571	2026-03-19 05:28:37.571
258	1	2	76	DEMO0258	Fatima Adeyemi	08084024242	\N	standard	4	0	4	0	\N	completed	paid	3200.00	\N	\N	3200.00	\N	\N	f	\N	5	\N	2026-03-10 05:28:37.576	2026-03-10 05:28:37.576
259	1	2	72	DEMO0259	Obinna Babatunde	08030376043	\N	premium	8	5	8	5	\N	completed	partial	22000.00	\N	\N	15180.00	\N	\N	f	\N	6	\N	2026-03-24 05:28:37.586	2026-03-24 05:28:37.586
260	1	2	67	DEMO0260	Kunle Adeyemi	08015661222	\N	standard	8	3	8	3	\N	completed	paid	9400.00	\N	\N	9400.00	\N	\N	f	\N	8	\N	2026-03-28 05:28:37.591	2026-03-28 05:28:37.591
261	1	2	79	DEMO0261	Olu Alabi	08028712671	\N	premium	1	2	1	2	\N	completed	paid	5500.00	\N	\N	5500.00	\N	\N	f	\N	8	\N	2026-03-18 05:28:37.601	2026-03-18 05:28:37.601
262	1	2	71	DEMO0262	Ifeoma Ogundele	08046268563	\N	standard	8	1	8	1	\N	completed	partial	7400.00	\N	\N	2442.00	\N	\N	f	\N	6	\N	2026-05-06 05:28:37.606	2026-05-06 05:28:37.606
263	1	2	49	DEMO0263	Olu Musa	08028020192	\N	standard	6	4	0	0	\N	processing	unpaid	8800.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-04-24 05:28:37.617	2026-04-24 05:28:37.617
264	1	2	47	DEMO0264	Gbenga Abubakar	08094121458	\N	standard	3	4	0	0	\N	pending	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	7	\N	2026-05-13 05:28:37.621	2026-05-13 05:28:37.621
265	1	2	80	DEMO0265	Yusuf Musa	08017305332	\N	premium	8	0	8	0	\N	completed	partial	12000.00	\N	\N	8280.00	\N	\N	f	\N	7	\N	2026-05-01 05:28:37.627	2026-05-01 05:28:37.627
266	1	2	58	DEMO0266	Babajide Bello	08081020731	\N	premium	3	1	0	0	\N	ready	unpaid	6500.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-04-30 05:28:37.633	2026-04-30 05:28:37.633
267	1	2	67	DEMO0267	Kunle Adeyemi	08015661222	\N	express	5	0	0	0	\N	processing	unpaid	6000.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-05-14 05:28:37.636	2026-05-14 05:28:37.636
268	1	2	75	DEMO0268	Chiamaka Eze	08097117142	\N	premium	3	4	0	0	\N	processing	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	8	\N	2026-05-31 05:28:37.64	2026-05-31 05:28:37.64
269	1	2	80	DEMO0269	Yusuf Musa	08017305332	\N	express	6	4	6	4	\N	completed	paid	13200.00	\N	\N	13200.00	\N	\N	f	\N	7	\N	2026-03-12 05:28:37.647	2026-03-12 05:28:37.647
270	1	2	50	DEMO0270	Ibrahim Nwosu	08075039269	\N	standard	7	1	0	0	\N	ready	partial	6600.00	\N	\N	2178.00	\N	\N	f	\N	5	\N	2026-05-07 05:28:37.654	2026-05-07 05:28:37.654
271	1	2	68	DEMO0271	Chidi Obiora	08092428328	\N	premium	8	3	8	3	\N	completed	paid	18000.00	\N	\N	18000.00	\N	\N	f	\N	6	\N	2026-04-04 05:28:37.659	2026-04-04 05:28:37.659
272	1	2	45	DEMO0272	Olu Ogundele	08090281268	\N	standard	7	3	0	0	\N	pending	unpaid	8600.00	\N	944.00	0.00	\N	\N	f	\N	5	\N	2026-05-24 05:28:37.665	2026-05-24 05:28:37.665
273	1	2	58	DEMO0273	Babajide Bello	08081020731	\N	express	8	0	8	0	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	7	\N	2026-05-02 05:28:37.677	2026-05-02 05:28:37.677
274	1	2	80	DEMO0274	Yusuf Musa	08017305332	\N	standard	8	0	0	0	\N	pending	partial	6400.00	\N	\N	1920.00	\N	\N	f	\N	5	\N	2026-06-03 05:28:37.683	2026-06-03 05:28:37.683
275	1	2	42	DEMO0275	Chidi Usman	08055963053	\N	express	6	1	6	1	\N	completed	partial	8700.00	\N	\N	3306.00	\N	\N	f	\N	7	\N	2026-04-21 05:28:37.693	2026-04-21 05:28:37.693
276	1	2	71	DEMO0276	Ifeoma Ogundele	08046268563	\N	standard	4	5	0	0	\N	ready	partial	8200.00	\N	\N	5494.00	\N	\N	f	\N	7	\N	2026-05-15 05:28:37.7	2026-05-15 05:28:37.7
277	1	2	75	DEMO0277	Chiamaka Eze	08097117142	\N	express	1	2	1	2	\N	completed	partial	4200.00	\N	\N	2478.00	\N	\N	f	\N	7	\N	2026-03-14 05:28:37.71	2026-03-14 05:28:37.71
278	1	2	53	DEMO0278	Musa Obi	08080235318	\N	premium	6	0	0	0	\N	ready	partial	9000.00	\N	\N	4950.00	\N	\N	f	\N	7	\N	2026-04-24 05:28:37.717	2026-04-24 05:28:37.717
279	1	2	65	DEMO0279	Yusuf Alabi	08046579600	\N	express	1	1	0	0	\N	processing	paid	2700.00	\N	\N	2700.00	\N	\N	f	\N	8	\N	2026-06-06 05:28:37.727	2026-06-06 05:28:37.727
280	1	2	71	DEMO0280	Ifeoma Ogundele	08046268563	\N	standard	1	2	0	0	\N	processing	unpaid	2800.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-05-04 05:28:37.733	2026-05-04 05:28:37.733
281	1	2	79	DEMO0281	Olu Alabi	08028712671	\N	express	8	1	8	1	\N	completed	paid	11100.00	\N	\N	11100.00	\N	\N	f	\N	6	\N	2026-04-05 05:28:37.736	2026-04-05 05:28:37.736
282	1	2	47	DEMO0282	Gbenga Abubakar	08094121458	\N	express	5	4	0	0	\N	processing	unpaid	12000.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-06-03 05:28:37.742	2026-06-03 05:28:37.742
283	1	2	62	DEMO0283	Gbenga Adeyemi	08061389499	\N	standard	5	5	0	0	\N	processing	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	7	\N	2026-05-15 05:28:37.748	2026-05-15 05:28:37.748
284	1	2	59	DEMO0284	Chidi Ogundele	08088400079	\N	express	4	2	0	0	\N	ready	partial	7800.00	\N	\N	5304.00	\N	\N	f	\N	6	\N	2026-05-09 05:28:37.754	2026-05-09 05:28:37.754
285	1	2	72	DEMO0285	Obinna Babatunde	08030376043	\N	premium	4	0	0	0	\N	ready	partial	6000.00	\N	\N	3660.00	\N	\N	f	\N	6	\N	2026-05-16 05:28:37.76	2026-05-16 05:28:37.76
286	1	2	72	DEMO0286	Obinna Babatunde	08030376043	\N	premium	2	4	0	0	\N	processing	paid	11000.00	\N	\N	11000.00	\N	\N	f	\N	5	\N	2026-05-02 05:28:37.768	2026-05-02 05:28:37.768
287	1	2	67	DEMO0287	Kunle Adeyemi	08015661222	\N	premium	2	4	0	0	\N	processing	partial	11000.00	\N	\N	7700.00	\N	\N	f	\N	6	\N	2026-05-14 05:28:37.774	2026-05-14 05:28:37.774
288	1	2	51	DEMO0288	Halima Musa	08011553725	\N	premium	4	0	4	0	\N	completed	paid	6000.00	\N	\N	6000.00	\N	\N	f	\N	5	\N	2026-03-16 05:28:37.78	2026-03-16 05:28:37.78
289	1	2	61	DEMO0289	Sule Obiora	08043519463	\N	premium	3	2	3	2	\N	completed	paid	8500.00	\N	\N	8500.00	\N	\N	f	\N	6	\N	2026-03-22 05:28:37.788	2026-03-22 05:28:37.788
290	1	2	73	DEMO0290	Blessing Chukwu	08084910590	\N	express	3	1	0	0	\N	pending	partial	5100.00	\N	\N	2652.00	\N	\N	f	\N	6	\N	2026-06-01 05:28:37.794	2026-06-01 05:28:37.794
291	1	2	73	DEMO0291	Blessing Chukwu	08084910590	\N	premium	6	4	0	0	\N	pending	partial	17000.00	\N	\N	9010.00	\N	\N	f	\N	5	\N	2026-06-04 05:28:37.8	2026-06-04 05:28:37.8
292	1	2	73	DEMO0292	Blessing Chukwu	08084910590	\N	premium	1	5	0	0	\N	processing	paid	11500.00	\N	\N	11500.00	\N	\N	f	\N	6	\N	2026-04-20 05:28:37.806	2026-04-20 05:28:37.806
293	1	2	45	DEMO0293	Olu Ogundele	08090281268	\N	express	7	4	7	4	\N	completed	paid	14400.00	\N	\N	14400.00	\N	\N	f	\N	6	\N	2026-04-26 05:28:37.812	2026-04-26 05:28:37.812
294	1	2	78	DEMO0294	Tobi Nwachukwu	08050293292	\N	premium	7	2	0	0	\N	ready	partial	14500.00	\N	\N	9425.00	\N	\N	f	\N	5	\N	2026-05-16 05:28:37.818	2026-05-16 05:28:37.818
295	1	2	47	DEMO0295	Gbenga Abubakar	08094121458	\N	premium	8	3	8	3	\N	completed	paid	18000.00	\N	\N	18000.00	\N	\N	f	\N	5	\N	2026-04-07 05:28:37.824	2026-04-07 05:28:37.824
296	1	2	51	DEMO0296	Halima Musa	08011553725	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	530.00	6400.00	\N	\N	f	\N	5	\N	2026-04-10 05:28:37.831	2026-04-10 05:28:37.831
297	1	2	56	DEMO0297	Damilola Okonkwo	08079323913	\N	standard	2	1	0	0	\N	ready	partial	2600.00	\N	\N	962.00	\N	\N	f	\N	7	\N	2026-04-24 05:28:37.846	2026-04-24 05:28:37.846
298	1	2	64	DEMO0298	Tobi Abubakar	08092902220	\N	premium	8	1	8	1	\N	completed	paid	14000.00	\N	\N	14000.00	\N	\N	f	\N	7	\N	2026-03-31 05:28:37.852	2026-03-31 05:28:37.852
299	1	2	66	DEMO0299	Blessing Lawal	08025636217	\N	premium	2	0	0	0	\N	pending	unpaid	3000.00	\N	390.00	0.00	\N	\N	f	\N	5	\N	2026-05-23 05:28:37.859	2026-05-23 05:28:37.859
300	1	2	71	DEMO0300	Ifeoma Ogundele	08046268563	\N	premium	4	5	4	5	\N	completed	paid	16000.00	\N	364.00	16000.00	\N	\N	f	\N	7	\N	2026-03-26 05:28:37.867	2026-03-26 05:28:37.867
301	1	2	60	DEMO0301	Amaka Okonkwo	08079916348	\N	express	7	4	7	4	\N	completed	paid	14400.00	\N	\N	14400.00	\N	\N	f	\N	5	\N	2026-03-19 05:28:37.881	2026-03-19 05:28:37.881
302	1	2	49	DEMO0302	Olu Musa	08028020192	\N	express	5	1	0	0	\N	ready	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	7	\N	2026-04-24 05:28:37.887	2026-04-24 05:28:37.887
303	1	2	62	DEMO0303	Gbenga Adeyemi	08061389499	\N	express	4	5	4	5	\N	completed	paid	12300.00	\N	\N	12300.00	\N	\N	f	\N	8	\N	2026-03-29 05:28:37.894	2026-03-29 05:28:37.894
304	1	2	51	DEMO0304	Halima Musa	08011553725	\N	standard	4	4	4	4	\N	completed	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	6	\N	2026-04-05 05:28:37.9	2026-04-05 05:28:37.9
305	1	2	43	DEMO0305	Olu Ogundele	08015800732	\N	premium	1	5	0	0	\N	processing	partial	11500.00	\N	\N	6440.00	\N	\N	f	\N	8	\N	2026-05-19 05:28:37.907	2026-05-19 05:28:37.907
306	1	2	57	DEMO0306	Blessing Abubakar	08037354832	\N	express	1	4	1	4	\N	completed	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	8	\N	2026-04-21 05:28:37.915	2026-04-21 05:28:37.915
307	1	2	64	DEMO0307	Tobi Abubakar	08092902220	\N	express	3	4	0	0	\N	pending	partial	9600.00	\N	\N	3264.00	\N	\N	f	\N	6	\N	2026-06-02 05:28:37.922	2026-06-02 05:28:37.922
308	1	2	55	DEMO0308	Nkechi Musa	08054274568	\N	standard	7	2	0	0	\N	processing	paid	7600.00	\N	122.00	7600.00	\N	\N	f	\N	6	\N	2026-05-26 05:28:37.928	2026-05-26 05:28:37.928
309	1	2	65	DEMO0309	Yusuf Alabi	08046579600	\N	standard	4	3	4	3	\N	completed	paid	6200.00	\N	\N	6200.00	\N	\N	f	\N	5	\N	2026-03-19 05:28:37.941	2026-03-19 05:28:37.941
310	1	2	49	DEMO0310	Olu Musa	08028020192	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	6	\N	2026-03-17 05:28:37.947	2026-03-17 05:28:37.947
311	1	2	68	DEMO0311	Chidi Obiora	08092428328	\N	express	6	4	0	0	\N	pending	partial	13200.00	\N	\N	5280.00	\N	\N	f	\N	7	\N	2026-05-28 05:28:37.953	2026-05-28 05:28:37.953
312	1	2	66	DEMO0312	Blessing Lawal	08025636217	\N	premium	5	3	5	3	\N	completed	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	8	\N	2026-03-14 05:28:37.959	2026-03-14 05:28:37.959
313	1	2	49	DEMO0313	Olu Musa	08028020192	\N	express	3	0	3	0	\N	completed	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	8	\N	2026-04-28 05:28:37.966	2026-04-28 05:28:37.966
314	1	2	61	DEMO0314	Sule Obiora	08043519463	\N	express	8	1	0	0	\N	processing	paid	11100.00	\N	\N	11100.00	\N	\N	f	\N	7	\N	2026-05-03 05:28:37.973	2026-05-03 05:28:37.973
315	1	2	80	DEMO0315	Yusuf Musa	08017305332	\N	express	5	1	0	0	\N	pending	unpaid	7500.00	\N	\N	0.00	\N	\N	f	\N	5	\N	2026-05-11 05:28:37.98	2026-05-11 05:28:37.98
316	1	2	70	DEMO0316	Gbenga Danjuma	08014398740	\N	standard	3	5	3	5	\N	completed	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	6	\N	2026-03-17 05:28:37.983	2026-03-17 05:28:37.983
317	1	2	78	DEMO0317	Tobi Nwachukwu	08050293292	\N	premium	7	4	0	0	\N	processing	unpaid	18500.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-06-02 05:28:37.99	2026-06-02 05:28:37.99
318	1	2	58	DEMO0318	Babajide Bello	08081020731	\N	standard	5	3	0	0	\N	processing	partial	7000.00	\N	\N	4480.00	\N	\N	f	\N	6	\N	2026-05-06 05:28:37.993	2026-05-06 05:28:37.993
319	1	2	69	DEMO0319	Seun Musa	08031014683	\N	express	3	5	0	0	\N	processing	partial	11100.00	\N	\N	5439.00	\N	\N	f	\N	5	\N	2026-05-08 05:28:38.002	2026-05-08 05:28:38.002
320	1	2	72	DEMO0320	Obinna Babatunde	08030376043	\N	express	3	1	3	1	\N	completed	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	5	\N	2026-03-14 05:28:38.008	2026-03-14 05:28:38.008
321	1	2	45	DEMO0321	Olu Ogundele	08090281268	\N	premium	4	4	4	4	\N	completed	paid	14000.00	\N	\N	14000.00	\N	\N	f	\N	8	\N	2026-04-07 05:28:38.018	2026-04-07 05:28:38.018
322	1	2	63	DEMO0322	Nkechi Danjuma	08095946436	\N	standard	8	3	0	0	\N	processing	unpaid	9400.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-05-11 05:28:38.025	2026-05-11 05:28:38.025
323	1	2	60	DEMO0323	Amaka Okonkwo	08079916348	\N	standard	2	0	2	0	\N	completed	paid	1600.00	\N	164.00	1600.00	\N	\N	f	\N	7	\N	2026-04-06 05:28:38.029	2026-04-06 05:28:38.029
324	1	2	53	DEMO0324	Musa Obi	08080235318	\N	premium	7	3	0	0	\N	pending	partial	16500.00	\N	\N	11055.00	\N	\N	f	\N	5	\N	2026-05-30 05:28:38.041	2026-05-30 05:28:38.041
325	1	2	70	DEMO0325	Gbenga Danjuma	08014398740	\N	express	3	4	3	4	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	5	\N	2026-04-01 05:28:38.047	2026-04-01 05:28:38.047
326	1	2	67	DEMO0326	Kunle Adeyemi	08015661222	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	768.00	8600.00	\N	\N	f	\N	7	\N	2026-04-28 05:28:38.054	2026-04-28 05:28:38.054
327	1	2	61	DEMO0327	Sule Obiora	08043519463	\N	premium	4	5	4	5	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	8	\N	2026-03-28 05:28:38.07	2026-03-28 05:28:38.07
328	1	2	65	DEMO0328	Yusuf Alabi	08046579600	\N	standard	4	4	0	0	\N	processing	partial	7200.00	\N	983.00	2808.00	\N	\N	f	\N	5	\N	2026-06-06 05:28:38.077	2026-06-06 05:28:38.077
329	1	2	75	DEMO0329	Chiamaka Eze	08097117142	\N	premium	4	1	4	1	\N	completed	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	8	\N	2026-03-14 05:28:38.094	2026-03-14 05:28:38.094
330	1	2	63	DEMO0330	Nkechi Danjuma	08095946436	\N	standard	1	0	0	0	\N	processing	paid	800.00	\N	\N	800.00	\N	\N	f	\N	5	\N	2026-06-06 05:28:38.102	2026-06-06 05:28:38.102
331	1	2	57	DEMO0331	Blessing Abubakar	08037354832	\N	express	1	1	1	1	\N	completed	paid	2700.00	\N	\N	2700.00	\N	\N	f	\N	7	\N	2026-03-14 05:28:38.111	2026-03-14 05:28:38.111
332	1	2	59	DEMO0332	Chidi Ogundele	08088400079	\N	premium	8	0	0	0	\N	ready	partial	12000.00	\N	\N	3960.00	\N	\N	f	\N	7	\N	2026-04-28 05:28:38.118	2026-04-28 05:28:38.118
333	1	2	53	DEMO0333	Musa Obi	08080235318	\N	standard	1	4	1	4	\N	completed	paid	4800.00	\N	126.00	4800.00	\N	\N	f	\N	8	\N	2026-03-10 05:28:38.128	2026-03-10 05:28:38.128
334	1	2	69	DEMO0334	Seun Musa	08031014683	\N	express	4	2	0	0	\N	processing	paid	7800.00	\N	\N	7800.00	\N	\N	f	\N	8	\N	2026-05-27 05:28:38.141	2026-05-27 05:28:38.141
335	1	2	71	DEMO0335	Ifeoma Ogundele	08046268563	\N	standard	6	3	6	3	\N	completed	paid	7800.00	\N	\N	7800.00	\N	\N	f	\N	6	\N	2026-03-25 05:28:38.147	2026-03-25 05:28:38.147
336	1	2	47	DEMO0336	Gbenga Abubakar	08094121458	\N	standard	1	1	0	0	\N	processing	paid	1800.00	\N	\N	1800.00	\N	\N	f	\N	5	\N	2026-04-10 05:28:38.154	2026-04-10 05:28:38.154
337	1	2	53	DEMO0337	Musa Obi	08080235318	\N	standard	3	2	0	0	\N	ready	unpaid	4400.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-04-20 05:28:38.161	2026-04-20 05:28:38.161
338	1	2	72	DEMO0338	Obinna Babatunde	08030376043	\N	express	2	0	2	0	\N	completed	paid	2400.00	\N	320.00	2400.00	\N	\N	f	\N	5	\N	2026-03-24 05:28:38.164	2026-03-24 05:28:38.164
339	1	2	54	DEMO0339	Fatima Abubakar	08027092518	\N	express	4	5	4	5	\N	completed	paid	12300.00	\N	278.00	12300.00	\N	\N	f	\N	5	\N	2026-04-03 05:28:38.176	2026-04-03 05:28:38.176
340	1	2	56	DEMO0340	Damilola Okonkwo	08079323913	\N	standard	6	4	6	4	\N	completed	paid	8800.00	\N	\N	8800.00	\N	\N	f	\N	7	\N	2026-03-20 05:28:38.188	2026-03-20 05:28:38.188
341	1	2	44	DEMO0341	Blessing Bello	08084652076	\N	standard	5	3	5	3	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	8	\N	2026-03-17 05:28:38.194	2026-03-17 05:28:38.194
342	1	2	76	DEMO0342	Fatima Adeyemi	08084024242	\N	premium	8	0	0	0	\N	processing	unpaid	12000.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-04-18 05:28:38.199	2026-04-18 05:28:38.199
343	1	2	55	DEMO0343	Nkechi Musa	08054274568	\N	express	3	5	3	5	\N	completed	paid	11100.00	\N	726.00	11100.00	\N	\N	f	\N	5	\N	2026-04-07 05:28:38.203	2026-04-07 05:28:38.203
344	1	2	66	DEMO0344	Blessing Lawal	08025636217	\N	standard	1	3	1	3	\N	completed	paid	3800.00	\N	\N	3800.00	\N	\N	f	\N	7	\N	2026-03-17 05:28:38.216	2026-03-17 05:28:38.216
345	1	2	69	DEMO0345	Seun Musa	08031014683	\N	express	7	1	7	1	\N	completed	paid	9900.00	\N	884.00	9900.00	\N	\N	f	\N	8	\N	2026-03-18 05:28:38.222	2026-03-18 05:28:38.222
346	1	2	74	DEMO0346	Chioma Nwosu	08068715571	\N	premium	4	1	4	1	\N	completed	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	7	\N	2026-04-15 05:28:38.234	2026-04-15 05:28:38.234
347	1	2	70	DEMO0347	Gbenga Danjuma	08014398740	\N	express	4	5	0	0	\N	pending	partial	12300.00	\N	\N	6396.00	\N	\N	f	\N	5	\N	2026-05-26 05:28:38.24	2026-05-26 05:28:38.24
348	1	2	75	DEMO0348	Chiamaka Eze	08097117142	\N	express	7	3	0	0	\N	processing	partial	12900.00	\N	\N	3870.00	\N	\N	f	\N	6	\N	2026-04-26 05:28:38.245	2026-04-26 05:28:38.245
349	1	2	55	DEMO0349	Nkechi Musa	08054274568	\N	express	1	5	0	0	\N	pending	unpaid	8700.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-06-03 05:28:38.25	2026-06-03 05:28:38.25
350	1	2	72	DEMO0350	Obinna Babatunde	08030376043	\N	express	1	1	0	0	\N	processing	paid	2700.00	\N	\N	2700.00	\N	\N	f	\N	7	\N	2026-05-06 05:28:38.254	2026-05-06 05:28:38.254
351	1	2	61	DEMO0351	Sule Obiora	08043519463	\N	premium	2	5	2	5	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	5	\N	2026-05-04 05:28:38.259	2026-05-04 05:28:38.259
352	1	2	70	DEMO0352	Gbenga Danjuma	08014398740	\N	express	5	4	0	0	\N	processing	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	6	\N	2026-05-18 05:28:38.264	2026-05-18 05:28:38.264
353	1	2	73	DEMO0353	Blessing Chukwu	08084910590	\N	express	8	5	8	5	\N	completed	paid	17100.00	\N	\N	17100.00	\N	\N	f	\N	8	\N	2026-03-25 05:28:38.27	2026-03-25 05:28:38.27
354	1	2	68	DEMO0354	Chidi Obiora	08092428328	\N	standard	3	0	0	0	\N	processing	unpaid	2400.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-05-14 05:28:38.276	2026-05-14 05:28:38.276
355	1	2	59	DEMO0355	Chidi Ogundele	08088400079	\N	express	4	5	4	5	\N	completed	paid	12300.00	\N	\N	12300.00	\N	\N	f	\N	5	\N	2026-03-21 05:28:38.28	2026-03-21 05:28:38.28
356	1	2	46	DEMO0356	Nkechi Bello	08092319821	\N	express	2	2	0	0	\N	processing	unpaid	5400.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-04-15 05:28:38.287	2026-04-15 05:28:38.287
357	1	2	61	DEMO0357	Sule Obiora	08043519463	\N	standard	8	2	0	0	\N	processing	unpaid	8400.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-06-06 05:28:38.291	2026-06-06 05:28:38.291
358	1	2	70	DEMO0358	Gbenga Danjuma	08014398740	\N	express	6	4	0	0	\N	pending	partial	13200.00	\N	\N	4488.00	\N	\N	f	\N	8	\N	2026-06-06 05:28:38.295	2026-06-06 05:28:38.295
359	1	2	41	DEMO0359	Sule Alabi	08094647361	\N	standard	2	3	0	0	\N	processing	partial	4600.00	\N	\N	2438.00	\N	\N	f	\N	5	\N	2026-05-14 05:28:38.301	2026-05-14 05:28:38.301
360	1	2	50	DEMO0360	Ibrahim Nwosu	08075039269	\N	standard	1	3	0	0	\N	ready	unpaid	3800.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-04-26 05:28:38.308	2026-04-26 05:28:38.308
361	1	2	79	DEMO0361	Olu Alabi	08028712671	\N	premium	8	3	0	0	\N	processing	paid	18000.00	\N	\N	18000.00	\N	\N	f	\N	6	\N	2026-04-13 05:28:38.311	2026-04-13 05:28:38.311
362	1	2	69	DEMO0362	Seun Musa	08031014683	\N	standard	8	1	8	1	\N	completed	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	8	\N	2026-03-10 05:28:38.32	2026-03-10 05:28:38.32
363	1	2	79	DEMO0363	Olu Alabi	08028712671	\N	standard	7	4	7	4	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	7	\N	2026-04-21 05:28:38.326	2026-04-21 05:28:38.326
364	1	2	59	DEMO0364	Chidi Ogundele	08088400079	\N	premium	7	2	7	2	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	7	\N	2026-03-13 05:28:38.336	2026-03-13 05:28:38.336
365	1	2	61	DEMO0365	Sule Obiora	08043519463	\N	premium	3	0	0	0	\N	ready	partial	4500.00	\N	\N	1890.00	\N	\N	f	\N	7	\N	2026-05-09 05:28:38.343	2026-05-09 05:28:38.343
366	1	2	52	DEMO0366	Yusuf Eze	08031855766	\N	premium	2	5	0	0	\N	processing	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	5	\N	2026-04-17 05:28:38.352	2026-04-17 05:28:38.352
367	1	2	73	DEMO0367	Blessing Chukwu	08084910590	\N	standard	8	3	8	3	\N	completed	paid	9400.00	\N	\N	9400.00	\N	\N	f	\N	8	\N	2026-04-13 05:28:38.361	2026-04-13 05:28:38.361
368	1	2	78	DEMO0368	Tobi Nwachukwu	08050293292	\N	express	6	1	0	0	\N	ready	partial	8700.00	\N	250.00	4437.00	\N	\N	f	\N	6	\N	2026-05-22 05:28:38.367	2026-05-22 05:28:38.367
369	1	2	52	DEMO0369	Yusuf Eze	08031855766	\N	express	5	5	0	0	\N	processing	partial	13500.00	\N	\N	4860.00	\N	\N	f	\N	8	\N	2026-05-04 05:28:38.383	2026-05-04 05:28:38.383
370	1	2	51	DEMO0370	Halima Musa	08011553725	\N	premium	7	3	7	3	\N	completed	paid	16500.00	\N	\N	16500.00	\N	\N	f	\N	5	\N	2026-04-05 05:28:38.39	2026-04-05 05:28:38.39
371	1	2	79	DEMO0371	Olu Alabi	08028712671	\N	premium	3	2	3	2	\N	completed	partial	8500.00	\N	753.00	5950.00	\N	\N	f	\N	8	\N	2026-04-04 05:28:38.396	2026-04-04 05:28:38.396
372	1	2	43	DEMO0372	Olu Ogundele	08015800732	\N	express	2	4	0	0	\N	ready	unpaid	8400.00	\N	\N	0.00	\N	\N	f	\N	6	\N	2026-05-13 05:28:38.411	2026-05-13 05:28:38.411
373	1	2	51	DEMO0373	Halima Musa	08011553725	\N	express	7	5	0	0	\N	processing	partial	15900.00	\N	\N	5724.00	\N	\N	f	\N	6	\N	2026-04-10 05:28:38.416	2026-04-10 05:28:38.416
374	1	2	42	DEMO0374	Chidi Usman	08055963053	\N	premium	2	5	2	5	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	7	\N	2026-03-15 05:28:38.423	2026-03-15 05:28:38.423
375	1	2	80	DEMO0375	Yusuf Musa	08017305332	\N	premium	6	1	0	0	\N	processing	partial	11000.00	\N	\N	5940.00	\N	\N	f	\N	5	\N	2026-05-19 05:28:38.431	2026-05-19 05:28:38.431
376	1	2	76	DEMO0376	Fatima Adeyemi	08084024242	\N	premium	8	3	8	3	\N	completed	paid	18000.00	\N	\N	18000.00	\N	\N	f	\N	5	\N	2026-03-11 05:28:38.437	2026-03-11 05:28:38.437
377	1	2	59	DEMO0377	Chidi Ogundele	08088400079	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	\N	15500.00	\N	\N	f	\N	8	\N	2026-04-06 05:28:38.444	2026-04-06 05:28:38.444
378	1	2	73	DEMO0378	Blessing Chukwu	08084910590	\N	standard	5	4	0	0	\N	ready	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	6	\N	2026-04-27 05:28:38.452	2026-04-27 05:28:38.452
379	1	2	74	DEMO0379	Chioma Nwosu	08068715571	\N	express	4	2	0	0	\N	processing	paid	7800.00	\N	\N	7800.00	\N	\N	f	\N	6	\N	2026-04-19 05:28:38.458	2026-04-19 05:28:38.458
380	1	2	54	DEMO0380	Fatima Abubakar	08027092518	\N	standard	6	1	0	0	\N	pending	unpaid	5800.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-05-12 05:28:38.465	2026-05-12 05:28:38.465
381	1	2	67	DEMO0381	Kunle Adeyemi	08015661222	\N	express	7	5	0	0	\N	ready	unpaid	15900.00	\N	1078.00	0.00	\N	\N	f	\N	8	\N	2026-04-15 05:28:38.468	2026-04-15 05:28:38.468
382	1	2	61	DEMO0382	Sule Obiora	08043519463	\N	standard	8	0	0	0	\N	processing	unpaid	6400.00	\N	449.00	0.00	\N	\N	f	\N	8	\N	2026-05-25 05:28:38.481	2026-05-25 05:28:38.481
383	1	2	48	DEMO0383	Tunde Bello	08023750820	\N	express	7	4	0	0	\N	pending	partial	14400.00	\N	\N	9072.00	\N	\N	f	\N	6	\N	2026-05-21 05:28:38.49	2026-05-21 05:28:38.49
384	1	2	65	DEMO0384	Yusuf Alabi	08046579600	\N	express	6	5	6	5	\N	completed	paid	14700.00	\N	992.00	14700.00	\N	\N	f	\N	6	\N	2026-04-19 05:28:38.497	2026-04-19 05:28:38.497
385	1	2	58	DEMO0385	Babajide Bello	08081020731	\N	standard	2	4	0	0	\N	ready	unpaid	5600.00	\N	\N	0.00	\N	\N	f	\N	5	\N	2026-05-24 05:28:38.513	2026-05-24 05:28:38.513
386	1	2	67	DEMO0386	Kunle Adeyemi	08015661222	\N	premium	5	0	0	0	\N	ready	partial	7500.00	\N	\N	4800.00	\N	\N	f	\N	6	\N	2026-04-27 05:28:38.517	2026-04-27 05:28:38.517
387	1	2	61	DEMO0387	Sule Obiora	08043519463	\N	standard	1	3	0	0	\N	ready	paid	3800.00	\N	\N	3800.00	\N	\N	f	\N	8	\N	2026-04-16 05:28:38.524	2026-04-16 05:28:38.524
388	1	2	57	DEMO0388	Blessing Abubakar	08037354832	\N	premium	3	2	3	2	\N	completed	paid	8500.00	\N	360.00	8500.00	\N	\N	f	\N	5	\N	2026-03-18 05:28:38.53	2026-03-18 05:28:38.53
389	1	2	49	DEMO0389	Olu Musa	08028020192	\N	standard	3	1	0	0	\N	pending	partial	3400.00	\N	\N	1904.00	\N	\N	f	\N	8	\N	2026-06-01 05:28:38.541	2026-06-01 05:28:38.541
390	1	2	41	DEMO0390	Sule Alabi	08094647361	\N	express	4	3	4	3	\N	completed	paid	9300.00	\N	\N	9300.00	\N	\N	f	\N	5	\N	2026-04-18 05:28:38.548	2026-04-18 05:28:38.548
391	1	2	79	DEMO0391	Olu Alabi	08028712671	\N	standard	7	3	0	0	\N	pending	unpaid	8600.00	\N	\N	0.00	\N	\N	f	\N	5	\N	2026-05-25 05:28:38.554	2026-05-25 05:28:38.554
392	1	2	51	DEMO0392	Halima Musa	08011553725	\N	express	5	5	5	5	\N	completed	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	6	\N	2026-03-21 05:28:38.558	2026-03-21 05:28:38.558
393	1	2	66	DEMO0393	Blessing Lawal	08025636217	\N	premium	2	2	0	0	\N	processing	unpaid	7000.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-05-18 05:28:38.564	2026-05-18 05:28:38.564
394	1	2	45	DEMO0394	Olu Ogundele	08090281268	\N	premium	1	0	1	0	\N	completed	paid	1500.00	\N	\N	1500.00	\N	\N	f	\N	5	\N	2026-04-05 05:28:38.568	2026-04-05 05:28:38.568
395	1	2	56	DEMO0395	Damilola Okonkwo	08079323913	\N	express	4	5	0	0	\N	processing	partial	12300.00	\N	\N	6642.00	\N	\N	f	\N	7	\N	2026-04-27 05:28:38.575	2026-04-27 05:28:38.575
396	1	2	44	DEMO0396	Blessing Bello	08084652076	\N	premium	5	4	0	0	\N	processing	partial	15500.00	\N	294.00	8990.00	\N	\N	f	\N	7	\N	2026-04-25 05:28:38.581	2026-04-25 05:28:38.581
397	1	2	68	DEMO0397	Chidi Obiora	08092428328	\N	premium	5	1	5	1	\N	completed	paid	9500.00	\N	417.00	9500.00	\N	\N	f	\N	8	\N	2026-04-06 05:28:38.591	2026-04-06 05:28:38.591
398	1	2	76	DEMO0398	Fatima Adeyemi	08084024242	\N	standard	7	2	0	0	\N	processing	unpaid	7600.00	\N	\N	0.00	\N	\N	f	\N	8	\N	2026-05-01 05:28:38.603	2026-05-01 05:28:38.603
399	1	2	44	DEMO0399	Blessing Bello	08084652076	\N	express	1	0	0	0	\N	ready	partial	1200.00	\N	\N	744.00	\N	\N	f	\N	7	\N	2026-04-26 05:28:38.606	2026-04-26 05:28:38.606
400	1	2	41	DEMO0400	Sule Alabi	08094647361	\N	express	8	3	0	0	\N	processing	unpaid	14100.00	\N	\N	0.00	\N	\N	f	\N	7	\N	2026-05-28 05:28:38.612	2026-05-28 05:28:38.612
401	1	3	114	DEMO0401	Ngozi Yusuf	08048720977	\N	standard	4	4	0	0	\N	ready	partial	7200.00	\N	\N	2232.00	\N	\N	f	\N	9	\N	2026-04-12 05:28:38.686	2026-04-12 05:28:38.686
402	1	3	101	DEMO0402	Gbenga Musa	08058346048	\N	premium	5	4	0	0	\N	ready	paid	15500.00	\N	325.00	15500.00	\N	\N	f	\N	11	\N	2026-05-29 05:28:38.692	2026-05-29 05:28:38.692
403	1	3	90	DEMO0403	Emeka Abubakar	08084090992	\N	standard	3	0	3	0	\N	completed	paid	2400.00	\N	380.00	2400.00	\N	\N	f	\N	9	\N	2026-03-21 05:28:38.706	2026-03-21 05:28:38.706
404	1	3	111	DEMO0404	Gbenga Nwachukwu	08053408656	\N	premium	1	2	0	0	\N	pending	unpaid	5500.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-05-27 05:28:38.716	2026-05-27 05:28:38.716
405	1	3	108	DEMO0405	Halima Danjuma	08013493888	\N	express	8	0	8	0	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	12	\N	2026-04-06 05:28:38.719	2026-04-06 05:28:38.719
406	1	3	96	DEMO0406	Chioma Danjuma	08054336095	\N	premium	3	0	3	0	\N	completed	paid	4500.00	\N	\N	4500.00	\N	\N	f	\N	10	\N	2026-03-10 05:28:38.725	2026-03-10 05:28:38.725
407	1	3	84	DEMO0407	Seun Nwosu	08045242521	\N	express	2	0	0	0	\N	processing	unpaid	2400.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-06-02 05:28:38.731	2026-06-02 05:28:38.731
408	1	3	94	DEMO0408	Obinna Babatunde	08011182241	\N	standard	3	0	3	0	\N	completed	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	9	\N	2026-03-23 05:28:38.734	2026-03-23 05:28:38.734
409	1	3	105	DEMO0409	Obinna Babatunde	08068312074	\N	express	1	2	1	2	\N	completed	paid	4200.00	\N	408.00	4200.00	\N	\N	f	\N	9	\N	2026-03-26 05:28:38.741	2026-03-26 05:28:38.741
410	1	3	93	DEMO0410	Yusuf Chukwu	08021507811	\N	premium	3	3	0	0	\N	processing	unpaid	10500.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-05-07 05:28:38.753	2026-05-07 05:28:38.753
411	1	3	82	DEMO0411	Tobi Nwosu	08029008888	\N	premium	4	5	0	0	\N	processing	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	10	\N	2026-05-28 05:28:38.756	2026-05-28 05:28:38.756
412	1	3	119	DEMO0412	Aisha Nwosu	08012429984	\N	premium	4	1	0	0	\N	pending	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	9	\N	2026-05-31 05:28:38.764	2026-05-31 05:28:38.764
413	1	3	85	DEMO0413	Kunle Okonkwo	08079046258	\N	express	2	1	2	1	\N	completed	paid	3900.00	\N	1071.00	3900.00	\N	\N	f	\N	12	\N	2026-04-22 05:28:38.77	2026-04-22 05:28:38.77
414	1	3	83	DEMO0414	Ade Nwachukwu	08080430943	\N	express	4	1	4	1	\N	completed	paid	6300.00	\N	\N	6300.00	\N	\N	f	\N	9	\N	2026-03-12 05:28:38.785	2026-03-12 05:28:38.785
415	1	3	112	DEMO0415	Obinna Okonkwo	08086425274	\N	premium	7	4	7	4	\N	completed	paid	18500.00	\N	804.00	18500.00	\N	\N	f	\N	12	\N	2026-04-02 05:28:38.792	2026-04-02 05:28:38.792
416	1	3	97	DEMO0416	Adaeze Usman	08055732994	\N	express	2	2	0	0	\N	processing	unpaid	5400.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-06-01 05:28:38.806	2026-06-01 05:28:38.806
417	1	3	117	DEMO0417	Chiamaka Alabi	08068700195	\N	express	8	4	8	4	\N	completed	paid	15600.00	\N	333.00	15600.00	\N	\N	f	\N	10	\N	2026-04-03 05:28:38.81	2026-04-03 05:28:38.81
418	1	3	90	DEMO0418	Emeka Abubakar	08084090992	\N	standard	1	2	0	0	\N	pending	paid	2800.00	\N	\N	2800.00	\N	\N	f	\N	12	\N	2026-06-04 05:28:38.823	2026-06-04 05:28:38.823
419	1	3	97	DEMO0419	Adaeze Usman	08055732994	\N	premium	1	2	0	0	\N	pending	paid	5500.00	\N	\N	5500.00	\N	\N	f	\N	9	\N	2026-05-18 05:28:38.83	2026-05-18 05:28:38.83
420	1	3	86	DEMO0420	Yusuf Alabi	08071141375	\N	standard	3	0	0	0	\N	processing	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	10	\N	2026-06-07 05:28:38.836	2026-06-07 05:28:38.836
421	1	3	83	DEMO0421	Ade Nwachukwu	08080430943	\N	premium	6	3	6	3	\N	completed	paid	15000.00	\N	459.00	15000.00	\N	\N	f	\N	12	\N	2026-04-01 05:28:38.843	2026-04-01 05:28:38.843
422	1	3	116	DEMO0422	Ada Nwosu	08067603736	\N	premium	4	5	0	0	\N	processing	partial	16000.00	\N	\N	6080.00	\N	\N	f	\N	11	\N	2026-04-13 05:28:38.855	2026-04-13 05:28:38.855
423	1	3	81	DEMO0423	Damilola Nwosu	08054267690	\N	premium	3	4	0	0	\N	pending	partial	12500.00	\N	338.00	6750.00	\N	\N	f	\N	11	\N	2026-05-22 05:28:38.865	2026-05-22 05:28:38.865
424	1	3	87	DEMO0424	Olu Usman	08077341894	\N	standard	5	3	0	0	\N	processing	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	11	\N	2026-05-30 05:28:38.878	2026-05-30 05:28:38.878
425	1	3	90	DEMO0425	Emeka Abubakar	08084090992	\N	standard	5	1	0	0	\N	ready	unpaid	5000.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-04-29 05:28:38.886	2026-04-29 05:28:38.886
426	1	3	106	DEMO0426	Chiamaka Chukwu	08010534596	\N	standard	1	3	0	0	\N	pending	paid	3800.00	\N	\N	3800.00	\N	\N	f	\N	11	\N	2026-05-09 05:28:38.889	2026-05-09 05:28:38.889
427	1	3	85	DEMO0427	Kunle Okonkwo	08079046258	\N	express	3	1	0	0	\N	pending	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	9	\N	2026-05-27 05:28:38.896	2026-05-27 05:28:38.896
428	1	3	102	DEMO0428	Emeka Adeyemi	08069205726	\N	premium	7	1	0	0	\N	processing	partial	12500.00	\N	\N	8125.00	\N	\N	f	\N	9	\N	2026-04-22 05:28:38.902	2026-04-22 05:28:38.902
429	1	3	120	DEMO0429	Kunle Okonkwo	08089035865	\N	premium	8	2	8	2	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	10	\N	2026-04-06 05:28:38.908	2026-04-06 05:28:38.908
430	1	3	118	DEMO0430	Obinna Okafor	08080918373	\N	premium	4	4	4	4	\N	completed	partial	14000.00	\N	\N	4480.00	\N	\N	f	\N	12	\N	2026-03-29 05:28:38.917	2026-03-29 05:28:38.917
431	1	3	99	DEMO0431	Ada Nwosu	08049265561	\N	standard	7	5	0	0	\N	processing	unpaid	10600.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-06-03 05:28:38.923	2026-06-03 05:28:38.923
432	1	3	89	DEMO0432	Tunde Lawal	08066570684	\N	standard	1	5	0	0	\N	pending	unpaid	5800.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-06-05 05:28:38.926	2026-06-05 05:28:38.926
433	1	3	85	DEMO0433	Kunle Okonkwo	08079046258	\N	standard	6	1	0	0	\N	pending	unpaid	5800.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-06-04 05:28:38.93	2026-06-04 05:28:38.93
434	1	3	110	DEMO0434	Chiamaka Musa	08019769341	\N	premium	3	5	0	0	\N	processing	partial	14500.00	\N	764.00	5655.00	\N	\N	f	\N	9	\N	2026-05-09 05:28:38.934	2026-05-09 05:28:38.934
435	1	3	117	DEMO0435	Chiamaka Alabi	08068700195	\N	express	5	3	5	3	\N	completed	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	11	\N	2026-03-10 05:28:38.95	2026-03-10 05:28:38.95
436	1	3	105	DEMO0436	Obinna Babatunde	08068312074	\N	standard	1	3	0	0	\N	pending	partial	3800.00	\N	\N	1938.00	\N	\N	f	\N	12	\N	2026-05-30 05:28:38.957	2026-05-30 05:28:38.957
437	1	3	98	DEMO0437	Nneka Isa	08049531612	\N	standard	6	4	6	4	\N	completed	paid	8800.00	\N	\N	8800.00	\N	\N	f	\N	9	\N	2026-04-16 05:28:38.966	2026-04-16 05:28:38.966
438	1	3	86	DEMO0438	Yusuf Alabi	08071141375	\N	express	6	2	0	0	\N	ready	partial	10200.00	\N	\N	6528.00	\N	\N	f	\N	12	\N	2026-04-27 05:28:38.972	2026-04-27 05:28:38.972
439	1	3	82	DEMO0439	Tobi Nwosu	08029008888	\N	standard	8	3	0	0	\N	processing	partial	9400.00	\N	\N	5922.00	\N	\N	f	\N	10	\N	2026-04-17 05:28:38.979	2026-04-17 05:28:38.979
440	1	3	115	DEMO0440	Yusuf Adeyemi	08079352598	\N	premium	1	5	0	0	\N	pending	paid	11500.00	\N	119.00	11500.00	\N	\N	f	\N	12	\N	2026-05-15 05:28:38.985	2026-05-15 05:28:38.985
441	1	3	120	DEMO0441	Kunle Okonkwo	08089035865	\N	premium	7	1	0	0	\N	ready	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	10	\N	2026-05-25 05:28:38.995	2026-05-25 05:28:38.995
442	1	3	83	DEMO0442	Ade Nwachukwu	08080430943	\N	premium	4	1	4	1	\N	completed	paid	8000.00	\N	310.00	8000.00	\N	\N	f	\N	9	\N	2026-03-19 05:28:39.001	2026-03-19 05:28:39.001
443	1	3	120	DEMO0443	Kunle Okonkwo	08089035865	\N	standard	4	2	4	2	\N	completed	paid	5200.00	\N	\N	5200.00	\N	\N	f	\N	12	\N	2026-04-27 05:28:39.012	2026-04-27 05:28:39.012
444	1	3	108	DEMO0444	Halima Danjuma	08013493888	\N	standard	2	0	2	0	\N	completed	paid	1600.00	\N	\N	1600.00	\N	\N	f	\N	12	\N	2026-03-20 05:28:39.017	2026-03-20 05:28:39.017
445	1	3	105	DEMO0445	Obinna Babatunde	08068312074	\N	premium	1	0	0	0	\N	pending	paid	1500.00	\N	\N	1500.00	\N	\N	f	\N	9	\N	2026-06-04 05:28:39.023	2026-06-04 05:28:39.023
446	1	3	93	DEMO0446	Yusuf Chukwu	08021507811	\N	standard	6	0	6	0	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	11	\N	2026-04-25 05:28:39.028	2026-04-25 05:28:39.028
447	1	3	85	DEMO0447	Kunle Okonkwo	08079046258	\N	standard	2	5	0	0	\N	ready	unpaid	6600.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-05-25 05:28:39.035	2026-05-25 05:28:39.035
448	1	3	103	DEMO0448	Babajide Obiora	08046922429	\N	premium	1	1	1	1	\N	completed	partial	3500.00	\N	\N	2240.00	\N	\N	f	\N	12	\N	2026-03-24 05:28:39.039	2026-03-24 05:28:39.039
449	1	3	107	DEMO0449	Musa Usman	08054251732	\N	express	2	0	0	0	\N	ready	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	12	\N	2026-04-30 05:28:39.045	2026-04-30 05:28:39.045
450	1	3	97	DEMO0450	Adaeze Usman	08055732994	\N	premium	5	3	0	0	\N	processing	unpaid	13500.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-06-07 05:28:39.051	2026-06-07 05:28:39.051
451	1	3	111	DEMO0451	Gbenga Nwachukwu	08053408656	\N	premium	2	2	2	2	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	12	\N	2026-03-18 05:28:39.055	2026-03-18 05:28:39.055
452	1	3	87	DEMO0452	Olu Usman	08077341894	\N	express	5	5	0	0	\N	processing	partial	13500.00	\N	845.00	9450.00	\N	\N	f	\N	10	\N	2026-05-07 05:28:39.061	2026-05-07 05:28:39.061
453	1	3	117	DEMO0453	Chiamaka Alabi	08068700195	\N	premium	7	3	7	3	\N	completed	paid	16500.00	\N	\N	16500.00	\N	\N	f	\N	10	\N	2026-04-01 05:28:39.077	2026-04-01 05:28:39.077
454	1	3	112	DEMO0454	Obinna Okonkwo	08086425274	\N	standard	2	1	2	1	\N	completed	paid	2600.00	\N	\N	2600.00	\N	\N	f	\N	11	\N	2026-04-27 05:28:39.088	2026-04-27 05:28:39.088
455	1	3	98	DEMO0455	Nneka Isa	08049531612	\N	express	1	0	0	0	\N	processing	unpaid	1200.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-05-27 05:28:39.095	2026-05-27 05:28:39.095
456	1	3	100	DEMO0456	Chiamaka Babatunde	08080358858	\N	standard	1	0	0	0	\N	ready	unpaid	800.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-04-14 05:28:39.102	2026-04-14 05:28:39.102
457	1	3	113	DEMO0457	Amaka Danjuma	08040357645	\N	standard	8	1	8	1	\N	completed	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	12	\N	2026-03-26 05:28:39.106	2026-03-26 05:28:39.106
458	1	3	113	DEMO0458	Amaka Danjuma	08040357645	\N	express	3	2	3	2	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	12	\N	2026-03-20 05:28:39.112	2026-03-20 05:28:39.112
459	1	3	109	DEMO0459	Blessing Lawal	08017990570	\N	express	7	1	0	0	\N	processing	unpaid	9900.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-06-05 05:28:39.121	2026-06-05 05:28:39.121
460	1	3	108	DEMO0460	Halima Danjuma	08013493888	\N	express	8	3	8	3	\N	completed	partial	14100.00	\N	\N	8037.00	\N	\N	f	\N	9	\N	2026-04-06 05:28:39.124	2026-04-06 05:28:39.124
461	1	3	107	DEMO0461	Musa Usman	08054251732	\N	standard	2	4	0	0	\N	ready	partial	5600.00	\N	\N	3416.00	\N	\N	f	\N	11	\N	2026-05-28 05:28:39.131	2026-05-28 05:28:39.131
462	1	3	83	DEMO0462	Ade Nwachukwu	08080430943	\N	standard	7	0	7	0	\N	completed	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	12	\N	2026-03-20 05:28:39.138	2026-03-20 05:28:39.138
463	1	3	88	DEMO0463	Chidi Okonkwo	08029638420	\N	express	7	2	0	0	\N	ready	unpaid	11400.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-04-16 05:28:39.146	2026-04-16 05:28:39.146
464	1	3	93	DEMO0464	Yusuf Chukwu	08021507811	\N	standard	8	2	0	0	\N	processing	unpaid	8400.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-04-17 05:28:39.15	2026-04-17 05:28:39.15
465	1	3	96	DEMO0465	Chioma Danjuma	08054336095	\N	premium	8	3	0	0	\N	pending	unpaid	18000.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-05-14 05:28:39.153	2026-05-14 05:28:39.153
466	1	3	117	DEMO0466	Chiamaka Alabi	08068700195	\N	express	8	3	0	0	\N	processing	paid	14100.00	\N	\N	14100.00	\N	\N	f	\N	12	\N	2026-05-01 05:28:39.157	2026-05-01 05:28:39.157
467	1	3	90	DEMO0467	Emeka Abubakar	08084090992	\N	standard	7	2	0	0	\N	pending	paid	7600.00	\N	\N	7600.00	\N	\N	f	\N	9	\N	2026-05-29 05:28:39.164	2026-05-29 05:28:39.164
468	1	3	100	DEMO0468	Chiamaka Babatunde	08080358858	\N	express	3	0	0	0	\N	pending	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	12	\N	2026-06-02 05:28:39.17	2026-06-02 05:28:39.17
469	1	3	115	DEMO0469	Yusuf Adeyemi	08079352598	\N	standard	5	3	5	3	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	11	\N	2026-04-17 05:28:39.176	2026-04-17 05:28:39.176
470	1	3	89	DEMO0470	Tunde Lawal	08066570684	\N	standard	6	3	0	0	\N	processing	unpaid	7800.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-05-25 05:28:39.183	2026-05-25 05:28:39.183
471	1	3	100	DEMO0471	Chiamaka Babatunde	08080358858	\N	standard	4	2	4	2	\N	completed	partial	5200.00	\N	232.00	2964.00	\N	\N	f	\N	12	\N	2026-05-01 05:28:39.186	2026-05-01 05:28:39.186
472	1	3	87	DEMO0472	Olu Usman	08077341894	\N	standard	2	5	0	0	\N	processing	partial	6600.00	\N	\N	2442.00	\N	\N	f	\N	12	\N	2026-05-29 05:28:39.199	2026-05-29 05:28:39.199
473	1	3	89	DEMO0473	Tunde Lawal	08066570684	\N	premium	6	3	6	3	\N	completed	paid	15000.00	\N	\N	15000.00	\N	\N	f	\N	10	\N	2026-04-01 05:28:39.205	2026-04-01 05:28:39.205
474	1	3	116	DEMO0474	Ada Nwosu	08067603736	\N	express	6	5	0	0	\N	processing	unpaid	14700.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-04-18 05:28:39.211	2026-04-18 05:28:39.211
475	1	3	84	DEMO0475	Seun Nwosu	08045242521	\N	premium	3	2	3	2	\N	completed	paid	8500.00	\N	\N	8500.00	\N	\N	f	\N	10	\N	2026-04-16 05:28:39.214	2026-04-16 05:28:39.214
476	1	3	83	DEMO0476	Ade Nwachukwu	08080430943	\N	premium	6	2	6	2	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	12	\N	2026-05-05 05:28:39.22	2026-05-05 05:28:39.22
477	1	3	86	DEMO0477	Yusuf Alabi	08071141375	\N	standard	4	0	0	0	\N	processing	unpaid	3200.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-06-04 05:28:39.227	2026-06-04 05:28:39.227
478	1	3	100	DEMO0478	Chiamaka Babatunde	08080358858	\N	express	4	4	0	0	\N	pending	paid	10800.00	\N	\N	10800.00	\N	\N	f	\N	9	\N	2026-05-20 05:28:39.233	2026-05-20 05:28:39.233
479	1	3	113	DEMO0479	Amaka Danjuma	08040357645	\N	standard	7	1	7	1	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	11	\N	2026-03-09 05:28:39.24	2026-03-09 05:28:39.24
480	1	3	104	DEMO0480	Chioma Okafor	08096577880	\N	express	2	4	0	0	\N	ready	paid	8400.00	\N	\N	8400.00	\N	\N	f	\N	10	\N	2026-04-26 05:28:39.245	2026-04-26 05:28:39.245
481	1	3	89	DEMO0481	Tunde Lawal	08066570684	\N	express	8	4	0	0	\N	pending	paid	15600.00	\N	\N	15600.00	\N	\N	f	\N	11	\N	2026-05-12 05:28:39.251	2026-05-12 05:28:39.251
482	1	3	89	DEMO0482	Tunde Lawal	08066570684	\N	express	7	5	0	0	\N	pending	paid	15900.00	\N	541.00	15900.00	\N	\N	f	\N	11	\N	2026-05-12 05:28:39.256	2026-05-12 05:28:39.256
483	1	3	81	DEMO0483	Damilola Nwosu	08054267690	\N	express	2	2	2	2	\N	completed	partial	5400.00	\N	\N	2808.00	\N	\N	f	\N	11	\N	2026-03-12 05:28:39.269	2026-03-12 05:28:39.269
484	1	3	118	DEMO0484	Obinna Okafor	08080918373	\N	express	2	0	2	0	\N	completed	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	11	\N	2026-03-26 05:28:39.275	2026-03-26 05:28:39.275
485	1	3	108	DEMO0485	Halima Danjuma	08013493888	\N	premium	5	2	0	0	\N	ready	partial	11500.00	\N	\N	6785.00	\N	\N	f	\N	9	\N	2026-04-14 05:28:39.281	2026-04-14 05:28:39.281
486	1	3	117	DEMO0486	Chiamaka Alabi	08068700195	\N	express	8	4	0	0	\N	ready	paid	15600.00	\N	\N	15600.00	\N	\N	f	\N	9	\N	2026-04-12 05:28:39.286	2026-04-12 05:28:39.286
487	1	3	82	DEMO0487	Tobi Nwosu	08029008888	\N	premium	5	3	0	0	\N	pending	unpaid	13500.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-05-29 05:28:39.292	2026-05-29 05:28:39.292
488	1	3	120	DEMO0488	Kunle Okonkwo	08089035865	\N	standard	8	2	8	2	\N	completed	paid	8400.00	\N	\N	8400.00	\N	\N	f	\N	10	\N	2026-03-20 05:28:39.295	2026-03-20 05:28:39.295
489	1	3	85	DEMO0489	Kunle Okonkwo	08079046258	\N	standard	6	5	0	0	\N	ready	partial	9800.00	\N	\N	6174.00	\N	\N	f	\N	9	\N	2026-04-18 05:28:39.3	2026-04-18 05:28:39.3
490	1	3	120	DEMO0490	Kunle Okonkwo	08089035865	\N	express	8	5	8	5	\N	completed	paid	17100.00	\N	\N	17100.00	\N	\N	f	\N	12	\N	2026-05-02 05:28:39.305	2026-05-02 05:28:39.305
491	1	3	99	DEMO0491	Ada Nwosu	08049265561	\N	premium	7	4	7	4	\N	completed	paid	18500.00	\N	\N	18500.00	\N	\N	f	\N	9	\N	2026-03-12 05:28:39.312	2026-03-12 05:28:39.312
492	1	3	112	DEMO0492	Obinna Okonkwo	08086425274	\N	standard	3	2	0	0	\N	processing	paid	4400.00	\N	\N	4400.00	\N	\N	f	\N	11	\N	2026-05-18 05:28:39.318	2026-05-18 05:28:39.318
493	1	3	120	DEMO0493	Kunle Okonkwo	08089035865	\N	express	5	2	5	2	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	9	\N	2026-03-28 05:28:39.324	2026-03-28 05:28:39.324
494	1	3	81	DEMO0494	Damilola Nwosu	08054267690	\N	standard	1	4	0	0	\N	processing	unpaid	4800.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-04-26 05:28:39.33	2026-04-26 05:28:39.33
495	1	3	118	DEMO0495	Obinna Okafor	08080918373	\N	premium	2	2	2	2	\N	completed	partial	7000.00	\N	\N	2100.00	\N	\N	f	\N	12	\N	2026-03-31 05:28:39.334	2026-03-31 05:28:39.334
496	1	3	85	DEMO0496	Kunle Okonkwo	08079046258	\N	standard	4	1	0	0	\N	pending	paid	4200.00	\N	119.00	4200.00	\N	\N	f	\N	10	\N	2026-06-07 05:28:39.34	2026-06-07 05:28:39.34
497	1	3	89	DEMO0497	Tunde Lawal	08066570684	\N	premium	5	0	5	0	\N	completed	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	12	\N	2026-03-18 05:28:39.355	2026-03-18 05:28:39.355
498	1	3	107	DEMO0498	Musa Usman	08054251732	\N	premium	2	1	2	1	\N	completed	paid	5000.00	\N	\N	5000.00	\N	\N	f	\N	11	\N	2026-03-13 05:28:39.362	2026-03-13 05:28:39.362
499	1	3	110	DEMO0499	Chiamaka Musa	08019769341	\N	premium	2	2	0	0	\N	pending	unpaid	7000.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-05-30 05:28:39.369	2026-05-30 05:28:39.369
500	1	3	88	DEMO0500	Chidi Okonkwo	08029638420	\N	premium	4	3	0	0	\N	processing	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	10	\N	2026-05-03 05:28:39.373	2026-05-03 05:28:39.373
501	1	3	102	DEMO0501	Emeka Adeyemi	08069205726	\N	premium	7	4	7	4	\N	completed	paid	18500.00	\N	\N	18500.00	\N	\N	f	\N	9	\N	2026-04-16 05:28:39.38	2026-04-16 05:28:39.38
502	1	3	119	DEMO0502	Aisha Nwosu	08012429984	\N	premium	8	5	8	5	\N	completed	paid	22000.00	\N	\N	22000.00	\N	\N	f	\N	10	\N	2026-05-07 05:28:39.39	2026-05-07 05:28:39.39
503	1	3	88	DEMO0503	Chidi Okonkwo	08029638420	\N	standard	4	3	4	3	\N	completed	paid	6200.00	\N	919.00	6200.00	\N	\N	f	\N	10	\N	2026-03-17 05:28:39.396	2026-03-17 05:28:39.396
504	1	3	101	DEMO0504	Gbenga Musa	08058346048	\N	standard	5	4	0	0	\N	pending	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	9	\N	2026-05-22 05:28:39.411	2026-05-22 05:28:39.411
505	1	3	118	DEMO0505	Obinna Okafor	08080918373	\N	standard	6	1	6	1	\N	completed	paid	5800.00	\N	\N	5800.00	\N	\N	f	\N	9	\N	2026-03-30 05:28:39.42	2026-03-30 05:28:39.42
506	1	3	90	DEMO0506	Emeka Abubakar	08084090992	\N	premium	7	3	0	0	\N	ready	unpaid	16500.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-04-25 05:28:39.427	2026-04-25 05:28:39.427
507	1	3	94	DEMO0507	Obinna Babatunde	08011182241	\N	express	1	0	0	0	\N	processing	partial	1200.00	\N	\N	480.00	\N	\N	f	\N	9	\N	2026-05-04 05:28:39.434	2026-05-04 05:28:39.434
508	1	3	117	DEMO0508	Chiamaka Alabi	08068700195	\N	standard	6	2	0	0	\N	processing	partial	6800.00	\N	\N	2992.00	\N	\N	f	\N	11	\N	2026-05-12 05:28:39.44	2026-05-12 05:28:39.44
509	1	3	117	DEMO0509	Chiamaka Alabi	08068700195	\N	premium	3	5	3	5	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	12	\N	2026-03-30 05:28:39.446	2026-03-30 05:28:39.446
510	1	3	115	DEMO0510	Yusuf Adeyemi	08079352598	\N	express	7	0	0	0	\N	processing	unpaid	8400.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-04-22 05:28:39.452	2026-04-22 05:28:39.452
511	1	3	100	DEMO0511	Chiamaka Babatunde	08080358858	\N	express	7	1	0	0	\N	ready	paid	9900.00	\N	\N	9900.00	\N	\N	f	\N	12	\N	2026-04-25 05:28:39.455	2026-04-25 05:28:39.455
512	1	3	99	DEMO0512	Ada Nwosu	08049265561	\N	express	7	5	0	0	\N	processing	unpaid	15900.00	\N	597.00	0.00	\N	\N	f	\N	11	\N	2026-05-13 05:28:39.463	2026-05-13 05:28:39.463
513	1	3	120	DEMO0513	Kunle Okonkwo	08089035865	\N	express	7	2	0	0	\N	processing	unpaid	11400.00	\N	1486.00	0.00	\N	\N	f	\N	9	\N	2026-06-04 05:28:39.475	2026-06-04 05:28:39.475
514	1	3	88	DEMO0514	Chidi Okonkwo	08029638420	\N	premium	5	4	0	0	\N	processing	unpaid	15500.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-04-12 05:28:39.487	2026-04-12 05:28:39.487
515	1	3	83	DEMO0515	Ade Nwachukwu	08080430943	\N	standard	2	4	0	0	\N	pending	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	12	\N	2026-06-04 05:28:39.49	2026-06-04 05:28:39.49
516	1	3	105	DEMO0516	Obinna Babatunde	08068312074	\N	standard	2	5	2	5	\N	completed	paid	6600.00	\N	198.00	6600.00	\N	\N	f	\N	12	\N	2026-03-25 05:28:39.497	2026-03-25 05:28:39.497
517	1	3	117	DEMO0517	Chiamaka Alabi	08068700195	\N	premium	8	1	8	1	\N	completed	paid	14000.00	\N	\N	14000.00	\N	\N	f	\N	10	\N	2026-05-03 05:28:39.509	2026-05-03 05:28:39.509
518	1	3	108	DEMO0518	Halima Danjuma	08013493888	\N	standard	2	0	2	0	\N	completed	paid	1600.00	\N	\N	1600.00	\N	\N	f	\N	12	\N	2026-04-28 05:28:39.518	2026-04-28 05:28:39.518
519	1	3	115	DEMO0519	Yusuf Adeyemi	08079352598	\N	express	6	5	0	0	\N	ready	paid	14700.00	\N	\N	14700.00	\N	\N	f	\N	12	\N	2026-04-28 05:28:39.527	2026-04-28 05:28:39.527
520	1	3	99	DEMO0520	Ada Nwosu	08049265561	\N	standard	7	3	0	0	\N	ready	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	12	\N	2026-04-23 05:28:39.533	2026-04-23 05:28:39.533
521	1	3	86	DEMO0521	Yusuf Alabi	08071141375	\N	standard	5	3	5	3	\N	completed	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	11	\N	2026-03-18 05:28:39.538	2026-03-18 05:28:39.538
522	1	3	95	DEMO0522	Ade Usman	08034170688	\N	premium	2	3	0	0	\N	ready	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	10	\N	2026-05-05 05:28:39.543	2026-05-05 05:28:39.543
523	1	3	117	DEMO0523	Chiamaka Alabi	08068700195	\N	express	7	3	0	0	\N	pending	paid	12900.00	\N	\N	12900.00	\N	\N	f	\N	9	\N	2026-06-07 05:28:39.551	2026-06-07 05:28:39.551
524	1	3	93	DEMO0524	Yusuf Chukwu	08021507811	\N	standard	6	3	0	0	\N	processing	unpaid	7800.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-04-09 05:28:39.557	2026-04-09 05:28:39.557
525	1	3	111	DEMO0525	Gbenga Nwachukwu	08053408656	\N	premium	8	5	0	0	\N	pending	partial	22000.00	\N	\N	14080.00	\N	\N	f	\N	11	\N	2026-05-13 05:28:39.56	2026-05-13 05:28:39.56
526	1	3	92	DEMO0526	Zainab Isa	08061552632	\N	premium	2	1	2	1	\N	completed	paid	5000.00	\N	\N	5000.00	\N	\N	f	\N	11	\N	2026-04-14 05:28:39.566	2026-04-14 05:28:39.566
527	1	3	106	DEMO0527	Chiamaka Chukwu	08010534596	\N	premium	6	1	0	0	\N	processing	paid	11000.00	\N	477.00	11000.00	\N	\N	f	\N	10	\N	2026-05-14 05:28:39.571	2026-05-14 05:28:39.571
528	1	3	85	DEMO0528	Kunle Okonkwo	08079046258	\N	premium	8	3	8	3	\N	completed	paid	18000.00	\N	\N	18000.00	\N	\N	f	\N	12	\N	2026-05-06 05:28:39.581	2026-05-06 05:28:39.581
529	1	3	107	DEMO0529	Musa Usman	08054251732	\N	express	5	2	5	2	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	9	\N	2026-04-04 05:28:39.586	2026-04-04 05:28:39.586
530	1	3	89	DEMO0530	Tunde Lawal	08066570684	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	9	\N	2026-04-06 05:28:39.592	2026-04-06 05:28:39.592
531	1	3	83	DEMO0531	Ade Nwachukwu	08080430943	\N	premium	4	2	4	2	\N	completed	paid	10000.00	\N	\N	10000.00	\N	\N	f	\N	11	\N	2026-03-20 05:28:39.598	2026-03-20 05:28:39.598
532	1	3	87	DEMO0532	Olu Usman	08077341894	\N	standard	6	4	0	0	\N	processing	unpaid	8800.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-04-14 05:28:39.607	2026-04-14 05:28:39.607
533	1	3	115	DEMO0533	Yusuf Adeyemi	08079352598	\N	express	2	1	2	1	\N	completed	paid	3900.00	\N	\N	3900.00	\N	\N	f	\N	10	\N	2026-03-23 05:28:39.61	2026-03-23 05:28:39.61
534	1	3	110	DEMO0534	Chiamaka Musa	08019769341	\N	premium	6	2	0	0	\N	processing	unpaid	13000.00	\N	\N	0.00	\N	\N	f	\N	10	\N	2026-05-23 05:28:39.616	2026-05-23 05:28:39.616
535	1	3	92	DEMO0535	Zainab Isa	08061552632	\N	express	1	1	0	0	\N	pending	unpaid	2700.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-06-01 05:28:39.619	2026-06-01 05:28:39.619
536	1	3	92	DEMO0536	Zainab Isa	08061552632	\N	premium	8	4	8	4	\N	completed	paid	20000.00	\N	\N	20000.00	\N	\N	f	\N	10	\N	2026-03-09 05:28:39.622	2026-03-09 05:28:39.622
537	1	3	112	DEMO0537	Obinna Okonkwo	08086425274	\N	premium	4	3	4	3	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	10	\N	2026-03-10 05:28:39.628	2026-03-10 05:28:39.628
538	1	3	93	DEMO0538	Yusuf Chukwu	08021507811	\N	express	7	5	0	0	\N	processing	partial	15900.00	\N	120.00	8427.00	\N	\N	f	\N	10	\N	2026-04-12 05:28:39.635	2026-04-12 05:28:39.635
539	1	3	112	DEMO0539	Obinna Okonkwo	08086425274	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	10	\N	2026-04-17 05:28:39.647	2026-04-17 05:28:39.647
540	1	3	100	DEMO0540	Chiamaka Babatunde	08080358858	\N	premium	2	5	2	5	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	11	\N	2026-03-29 05:28:39.652	2026-03-29 05:28:39.652
541	1	3	104	DEMO0541	Chioma Okafor	08096577880	\N	premium	2	1	0	0	\N	ready	partial	5000.00	\N	\N	3400.00	\N	\N	f	\N	10	\N	2026-04-16 05:28:39.658	2026-04-16 05:28:39.658
542	1	3	97	DEMO0542	Adaeze Usman	08055732994	\N	premium	7	2	0	0	\N	processing	paid	14500.00	\N	1203.00	14500.00	\N	\N	f	\N	11	\N	2026-05-19 05:28:39.665	2026-05-19 05:28:39.665
543	1	3	82	DEMO0543	Tobi Nwosu	08029008888	\N	express	6	2	6	2	\N	completed	paid	10200.00	\N	\N	10200.00	\N	\N	f	\N	9	\N	2026-03-11 05:28:39.68	2026-03-11 05:28:39.68
544	1	3	113	DEMO0544	Amaka Danjuma	08040357645	\N	standard	7	4	0	0	\N	processing	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	11	\N	2026-05-01 05:28:39.685	2026-05-01 05:28:39.685
545	1	3	116	DEMO0545	Ada Nwosu	08067603736	\N	express	5	1	5	1	\N	completed	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	12	\N	2026-03-23 05:28:39.694	2026-03-23 05:28:39.694
546	1	3	88	DEMO0546	Chidi Okonkwo	08029638420	\N	premium	3	5	3	5	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	9	\N	2026-03-24 05:28:39.699	2026-03-24 05:28:39.699
547	1	3	93	DEMO0547	Yusuf Chukwu	08021507811	\N	express	3	1	0	0	\N	processing	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	9	\N	2026-05-25 05:28:39.705	2026-05-25 05:28:39.705
548	1	3	110	DEMO0548	Chiamaka Musa	08019769341	\N	premium	6	5	6	5	\N	completed	paid	19000.00	\N	\N	19000.00	\N	\N	f	\N	12	\N	2026-04-18 05:28:39.71	2026-04-18 05:28:39.71
549	1	3	100	DEMO0549	Chiamaka Babatunde	08080358858	\N	express	5	0	0	0	\N	ready	paid	6000.00	\N	\N	6000.00	\N	\N	f	\N	9	\N	2026-05-23 05:28:39.715	2026-05-23 05:28:39.715
550	1	3	85	DEMO0550	Kunle Okonkwo	08079046258	\N	express	5	4	0	0	\N	pending	partial	12000.00	\N	\N	7200.00	\N	\N	f	\N	10	\N	2026-05-26 05:28:39.721	2026-05-26 05:28:39.721
551	1	3	107	DEMO0551	Musa Usman	08054251732	\N	premium	7	2	7	2	\N	completed	partial	14500.00	\N	\N	7685.00	\N	\N	f	\N	11	\N	2026-03-25 05:28:39.727	2026-03-25 05:28:39.727
552	1	3	85	DEMO0552	Kunle Okonkwo	08079046258	\N	standard	7	4	0	0	\N	pending	partial	9600.00	\N	\N	4992.00	\N	\N	f	\N	11	\N	2026-06-04 05:28:39.733	2026-06-04 05:28:39.733
553	1	3	101	DEMO0553	Gbenga Musa	08058346048	\N	express	2	2	2	2	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	9	\N	2026-04-21 05:28:39.74	2026-04-21 05:28:39.74
554	1	3	107	DEMO0554	Musa Usman	08054251732	\N	standard	2	2	2	2	\N	completed	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	10	\N	2026-03-10 05:28:39.746	2026-03-10 05:28:39.746
555	1	3	88	DEMO0555	Chidi Okonkwo	08029638420	\N	premium	5	4	0	0	\N	ready	unpaid	15500.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-05-27 05:28:39.753	2026-05-27 05:28:39.753
556	1	3	120	DEMO0556	Kunle Okonkwo	08089035865	\N	express	1	0	1	0	\N	completed	paid	1200.00	\N	\N	1200.00	\N	\N	f	\N	10	\N	2026-03-18 05:28:39.756	2026-03-18 05:28:39.756
557	1	3	113	DEMO0557	Amaka Danjuma	08040357645	\N	standard	8	0	0	0	\N	ready	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	12	\N	2026-05-10 05:28:39.762	2026-05-10 05:28:39.762
558	1	3	113	DEMO0558	Amaka Danjuma	08040357645	\N	express	5	3	5	3	\N	completed	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	12	\N	2026-03-28 05:28:39.767	2026-03-28 05:28:39.767
559	1	3	105	DEMO0559	Obinna Babatunde	08068312074	\N	standard	2	0	0	0	\N	ready	partial	1600.00	\N	\N	752.00	\N	\N	f	\N	9	\N	2026-04-29 05:28:39.774	2026-04-29 05:28:39.774
560	1	3	106	DEMO0560	Chiamaka Chukwu	08010534596	\N	premium	7	5	0	0	\N	ready	unpaid	20500.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-04-28 05:28:39.78	2026-04-28 05:28:39.78
561	1	3	103	DEMO0561	Babajide Obiora	08046922429	\N	standard	4	0	0	0	\N	ready	unpaid	3200.00	\N	1054.00	0.00	\N	\N	f	\N	12	\N	2026-04-25 05:28:39.783	2026-04-25 05:28:39.783
562	1	3	119	DEMO0562	Aisha Nwosu	08012429984	\N	premium	3	2	3	2	\N	completed	paid	8500.00	\N	\N	8500.00	\N	\N	f	\N	10	\N	2026-03-21 05:28:39.795	2026-03-21 05:28:39.795
563	1	3	116	DEMO0563	Ada Nwosu	08067603736	\N	standard	7	1	7	1	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	10	\N	2026-03-31 05:28:39.801	2026-03-31 05:28:39.801
564	1	3	108	DEMO0564	Halima Danjuma	08013493888	\N	standard	3	1	3	1	\N	completed	paid	3400.00	\N	\N	3400.00	\N	\N	f	\N	11	\N	2026-04-07 05:28:39.808	2026-04-07 05:28:39.808
565	1	3	111	DEMO0565	Gbenga Nwachukwu	08053408656	\N	express	5	2	0	0	\N	ready	partial	9000.00	\N	\N	5940.00	\N	\N	f	\N	11	\N	2026-05-29 05:28:39.815	2026-05-29 05:28:39.815
566	1	3	91	DEMO0566	Kunle Nwachukwu	08036199277	\N	premium	1	1	0	0	\N	pending	paid	3500.00	\N	\N	3500.00	\N	\N	f	\N	9	\N	2026-06-04 05:28:39.823	2026-06-04 05:28:39.823
567	1	3	86	DEMO0567	Yusuf Alabi	08071141375	\N	standard	4	0	4	0	\N	completed	paid	3200.00	\N	\N	3200.00	\N	\N	f	\N	11	\N	2026-03-15 05:28:39.831	2026-03-15 05:28:39.831
568	1	3	116	DEMO0568	Ada Nwosu	08067603736	\N	standard	3	2	0	0	\N	ready	unpaid	4400.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-04-22 05:28:39.837	2026-04-22 05:28:39.837
569	1	3	94	DEMO0569	Obinna Babatunde	08011182241	\N	express	6	2	0	0	\N	processing	unpaid	10200.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-05-27 05:28:39.841	2026-05-27 05:28:39.841
570	1	3	109	DEMO0570	Blessing Lawal	08017990570	\N	express	6	5	0	0	\N	processing	partial	14700.00	\N	\N	4998.00	\N	\N	f	\N	11	\N	2026-04-23 05:28:39.844	2026-04-23 05:28:39.844
571	1	3	85	DEMO0571	Kunle Okonkwo	08079046258	\N	premium	8	0	0	0	\N	pending	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	9	\N	2026-05-12 05:28:39.851	2026-05-12 05:28:39.851
572	1	3	104	DEMO0572	Chioma Okafor	08096577880	\N	express	8	4	0	0	\N	processing	unpaid	15600.00	\N	\N	0.00	\N	\N	f	\N	12	\N	2026-05-27 05:28:39.857	2026-05-27 05:28:39.857
573	1	3	88	DEMO0573	Chidi Okonkwo	08029638420	\N	standard	4	4	0	0	\N	ready	unpaid	7200.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-05-09 05:28:39.863	2026-05-09 05:28:39.863
574	1	3	117	DEMO0574	Chiamaka Alabi	08068700195	\N	premium	4	4	4	4	\N	completed	paid	14000.00	\N	\N	14000.00	\N	\N	f	\N	10	\N	2026-04-09 05:28:39.866	2026-04-09 05:28:39.866
575	1	3	89	DEMO0575	Tunde Lawal	08066570684	\N	express	5	0	5	0	\N	completed	partial	6000.00	\N	\N	2760.00	\N	\N	f	\N	10	\N	2026-03-09 05:28:39.873	2026-03-09 05:28:39.873
576	1	3	105	DEMO0576	Obinna Babatunde	08068312074	\N	express	8	2	0	0	\N	ready	paid	12600.00	\N	820.00	12600.00	\N	\N	f	\N	9	\N	2026-04-22 05:28:39.879	2026-04-22 05:28:39.879
577	1	3	89	DEMO0577	Tunde Lawal	08066570684	\N	standard	2	0	2	0	\N	completed	paid	1600.00	\N	\N	1600.00	\N	\N	f	\N	9	\N	2026-03-30 05:28:39.892	2026-03-30 05:28:39.892
578	1	3	94	DEMO0578	Obinna Babatunde	08011182241	\N	premium	6	2	0	0	\N	processing	partial	13000.00	\N	\N	7150.00	\N	\N	f	\N	11	\N	2026-05-22 05:28:39.897	2026-05-22 05:28:39.897
579	1	3	103	DEMO0579	Babajide Obiora	08046922429	\N	standard	5	4	0	0	\N	processing	partial	8000.00	\N	\N	5360.00	\N	\N	f	\N	11	\N	2026-06-01 05:28:39.903	2026-06-01 05:28:39.903
580	1	3	91	DEMO0580	Kunle Nwachukwu	08036199277	\N	premium	8	5	8	5	\N	completed	paid	22000.00	\N	\N	22000.00	\N	\N	f	\N	11	\N	2026-03-25 05:28:39.909	2026-03-25 05:28:39.909
581	1	3	87	DEMO0581	Olu Usman	08077341894	\N	express	7	1	0	0	\N	ready	unpaid	9900.00	\N	\N	0.00	\N	\N	f	\N	11	\N	2026-04-16 05:28:39.916	2026-04-16 05:28:39.916
582	1	3	92	DEMO0582	Zainab Isa	08061552632	\N	standard	3	5	0	0	\N	pending	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	9	\N	2026-05-27 05:28:39.918	2026-05-27 05:28:39.918
583	1	3	99	DEMO0583	Ada Nwosu	08049265561	\N	express	4	5	4	5	\N	completed	paid	12300.00	\N	\N	12300.00	\N	\N	f	\N	11	\N	2026-03-10 05:28:39.923	2026-03-10 05:28:39.923
584	1	3	103	DEMO0584	Babajide Obiora	08046922429	\N	standard	1	1	1	1	\N	completed	paid	1800.00	\N	\N	1800.00	\N	\N	f	\N	9	\N	2026-03-15 05:28:39.929	2026-03-15 05:28:39.929
585	1	3	106	DEMO0585	Chiamaka Chukwu	08010534596	\N	express	8	3	0	0	\N	ready	paid	14100.00	\N	\N	14100.00	\N	\N	f	\N	10	\N	2026-05-02 05:28:39.934	2026-05-02 05:28:39.934
586	1	3	117	DEMO0586	Chiamaka Alabi	08068700195	\N	standard	6	3	0	0	\N	processing	partial	7800.00	\N	\N	4680.00	\N	\N	f	\N	12	\N	2026-05-14 05:28:39.942	2026-05-14 05:28:39.942
587	1	3	109	DEMO0587	Blessing Lawal	08017990570	\N	express	4	0	4	0	\N	completed	paid	4800.00	\N	1440.00	4800.00	\N	\N	f	\N	10	\N	2026-04-14 05:28:39.952	2026-04-14 05:28:39.952
588	1	3	82	DEMO0588	Tobi Nwosu	08029008888	\N	standard	5	0	0	0	\N	pending	paid	4000.00	\N	344.00	4000.00	\N	\N	f	\N	12	\N	2026-05-19 05:28:39.965	2026-05-19 05:28:39.965
589	1	3	118	DEMO0589	Obinna Okafor	08080918373	\N	premium	3	2	3	2	\N	completed	paid	8500.00	\N	449.00	8500.00	\N	\N	f	\N	10	\N	2026-03-29 05:28:39.977	2026-03-29 05:28:39.977
590	1	3	86	DEMO0590	Yusuf Alabi	08071141375	\N	premium	2	3	0	0	\N	ready	partial	9000.00	\N	\N	2970.00	\N	\N	f	\N	11	\N	2026-04-23 05:28:39.988	2026-04-23 05:28:39.988
591	1	3	110	DEMO0591	Chiamaka Musa	08019769341	\N	premium	3	2	0	0	\N	pending	unpaid	8500.00	\N	124.00	0.00	\N	\N	f	\N	12	\N	2026-06-05 05:28:39.995	2026-06-05 05:28:39.995
592	1	3	116	DEMO0592	Ada Nwosu	08067603736	\N	premium	2	5	2	5	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	11	\N	2026-04-20 05:28:40.004	2026-04-20 05:28:40.004
593	1	3	105	DEMO0593	Obinna Babatunde	08068312074	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	11	\N	2026-03-11 05:28:40.01	2026-03-11 05:28:40.01
594	1	3	114	DEMO0594	Ngozi Yusuf	08048720977	\N	standard	2	5	0	0	\N	processing	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	11	\N	2026-04-22 05:28:40.018	2026-04-22 05:28:40.018
595	1	3	87	DEMO0595	Olu Usman	08077341894	\N	premium	8	0	8	0	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	10	\N	2026-03-24 05:28:40.028	2026-03-24 05:28:40.028
596	1	3	95	DEMO0596	Ade Usman	08034170688	\N	standard	7	1	0	0	\N	ready	unpaid	6600.00	\N	\N	0.00	\N	\N	f	\N	9	\N	2026-05-19 05:28:40.033	2026-05-19 05:28:40.033
597	1	3	115	DEMO0597	Yusuf Adeyemi	08079352598	\N	premium	5	3	5	3	\N	completed	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	11	\N	2026-04-02 05:28:40.036	2026-04-02 05:28:40.036
598	1	3	101	DEMO0598	Gbenga Musa	08058346048	\N	premium	5	0	0	0	\N	processing	unpaid	7500.00	\N	262.00	0.00	\N	\N	f	\N	10	\N	2026-05-07 05:28:40.043	2026-05-07 05:28:40.043
599	1	3	118	DEMO0599	Obinna Okafor	08080918373	\N	express	1	1	1	1	\N	completed	paid	2700.00	\N	\N	2700.00	\N	\N	f	\N	9	\N	2026-03-16 05:28:40.051	2026-03-16 05:28:40.051
600	1	3	90	DEMO0600	Emeka Abubakar	08084090992	\N	standard	1	1	0	0	\N	processing	paid	1800.00	\N	\N	1800.00	\N	\N	f	\N	10	\N	2026-05-28 05:28:40.056	2026-05-28 05:28:40.056
601	1	4	142	DEMO0601	Blessing Obi	08034305120	\N	premium	2	5	2	5	\N	completed	paid	13000.00	\N	151.00	13000.00	\N	\N	f	\N	16	\N	2026-04-14 05:28:40.136	2026-04-14 05:28:40.136
602	1	4	150	DEMO0602	Ibrahim Lawal	08020290227	\N	standard	6	5	0	0	\N	processing	unpaid	9800.00	\N	\N	0.00	\N	\N	f	\N	16	\N	2026-04-16 05:28:40.148	2026-04-16 05:28:40.148
603	1	4	129	DEMO0603	Obinna Isa	08042459898	\N	express	2	4	0	0	\N	ready	partial	8400.00	\N	\N	3192.00	\N	\N	f	\N	13	\N	2026-04-20 05:28:40.152	2026-04-20 05:28:40.152
604	1	4	146	DEMO0604	Damilola Nwachukwu	08041295494	\N	standard	5	4	0	0	\N	processing	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	16	\N	2026-04-11 05:28:40.158	2026-04-11 05:28:40.158
605	1	4	158	DEMO0605	Fatima Obiora	08045416657	\N	standard	1	2	0	0	\N	pending	unpaid	2800.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-05-22 05:28:40.164	2026-05-22 05:28:40.164
606	1	4	154	DEMO0606	Aisha Isa	08064997562	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	16	\N	2026-03-24 05:28:40.168	2026-03-24 05:28:40.168
607	1	4	153	DEMO0607	Seun Obiora	08089855224	\N	standard	2	4	0	0	\N	pending	partial	5600.00	\N	\N	2464.00	\N	\N	f	\N	15	\N	2026-06-03 05:28:40.174	2026-06-03 05:28:40.174
608	1	4	133	DEMO0608	Chidi Ogundele	08036563927	\N	express	5	3	5	3	\N	completed	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	14	\N	2026-03-26 05:28:40.181	2026-03-26 05:28:40.181
609	1	4	137	DEMO0609	Sule Musa	08061440233	\N	express	5	2	0	0	\N	processing	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	13	\N	2026-04-25 05:28:40.187	2026-04-25 05:28:40.187
610	1	4	156	DEMO0610	Yusuf Abubakar	08078005912	\N	express	4	0	0	0	\N	ready	unpaid	4800.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-04-13 05:28:40.194	2026-04-13 05:28:40.194
611	1	4	121	DEMO0611	Ade Obiora	08039919323	\N	express	6	2	6	2	\N	completed	paid	10200.00	\N	\N	10200.00	\N	\N	f	\N	15	\N	2026-03-24 05:28:40.197	2026-03-24 05:28:40.197
612	1	4	155	DEMO0612	Adaeze Babatunde	08026202752	\N	standard	2	3	0	0	\N	pending	paid	4600.00	\N	\N	4600.00	\N	\N	f	\N	14	\N	2026-05-15 05:28:40.204	2026-05-15 05:28:40.204
613	1	4	140	DEMO0613	Adaeze Danjuma	08095011255	\N	premium	6	4	0	0	\N	pending	paid	17000.00	\N	411.00	17000.00	\N	\N	f	\N	16	\N	2026-05-15 05:28:40.213	2026-05-15 05:28:40.213
614	1	4	136	DEMO0614	Musa Obi	08030707134	\N	express	4	4	4	4	\N	completed	paid	10800.00	\N	\N	10800.00	\N	\N	f	\N	13	\N	2026-03-19 05:28:40.225	2026-03-19 05:28:40.225
615	1	4	142	DEMO0615	Blessing Obi	08034305120	\N	standard	1	4	1	4	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	14	\N	2026-03-09 05:28:40.231	2026-03-09 05:28:40.231
616	1	4	121	DEMO0616	Ade Obiora	08039919323	\N	standard	3	1	0	0	\N	pending	paid	3400.00	\N	1317.00	3400.00	\N	\N	f	\N	16	\N	2026-06-05 05:28:40.236	2026-06-05 05:28:40.236
617	1	4	132	DEMO0617	Chioma Adeyemi	08031115790	\N	express	6	1	6	1	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	15	\N	2026-03-23 05:28:40.252	2026-03-23 05:28:40.252
618	1	4	130	DEMO0618	Ifeoma Adeyemi	08024091314	\N	express	5	5	0	0	\N	ready	partial	13500.00	\N	922.00	8235.00	\N	\N	f	\N	13	\N	2026-04-21 05:28:40.257	2026-04-21 05:28:40.257
619	1	4	153	DEMO0619	Seun Obiora	08089855224	\N	premium	7	0	7	0	\N	completed	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	16	\N	2026-03-10 05:28:40.271	2026-03-10 05:28:40.271
620	1	4	158	DEMO0620	Fatima Obiora	08045416657	\N	premium	3	2	3	2	\N	completed	paid	8500.00	\N	1109.00	8500.00	\N	\N	f	\N	15	\N	2026-04-28 05:28:40.277	2026-04-28 05:28:40.277
621	1	4	123	DEMO0621	Tobi Obiora	08090767138	\N	premium	4	1	0	0	\N	ready	unpaid	8000.00	\N	\N	0.00	\N	\N	f	\N	16	\N	2026-05-04 05:28:40.29	2026-05-04 05:28:40.29
622	1	4	125	DEMO0622	Chioma Nwachukwu	08046519602	\N	express	4	0	4	0	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	16	\N	2026-04-20 05:28:40.294	2026-04-20 05:28:40.294
623	1	4	145	DEMO0623	Nkechi Isa	08072052162	\N	standard	5	0	5	0	\N	completed	paid	4000.00	\N	\N	4000.00	\N	\N	f	\N	16	\N	2026-04-03 05:28:40.3	2026-04-03 05:28:40.3
624	1	4	124	DEMO0624	Adaeze Okafor	08061833781	\N	premium	6	3	0	0	\N	processing	paid	15000.00	\N	377.00	15000.00	\N	\N	f	\N	13	\N	2026-04-13 05:28:40.306	2026-04-13 05:28:40.306
625	1	4	125	DEMO0625	Chioma Nwachukwu	08046519602	\N	express	6	0	6	0	\N	completed	partial	7200.00	\N	\N	4896.00	\N	\N	f	\N	15	\N	2026-04-02 05:28:40.317	2026-04-02 05:28:40.317
626	1	4	160	DEMO0626	Aisha Bello	08092491205	\N	premium	5	3	0	0	\N	processing	unpaid	13500.00	\N	\N	0.00	\N	\N	f	\N	15	\N	2026-04-20 05:28:40.324	2026-04-20 05:28:40.324
627	1	4	123	DEMO0627	Tobi Obiora	08090767138	\N	standard	5	3	0	0	\N	processing	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	15	\N	2026-04-29 05:28:40.327	2026-04-29 05:28:40.327
628	1	4	124	DEMO0628	Adaeze Okafor	08061833781	\N	express	7	0	0	0	\N	ready	partial	8400.00	\N	\N	4704.00	\N	\N	f	\N	14	\N	2026-05-08 05:28:40.332	2026-05-08 05:28:40.332
629	1	4	158	DEMO0629	Fatima Obiora	08045416657	\N	standard	3	3	0	0	\N	pending	partial	5400.00	\N	\N	2106.00	\N	\N	f	\N	13	\N	2026-05-08 05:28:40.338	2026-05-08 05:28:40.338
630	1	4	151	DEMO0630	Obinna Danjuma	08036655329	\N	standard	1	1	1	1	\N	completed	paid	1800.00	\N	\N	1800.00	\N	\N	f	\N	14	\N	2026-03-19 05:28:40.344	2026-03-19 05:28:40.344
631	1	4	129	DEMO0631	Obinna Isa	08042459898	\N	standard	1	5	1	5	\N	completed	paid	5800.00	\N	\N	5800.00	\N	\N	f	\N	16	\N	2026-03-15 05:28:40.35	2026-03-15 05:28:40.35
632	1	4	134	DEMO0632	Obinna Adeyemi	08097105120	\N	premium	8	3	0	0	\N	pending	partial	18000.00	\N	\N	9000.00	\N	\N	f	\N	15	\N	2026-05-25 05:28:40.356	2026-05-25 05:28:40.356
633	1	4	135	DEMO0633	Fatima Alabi	08096074419	\N	express	1	5	0	0	\N	pending	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	15	\N	2026-05-22 05:28:40.361	2026-05-22 05:28:40.361
634	1	4	141	DEMO0634	Blessing Nwosu	08082580604	\N	express	7	2	7	2	\N	completed	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	14	\N	2026-04-07 05:28:40.367	2026-04-07 05:28:40.367
635	1	4	142	DEMO0635	Blessing Obi	08034305120	\N	express	5	5	5	5	\N	completed	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	15	\N	2026-03-11 05:28:40.378	2026-03-11 05:28:40.378
636	1	4	156	DEMO0636	Yusuf Abubakar	08078005912	\N	premium	5	0	0	0	\N	ready	unpaid	7500.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-04-13 05:28:40.386	2026-04-13 05:28:40.386
637	1	4	137	DEMO0637	Sule Musa	08061440233	\N	express	7	4	7	4	\N	completed	paid	14400.00	\N	\N	14400.00	\N	\N	f	\N	16	\N	2026-03-20 05:28:40.389	2026-03-20 05:28:40.389
638	1	4	152	DEMO0638	Nkechi Ogundele	08041396289	\N	express	1	3	0	0	\N	ready	partial	5700.00	\N	\N	2907.00	\N	\N	f	\N	16	\N	2026-05-02 05:28:40.396	2026-05-02 05:28:40.396
639	1	4	131	DEMO0639	Fatima Abubakar	08014900020	\N	express	5	2	5	2	\N	completed	partial	9000.00	\N	\N	2700.00	\N	\N	f	\N	14	\N	2026-03-12 05:28:40.404	2026-03-12 05:28:40.404
640	1	4	133	DEMO0640	Chidi Ogundele	08036563927	\N	standard	8	5	8	5	\N	completed	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	15	\N	2026-04-07 05:28:40.411	2026-04-07 05:28:40.411
641	1	4	146	DEMO0641	Damilola Nwachukwu	08041295494	\N	express	1	4	1	4	\N	completed	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	15	\N	2026-04-05 05:28:40.417	2026-04-05 05:28:40.417
642	1	4	127	DEMO0642	Obinna Abubakar	08014057350	\N	express	8	1	8	1	\N	completed	paid	11100.00	\N	\N	11100.00	\N	\N	f	\N	13	\N	2026-03-31 05:28:40.423	2026-03-31 05:28:40.423
643	1	4	128	DEMO0643	Ngozi Danjuma	08017811962	\N	express	1	2	0	0	\N	ready	paid	4200.00	\N	\N	4200.00	\N	\N	f	\N	16	\N	2026-04-12 05:28:40.43	2026-04-12 05:28:40.43
644	1	4	151	DEMO0644	Obinna Danjuma	08036655329	\N	premium	1	0	0	0	\N	ready	paid	1500.00	\N	\N	1500.00	\N	\N	f	\N	13	\N	2026-05-04 05:28:40.44	2026-05-04 05:28:40.44
645	1	4	150	DEMO0645	Ibrahim Lawal	08020290227	\N	standard	4	1	0	0	\N	processing	unpaid	4200.00	\N	\N	0.00	\N	\N	f	\N	16	\N	2026-05-02 05:28:40.449	2026-05-02 05:28:40.449
646	1	4	126	DEMO0646	Seun Yusuf	08034658823	\N	standard	4	3	0	0	\N	pending	paid	6200.00	\N	\N	6200.00	\N	\N	f	\N	15	\N	2026-06-04 05:28:40.453	2026-06-04 05:28:40.453
647	1	4	141	DEMO0647	Blessing Nwosu	08082580604	\N	standard	6	0	0	0	\N	pending	partial	4800.00	\N	\N	2064.00	\N	\N	f	\N	13	\N	2026-06-07 05:28:40.461	2026-06-07 05:28:40.461
648	1	4	131	DEMO0648	Fatima Abubakar	08014900020	\N	premium	2	0	2	0	\N	completed	paid	3000.00	\N	\N	3000.00	\N	\N	f	\N	15	\N	2026-03-17 05:28:40.468	2026-03-17 05:28:40.468
649	1	4	152	DEMO0649	Nkechi Ogundele	08041396289	\N	express	6	4	0	0	\N	pending	partial	13200.00	\N	\N	7788.00	\N	\N	f	\N	15	\N	2026-05-31 05:28:40.48	2026-05-31 05:28:40.48
650	1	4	140	DEMO0650	Adaeze Danjuma	08095011255	\N	express	5	1	0	0	\N	ready	paid	7500.00	\N	404.00	7500.00	\N	\N	f	\N	14	\N	2026-05-16 05:28:40.487	2026-05-16 05:28:40.487
651	1	4	145	DEMO0651	Nkechi Isa	08072052162	\N	express	7	4	7	4	\N	completed	paid	14400.00	\N	\N	14400.00	\N	\N	f	\N	15	\N	2026-03-13 05:28:40.499	2026-03-13 05:28:40.499
652	1	4	124	DEMO0652	Adaeze Okafor	08061833781	\N	standard	5	0	0	0	\N	pending	partial	4000.00	\N	\N	1240.00	\N	\N	f	\N	15	\N	2026-06-04 05:28:40.509	2026-06-04 05:28:40.509
653	1	4	142	DEMO0653	Blessing Obi	08034305120	\N	premium	2	3	0	0	\N	pending	partial	9000.00	\N	237.00	3960.00	\N	\N	f	\N	15	\N	2026-05-21 05:28:40.516	2026-05-21 05:28:40.516
654	1	4	158	DEMO0654	Fatima Obiora	08045416657	\N	standard	1	1	0	0	\N	processing	paid	1800.00	\N	\N	1800.00	\N	\N	f	\N	15	\N	2026-05-29 05:28:40.528	2026-05-29 05:28:40.528
655	1	4	160	DEMO0655	Aisha Bello	08092491205	\N	express	4	0	4	0	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	14	\N	2026-04-06 05:28:40.538	2026-04-06 05:28:40.538
656	1	4	150	DEMO0656	Ibrahim Lawal	08020290227	\N	premium	4	3	0	0	\N	ready	partial	12000.00	\N	\N	4080.00	\N	\N	f	\N	16	\N	2026-05-09 05:28:40.545	2026-05-09 05:28:40.545
657	1	4	158	DEMO0657	Fatima Obiora	08045416657	\N	standard	3	5	3	5	\N	completed	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	13	\N	2026-03-30 05:28:40.552	2026-03-30 05:28:40.552
658	1	4	130	DEMO0658	Ifeoma Adeyemi	08024091314	\N	express	7	2	7	2	\N	completed	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	16	\N	2026-03-10 05:28:40.558	2026-03-10 05:28:40.558
659	1	4	152	DEMO0659	Nkechi Ogundele	08041396289	\N	express	5	2	5	2	\N	completed	paid	9000.00	\N	255.00	9000.00	\N	\N	f	\N	16	\N	2026-04-22 05:28:40.564	2026-04-22 05:28:40.564
660	1	4	140	DEMO0660	Adaeze Danjuma	08095011255	\N	express	8	4	8	4	\N	completed	paid	15600.00	\N	\N	15600.00	\N	\N	f	\N	14	\N	2026-04-01 05:28:40.576	2026-04-01 05:28:40.576
661	1	4	144	DEMO0661	Adaeze Yusuf	08072273375	\N	premium	1	4	1	4	\N	completed	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	14	\N	2026-03-13 05:28:40.582	2026-03-13 05:28:40.582
662	1	4	129	DEMO0662	Obinna Isa	08042459898	\N	standard	8	5	0	0	\N	processing	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	13	\N	2026-04-09 05:28:40.589	2026-04-09 05:28:40.589
663	1	4	158	DEMO0663	Fatima Obiora	08045416657	\N	express	8	1	0	0	\N	pending	paid	11100.00	\N	\N	11100.00	\N	\N	f	\N	16	\N	2026-06-06 05:28:40.597	2026-06-06 05:28:40.597
664	1	4	133	DEMO0664	Chidi Ogundele	08036563927	\N	express	3	4	3	4	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	15	\N	2026-04-02 05:28:40.603	2026-04-02 05:28:40.603
665	1	4	124	DEMO0665	Adaeze Okafor	08061833781	\N	premium	8	3	0	0	\N	pending	unpaid	18000.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-05-29 05:28:40.61	2026-05-29 05:28:40.61
666	1	4	145	DEMO0666	Nkechi Isa	08072052162	\N	standard	6	5	6	5	\N	completed	paid	9800.00	\N	\N	9800.00	\N	\N	f	\N	15	\N	2026-04-13 05:28:40.613	2026-04-13 05:28:40.613
667	1	4	141	DEMO0667	Blessing Nwosu	08082580604	\N	premium	8	1	8	1	\N	completed	paid	14000.00	\N	\N	14000.00	\N	\N	f	\N	14	\N	2026-04-04 05:28:40.62	2026-04-04 05:28:40.62
668	1	4	132	DEMO0668	Chioma Adeyemi	08031115790	\N	premium	3	1	3	1	\N	completed	paid	6500.00	\N	\N	6500.00	\N	\N	f	\N	13	\N	2026-04-01 05:28:40.627	2026-04-01 05:28:40.627
669	1	4	147	DEMO0669	Ada Obiora	08018524555	\N	premium	1	4	0	0	\N	ready	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	13	\N	2026-04-14 05:28:40.633	2026-04-14 05:28:40.633
670	1	4	128	DEMO0670	Ngozi Danjuma	08017811962	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	16	\N	2026-04-04 05:28:40.642	2026-04-04 05:28:40.642
671	1	4	139	DEMO0671	Kunle Obi	08055367578	\N	standard	2	4	0	0	\N	processing	partial	5600.00	\N	\N	2184.00	\N	\N	f	\N	13	\N	2026-04-29 05:28:40.652	2026-04-29 05:28:40.652
672	1	4	148	DEMO0672	Yusuf Obiora	08069077275	\N	premium	7	4	0	0	\N	pending	unpaid	18500.00	\N	348.00	0.00	\N	\N	f	\N	14	\N	2026-06-05 05:28:40.658	2026-06-05 05:28:40.658
673	1	4	134	DEMO0673	Obinna Adeyemi	08097105120	\N	premium	7	4	0	0	\N	ready	paid	18500.00	\N	\N	18500.00	\N	\N	f	\N	16	\N	2026-05-18 05:28:40.667	2026-05-18 05:28:40.667
674	1	4	152	DEMO0674	Nkechi Ogundele	08041396289	\N	standard	6	4	0	0	\N	processing	paid	8800.00	\N	\N	8800.00	\N	\N	f	\N	13	\N	2026-04-30 05:28:40.673	2026-04-30 05:28:40.673
675	1	4	138	DEMO0675	Sule Bello	08057696941	\N	standard	5	3	0	0	\N	ready	paid	7000.00	\N	\N	7000.00	\N	\N	f	\N	13	\N	2026-04-14 05:28:40.679	2026-04-14 05:28:40.679
676	1	4	148	DEMO0676	Yusuf Obiora	08069077275	\N	standard	3	3	3	3	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	16	\N	2026-03-09 05:28:40.685	2026-03-09 05:28:40.685
677	1	4	142	DEMO0677	Blessing Obi	08034305120	\N	express	6	3	6	3	\N	completed	paid	11700.00	\N	\N	11700.00	\N	\N	f	\N	13	\N	2026-03-27 05:28:40.69	2026-03-27 05:28:40.69
678	1	4	148	DEMO0678	Yusuf Obiora	08069077275	\N	express	6	5	0	0	\N	ready	paid	14700.00	\N	\N	14700.00	\N	\N	f	\N	14	\N	2026-05-19 05:28:40.696	2026-05-19 05:28:40.696
679	1	4	156	DEMO0679	Yusuf Abubakar	08078005912	\N	express	3	5	0	0	\N	processing	partial	11100.00	\N	\N	4107.00	\N	\N	f	\N	13	\N	2026-04-08 05:28:40.703	2026-04-08 05:28:40.703
680	1	4	125	DEMO0680	Chioma Nwachukwu	08046519602	\N	premium	5	4	0	0	\N	ready	partial	15500.00	\N	\N	7440.00	\N	\N	f	\N	16	\N	2026-04-15 05:28:40.712	2026-04-15 05:28:40.712
681	1	4	140	DEMO0681	Adaeze Danjuma	08095011255	\N	standard	2	1	2	1	\N	completed	partial	2600.00	\N	\N	1274.00	\N	\N	f	\N	13	\N	2026-03-27 05:28:40.719	2026-03-27 05:28:40.719
682	1	4	144	DEMO0682	Adaeze Yusuf	08072273375	\N	standard	4	4	4	4	\N	completed	paid	7200.00	\N	388.00	7200.00	\N	\N	f	\N	16	\N	2026-03-13 05:28:40.725	2026-03-13 05:28:40.725
683	1	4	131	DEMO0683	Fatima Abubakar	08014900020	\N	premium	5	5	5	5	\N	completed	paid	17500.00	\N	\N	17500.00	\N	\N	f	\N	13	\N	2026-04-29 05:28:40.736	2026-04-29 05:28:40.736
684	1	4	121	DEMO0684	Ade Obiora	08039919323	\N	standard	2	2	2	2	\N	completed	paid	3600.00	\N	\N	3600.00	\N	\N	f	\N	14	\N	2026-05-05 05:28:40.741	2026-05-05 05:28:40.741
685	1	4	159	DEMO0685	Blessing Nwosu	08017410283	\N	premium	5	1	5	1	\N	completed	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	16	\N	2026-03-22 05:28:40.749	2026-03-22 05:28:40.749
686	1	4	153	DEMO0686	Seun Obiora	08089855224	\N	express	4	3	0	0	\N	processing	paid	9300.00	\N	\N	9300.00	\N	\N	f	\N	15	\N	2026-05-30 05:28:40.757	2026-05-30 05:28:40.757
687	1	4	121	DEMO0687	Ade Obiora	08039919323	\N	standard	5	4	0	0	\N	pending	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	15	\N	2026-06-04 05:28:40.763	2026-06-04 05:28:40.763
688	1	4	152	DEMO0688	Nkechi Ogundele	08041396289	\N	standard	8	2	8	2	\N	completed	paid	8400.00	\N	\N	8400.00	\N	\N	f	\N	16	\N	2026-04-23 05:28:40.769	2026-04-23 05:28:40.769
689	1	4	122	DEMO0689	Nkechi Bello	08075507131	\N	express	6	0	6	0	\N	completed	paid	7200.00	\N	393.00	7200.00	\N	\N	f	\N	13	\N	2026-03-21 05:28:40.775	2026-03-21 05:28:40.775
690	1	4	149	DEMO0690	Ngozi Alabi	08083898605	\N	standard	2	1	0	0	\N	pending	paid	2600.00	\N	\N	2600.00	\N	\N	f	\N	14	\N	2026-05-25 05:28:40.787	2026-05-25 05:28:40.787
691	1	4	147	DEMO0691	Ada Obiora	08018524555	\N	standard	2	4	2	4	\N	completed	paid	5600.00	\N	\N	5600.00	\N	\N	f	\N	14	\N	2026-03-17 05:28:40.795	2026-03-17 05:28:40.795
692	1	4	132	DEMO0692	Chioma Adeyemi	08031115790	\N	express	4	1	0	0	\N	pending	paid	6300.00	\N	\N	6300.00	\N	\N	f	\N	15	\N	2026-05-16 05:28:40.801	2026-05-16 05:28:40.801
693	1	4	137	DEMO0693	Sule Musa	08061440233	\N	premium	6	4	0	0	\N	processing	paid	17000.00	\N	\N	17000.00	\N	\N	f	\N	16	\N	2026-06-06 05:28:40.807	2026-06-06 05:28:40.807
694	1	4	138	DEMO0694	Sule Bello	08057696941	\N	premium	1	1	1	1	\N	completed	paid	3500.00	\N	\N	3500.00	\N	\N	f	\N	13	\N	2026-03-16 05:28:40.813	2026-03-16 05:28:40.813
695	1	4	141	DEMO0695	Blessing Nwosu	08082580604	\N	standard	6	3	0	0	\N	pending	paid	7800.00	\N	\N	7800.00	\N	\N	f	\N	15	\N	2026-05-14 05:28:40.819	2026-05-14 05:28:40.819
696	1	4	132	DEMO0696	Chioma Adeyemi	08031115790	\N	standard	7	5	7	5	\N	completed	paid	10600.00	\N	\N	10600.00	\N	\N	f	\N	15	\N	2026-03-29 05:28:40.826	2026-03-29 05:28:40.826
697	1	4	157	DEMO0697	Tunde Nwosu	08080658899	\N	standard	6	5	0	0	\N	ready	partial	9800.00	\N	\N	6370.00	\N	\N	f	\N	15	\N	2026-04-19 05:28:40.832	2026-04-19 05:28:40.832
698	1	4	153	DEMO0698	Seun Obiora	08089855224	\N	express	7	3	7	3	\N	completed	paid	12900.00	\N	\N	12900.00	\N	\N	f	\N	14	\N	2026-03-31 05:28:40.839	2026-03-31 05:28:40.839
699	1	4	153	DEMO0699	Seun Obiora	08089855224	\N	express	2	1	0	0	\N	processing	paid	3900.00	\N	\N	3900.00	\N	\N	f	\N	14	\N	2026-05-02 05:28:40.847	2026-05-02 05:28:40.847
700	1	4	145	DEMO0700	Nkechi Isa	08072052162	\N	standard	4	0	0	0	\N	pending	unpaid	3200.00	\N	474.00	0.00	\N	\N	f	\N	14	\N	2026-05-26 05:28:40.854	2026-05-26 05:28:40.854
701	1	4	156	DEMO0701	Yusuf Abubakar	08078005912	\N	express	6	1	6	1	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	14	\N	2026-03-25 05:28:40.863	2026-03-25 05:28:40.863
702	1	4	144	DEMO0702	Adaeze Yusuf	08072273375	\N	premium	3	4	3	4	\N	completed	paid	12500.00	\N	393.00	12500.00	\N	\N	f	\N	14	\N	2026-04-21 05:28:40.869	2026-04-21 05:28:40.869
703	1	4	133	DEMO0703	Chidi Ogundele	08036563927	\N	premium	1	2	0	0	\N	processing	unpaid	5500.00	\N	103.00	0.00	\N	\N	f	\N	14	\N	2026-04-18 05:28:40.881	2026-04-18 05:28:40.881
704	1	4	129	DEMO0704	Obinna Isa	08042459898	\N	premium	3	4	0	0	\N	pending	partial	12500.00	\N	\N	4750.00	\N	\N	f	\N	13	\N	2026-06-02 05:28:40.89	2026-06-02 05:28:40.89
705	1	4	149	DEMO0705	Ngozi Alabi	08083898605	\N	express	2	5	0	0	\N	ready	unpaid	9900.00	\N	114.00	0.00	\N	\N	f	\N	16	\N	2026-05-22 05:28:40.899	2026-05-22 05:28:40.899
706	1	4	147	DEMO0706	Ada Obiora	08018524555	\N	standard	1	0	1	0	\N	completed	paid	800.00	\N	\N	800.00	\N	\N	f	\N	16	\N	2026-03-17 05:28:40.909	2026-03-17 05:28:40.909
707	1	4	123	DEMO0707	Tobi Obiora	08090767138	\N	express	8	4	0	0	\N	ready	partial	15600.00	\N	\N	8112.00	\N	\N	f	\N	14	\N	2026-04-29 05:28:40.915	2026-04-29 05:28:40.915
708	1	4	140	DEMO0708	Adaeze Danjuma	08095011255	\N	standard	6	1	6	1	\N	completed	paid	5800.00	\N	\N	5800.00	\N	\N	f	\N	13	\N	2026-03-20 05:28:40.925	2026-03-20 05:28:40.925
709	1	4	131	DEMO0709	Fatima Abubakar	08014900020	\N	express	5	5	0	0	\N	processing	partial	13500.00	\N	\N	5400.00	\N	\N	f	\N	15	\N	2026-05-31 05:28:40.934	2026-05-31 05:28:40.934
710	1	4	141	DEMO0710	Blessing Nwosu	08082580604	\N	express	2	5	0	0	\N	ready	partial	9900.00	\N	\N	2970.00	\N	\N	f	\N	13	\N	2026-05-02 05:28:40.941	2026-05-02 05:28:40.941
711	1	4	134	DEMO0711	Obinna Adeyemi	08097105120	\N	standard	2	1	0	0	\N	ready	partial	2600.00	\N	\N	1456.00	\N	\N	f	\N	16	\N	2026-05-23 05:28:40.948	2026-05-23 05:28:40.948
712	1	4	128	DEMO0712	Ngozi Danjuma	08017811962	\N	express	7	0	7	0	\N	completed	paid	8400.00	\N	383.00	8400.00	\N	\N	f	\N	15	\N	2026-04-24 05:28:40.954	2026-04-24 05:28:40.954
713	1	4	160	DEMO0713	Aisha Bello	08092491205	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	\N	15500.00	\N	\N	f	\N	15	\N	2026-04-26 05:28:40.966	2026-04-26 05:28:40.966
714	1	4	132	DEMO0714	Chioma Adeyemi	08031115790	\N	express	7	4	0	0	\N	pending	partial	14400.00	\N	\N	5328.00	\N	\N	f	\N	13	\N	2026-05-16 05:28:40.972	2026-05-16 05:28:40.972
715	1	4	144	DEMO0715	Adaeze Yusuf	08072273375	\N	standard	5	5	0	0	\N	processing	unpaid	9000.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-04-17 05:28:40.979	2026-04-17 05:28:40.979
716	1	4	133	DEMO0716	Chidi Ogundele	08036563927	\N	premium	7	3	7	3	\N	completed	paid	16500.00	\N	\N	16500.00	\N	\N	f	\N	14	\N	2026-03-16 05:28:40.983	2026-03-16 05:28:40.983
717	1	4	127	DEMO0717	Obinna Abubakar	08014057350	\N	standard	6	4	6	4	\N	completed	paid	8800.00	\N	\N	8800.00	\N	\N	f	\N	14	\N	2026-03-27 05:28:40.989	2026-03-27 05:28:40.989
718	1	4	157	DEMO0718	Tunde Nwosu	08080658899	\N	express	8	4	0	0	\N	processing	unpaid	15600.00	\N	\N	0.00	\N	\N	f	\N	13	\N	2026-05-08 05:28:40.996	2026-05-08 05:28:40.996
719	1	4	131	DEMO0719	Fatima Abubakar	08014900020	\N	standard	5	2	0	0	\N	ready	partial	6000.00	\N	117.00	2820.00	\N	\N	f	\N	15	\N	2026-05-23 05:28:40.999	2026-05-23 05:28:40.999
720	1	4	135	DEMO0720	Fatima Alabi	08096074419	\N	standard	3	2	0	0	\N	pending	unpaid	4400.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-05-17 05:28:41.011	2026-05-17 05:28:41.011
721	1	4	135	DEMO0721	Fatima Alabi	08096074419	\N	premium	6	1	0	0	\N	pending	partial	11000.00	\N	\N	7480.00	\N	\N	f	\N	13	\N	2026-06-06 05:28:41.014	2026-06-06 05:28:41.014
722	1	4	145	DEMO0722	Nkechi Isa	08072052162	\N	standard	2	0	0	0	\N	pending	unpaid	1600.00	\N	\N	0.00	\N	\N	f	\N	13	\N	2026-05-31 05:28:41.019	2026-05-31 05:28:41.019
723	1	4	133	DEMO0723	Chidi Ogundele	08036563927	\N	standard	4	4	0	0	\N	ready	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	15	\N	2026-04-15 05:28:41.023	2026-04-15 05:28:41.023
724	1	4	142	DEMO0724	Blessing Obi	08034305120	\N	standard	3	5	3	5	\N	completed	paid	7400.00	\N	1471.00	7400.00	\N	\N	f	\N	15	\N	2026-03-13 05:28:41.03	2026-03-13 05:28:41.03
725	1	4	132	DEMO0725	Chioma Adeyemi	08031115790	\N	express	1	5	0	0	\N	processing	partial	8700.00	\N	\N	3828.00	\N	\N	f	\N	15	\N	2026-04-25 05:28:41.047	2026-04-25 05:28:41.047
726	1	4	125	DEMO0726	Chioma Nwachukwu	08046519602	\N	standard	1	0	0	0	\N	processing	partial	800.00	\N	\N	560.00	\N	\N	f	\N	14	\N	2026-05-09 05:28:41.054	2026-05-09 05:28:41.054
727	1	4	125	DEMO0727	Chioma Nwachukwu	08046519602	\N	premium	6	0	0	0	\N	processing	partial	9000.00	\N	\N	2880.00	\N	\N	f	\N	15	\N	2026-05-05 05:28:41.06	2026-05-05 05:28:41.06
728	1	4	159	DEMO0728	Blessing Nwosu	08017410283	\N	standard	1	4	1	4	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	15	\N	2026-03-11 05:28:41.066	2026-03-11 05:28:41.066
729	1	4	125	DEMO0729	Chioma Nwachukwu	08046519602	\N	express	7	5	0	0	\N	pending	partial	15900.00	\N	\N	5088.00	\N	\N	f	\N	13	\N	2026-06-04 05:28:41.076	2026-06-04 05:28:41.076
730	1	4	136	DEMO0730	Musa Obi	08030707134	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	15	\N	2026-03-22 05:28:41.083	2026-03-22 05:28:41.083
731	1	4	126	DEMO0731	Seun Yusuf	08034658823	\N	standard	8	3	0	0	\N	pending	partial	9400.00	\N	\N	3196.00	\N	\N	f	\N	15	\N	2026-05-11 05:28:41.09	2026-05-11 05:28:41.09
732	1	4	141	DEMO0732	Blessing Nwosu	08082580604	\N	premium	8	4	0	0	\N	pending	partial	20000.00	\N	\N	8400.00	\N	\N	f	\N	15	\N	2026-06-05 05:28:41.097	2026-06-05 05:28:41.097
733	1	4	138	DEMO0733	Sule Bello	08057696941	\N	standard	5	2	0	0	\N	pending	unpaid	6000.00	\N	1221.00	0.00	\N	\N	f	\N	14	\N	2026-06-07 05:28:41.104	2026-06-07 05:28:41.104
734	1	4	148	DEMO0734	Yusuf Obiora	08069077275	\N	express	8	4	8	4	\N	completed	paid	15600.00	\N	676.00	15600.00	\N	\N	f	\N	16	\N	2026-03-10 05:28:41.117	2026-03-10 05:28:41.117
735	1	4	149	DEMO0735	Ngozi Alabi	08083898605	\N	premium	5	4	5	4	\N	completed	paid	15500.00	\N	\N	15500.00	\N	\N	f	\N	13	\N	2026-03-15 05:28:41.132	2026-03-15 05:28:41.132
736	1	4	160	DEMO0736	Aisha Bello	08092491205	\N	premium	2	5	2	5	\N	completed	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	13	\N	2026-04-28 05:28:41.138	2026-04-28 05:28:41.138
737	1	4	136	DEMO0737	Musa Obi	08030707134	\N	express	1	3	0	0	\N	ready	partial	5700.00	\N	\N	3420.00	\N	\N	f	\N	15	\N	2026-04-16 05:28:41.144	2026-04-16 05:28:41.144
738	1	4	147	DEMO0738	Ada Obiora	08018524555	\N	premium	4	3	4	3	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	15	\N	2026-03-12 05:28:41.151	2026-03-12 05:28:41.151
739	1	4	129	DEMO0739	Obinna Isa	08042459898	\N	express	3	1	0	0	\N	processing	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	16	\N	2026-04-18 05:28:41.158	2026-04-18 05:28:41.158
740	1	4	132	DEMO0740	Chioma Adeyemi	08031115790	\N	express	3	2	3	2	\N	completed	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	15	\N	2026-05-03 05:28:41.164	2026-05-03 05:28:41.164
741	1	4	126	DEMO0741	Seun Yusuf	08034658823	\N	premium	6	4	6	4	\N	completed	paid	17000.00	\N	\N	17000.00	\N	\N	f	\N	16	\N	2026-03-27 05:28:41.169	2026-03-27 05:28:41.169
742	1	4	121	DEMO0742	Ade Obiora	08039919323	\N	express	2	5	2	5	\N	completed	partial	9900.00	\N	\N	6237.00	\N	\N	f	\N	16	\N	2026-03-17 05:28:41.175	2026-03-17 05:28:41.175
743	1	4	150	DEMO0743	Ibrahim Lawal	08020290227	\N	premium	6	0	6	0	\N	completed	paid	9000.00	\N	301.00	9000.00	\N	\N	f	\N	14	\N	2026-03-14 05:28:41.182	2026-03-14 05:28:41.182
744	1	4	129	DEMO0744	Obinna Isa	08042459898	\N	premium	1	0	0	0	\N	pending	unpaid	1500.00	\N	1048.00	0.00	\N	\N	f	\N	15	\N	2026-05-20 05:28:41.2	2026-05-20 05:28:41.2
745	1	4	140	DEMO0745	Adaeze Danjuma	08095011255	\N	premium	6	4	0	0	\N	processing	unpaid	17000.00	\N	\N	0.00	\N	\N	f	\N	13	\N	2026-06-07 05:28:41.212	2026-06-07 05:28:41.212
746	1	4	143	DEMO0746	Chioma Ogundele	08092145379	\N	express	4	1	0	0	\N	processing	paid	6300.00	\N	\N	6300.00	\N	\N	f	\N	13	\N	2026-04-15 05:28:41.218	2026-04-15 05:28:41.218
747	1	4	147	DEMO0747	Ada Obiora	08018524555	\N	premium	1	4	1	4	\N	completed	paid	9500.00	\N	\N	9500.00	\N	\N	f	\N	13	\N	2026-03-12 05:28:41.224	2026-03-12 05:28:41.224
748	1	4	131	DEMO0748	Fatima Abubakar	08014900020	\N	standard	2	0	0	0	\N	ready	paid	1600.00	\N	354.00	1600.00	\N	\N	f	\N	16	\N	2026-04-25 05:28:41.23	2026-04-25 05:28:41.23
749	1	4	158	DEMO0749	Fatima Obiora	08045416657	\N	premium	4	0	0	0	\N	processing	paid	6000.00	\N	\N	6000.00	\N	\N	f	\N	14	\N	2026-05-15 05:28:41.241	2026-05-15 05:28:41.241
750	1	4	158	DEMO0750	Fatima Obiora	08045416657	\N	premium	7	0	0	0	\N	processing	partial	10500.00	\N	\N	6300.00	\N	\N	f	\N	16	\N	2026-04-27 05:28:41.247	2026-04-27 05:28:41.247
751	1	4	159	DEMO0751	Blessing Nwosu	08017410283	\N	express	1	5	0	0	\N	processing	partial	8700.00	\N	\N	4350.00	\N	\N	f	\N	14	\N	2026-05-02 05:28:41.257	2026-05-02 05:28:41.257
752	1	4	140	DEMO0752	Adaeze Danjuma	08095011255	\N	express	3	1	0	0	\N	processing	partial	5100.00	\N	623.00	1785.00	\N	\N	f	\N	15	\N	2026-06-05 05:28:41.262	2026-06-05 05:28:41.262
753	1	4	123	DEMO0753	Tobi Obiora	08090767138	\N	standard	3	3	0	0	\N	ready	unpaid	5400.00	\N	\N	0.00	\N	\N	f	\N	15	\N	2026-04-11 05:28:41.275	2026-04-11 05:28:41.275
754	1	4	133	DEMO0754	Chidi Ogundele	08036563927	\N	premium	5	5	5	5	\N	completed	paid	17500.00	\N	\N	17500.00	\N	\N	f	\N	14	\N	2026-03-22 05:28:41.279	2026-03-22 05:28:41.279
755	1	4	145	DEMO0755	Nkechi Isa	08072052162	\N	premium	4	1	4	1	\N	completed	paid	8000.00	\N	484.00	8000.00	\N	\N	f	\N	16	\N	2026-03-17 05:28:41.285	2026-03-17 05:28:41.285
756	1	4	157	DEMO0756	Tunde Nwosu	08080658899	\N	standard	8	3	8	3	\N	completed	paid	9400.00	\N	\N	9400.00	\N	\N	f	\N	13	\N	2026-04-06 05:28:41.297	2026-04-06 05:28:41.297
757	1	4	146	DEMO0757	Damilola Nwachukwu	08041295494	\N	standard	1	2	0	0	\N	processing	unpaid	2800.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-06-04 05:28:41.306	2026-06-04 05:28:41.306
758	1	4	145	DEMO0758	Nkechi Isa	08072052162	\N	premium	8	0	0	0	\N	ready	partial	12000.00	\N	\N	6480.00	\N	\N	f	\N	14	\N	2026-05-30 05:28:41.309	2026-05-30 05:28:41.309
759	1	4	158	DEMO0759	Fatima Obiora	08045416657	\N	standard	6	5	6	5	\N	completed	paid	9800.00	\N	\N	9800.00	\N	\N	f	\N	16	\N	2026-04-16 05:28:41.316	2026-04-16 05:28:41.316
760	1	4	128	DEMO0760	Ngozi Danjuma	08017811962	\N	express	5	4	0	0	\N	processing	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	14	\N	2026-05-28 05:28:41.322	2026-05-28 05:28:41.322
761	1	4	127	DEMO0761	Obinna Abubakar	08014057350	\N	standard	1	5	0	0	\N	processing	unpaid	5800.00	\N	\N	0.00	\N	\N	f	\N	15	\N	2026-05-26 05:28:41.328	2026-05-26 05:28:41.328
762	1	4	153	DEMO0762	Seun Obiora	08089855224	\N	premium	7	1	7	1	\N	completed	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	15	\N	2026-04-07 05:28:41.332	2026-04-07 05:28:41.332
763	1	4	154	DEMO0763	Aisha Isa	08064997562	\N	express	5	4	0	0	\N	ready	partial	12000.00	\N	\N	3720.00	\N	\N	f	\N	14	\N	2026-05-28 05:28:41.339	2026-05-28 05:28:41.339
764	1	4	154	DEMO0764	Aisha Isa	08064997562	\N	express	4	3	0	0	\N	processing	unpaid	9300.00	\N	\N	0.00	\N	\N	f	\N	16	\N	2026-04-27 05:28:41.345	2026-04-27 05:28:41.345
765	1	4	157	DEMO0765	Tunde Nwosu	08080658899	\N	express	6	3	6	3	\N	completed	paid	11700.00	\N	\N	11700.00	\N	\N	f	\N	13	\N	2026-03-15 05:28:41.351	2026-03-15 05:28:41.351
766	1	4	127	DEMO0766	Obinna Abubakar	08014057350	\N	express	1	0	1	0	\N	completed	partial	1200.00	\N	\N	516.00	\N	\N	f	\N	15	\N	2026-03-24 05:28:41.359	2026-03-24 05:28:41.359
767	1	4	146	DEMO0767	Damilola Nwachukwu	08041295494	\N	premium	1	0	1	0	\N	completed	paid	1500.00	\N	\N	1500.00	\N	\N	f	\N	13	\N	2026-03-23 05:28:41.371	2026-03-23 05:28:41.371
768	1	4	149	DEMO0768	Ngozi Alabi	08083898605	\N	premium	4	5	0	0	\N	pending	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	16	\N	2026-05-29 05:28:41.378	2026-05-29 05:28:41.378
769	1	4	134	DEMO0769	Obinna Adeyemi	08097105120	\N	express	2	5	2	5	\N	completed	paid	9900.00	\N	\N	9900.00	\N	\N	f	\N	16	\N	2026-04-08 05:28:41.385	2026-04-08 05:28:41.385
770	1	4	157	DEMO0770	Tunde Nwosu	08080658899	\N	premium	7	1	0	0	\N	processing	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	16	\N	2026-05-22 05:28:41.392	2026-05-22 05:28:41.392
771	1	4	125	DEMO0771	Chioma Nwachukwu	08046519602	\N	standard	1	0	0	0	\N	ready	partial	800.00	\N	\N	464.00	\N	\N	f	\N	13	\N	2026-05-27 05:28:41.398	2026-05-27 05:28:41.398
772	1	4	127	DEMO0772	Obinna Abubakar	08014057350	\N	express	1	4	1	4	\N	completed	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	13	\N	2026-03-17 05:28:41.407	2026-03-17 05:28:41.407
773	1	4	133	DEMO0773	Chidi Ogundele	08036563927	\N	express	3	4	0	0	\N	pending	unpaid	9600.00	\N	\N	0.00	\N	\N	f	\N	16	\N	2026-05-21 05:28:41.415	2026-05-21 05:28:41.415
774	1	4	139	DEMO0774	Kunle Obi	08055367578	\N	premium	3	4	0	0	\N	ready	partial	12500.00	\N	\N	7750.00	\N	\N	f	\N	15	\N	2026-05-03 05:28:41.419	2026-05-03 05:28:41.419
775	1	4	143	DEMO0775	Chioma Ogundele	08092145379	\N	express	4	3	4	3	\N	completed	paid	9300.00	\N	\N	9300.00	\N	\N	f	\N	13	\N	2026-04-06 05:28:41.425	2026-04-06 05:28:41.425
776	1	4	130	DEMO0776	Ifeoma Adeyemi	08024091314	\N	premium	7	4	0	0	\N	pending	partial	18500.00	\N	\N	11285.00	\N	\N	f	\N	16	\N	2026-05-28 05:28:41.431	2026-05-28 05:28:41.431
777	1	4	143	DEMO0777	Chioma Ogundele	08092145379	\N	express	5	1	0	0	\N	pending	unpaid	7500.00	\N	\N	0.00	\N	\N	f	\N	15	\N	2026-05-13 05:28:41.437	2026-05-13 05:28:41.437
778	1	4	159	DEMO0778	Blessing Nwosu	08017410283	\N	express	2	0	0	0	\N	ready	unpaid	2400.00	\N	\N	0.00	\N	\N	f	\N	14	\N	2026-05-22 05:28:41.44	2026-05-22 05:28:41.44
779	1	4	135	DEMO0779	Fatima Alabi	08096074419	\N	express	5	4	5	4	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	16	\N	2026-04-04 05:28:41.443	2026-04-04 05:28:41.443
780	1	4	150	DEMO0780	Ibrahim Lawal	08020290227	\N	standard	8	3	0	0	\N	pending	partial	9400.00	\N	\N	4324.00	\N	\N	f	\N	16	\N	2026-05-30 05:28:41.448	2026-05-30 05:28:41.448
781	1	4	158	DEMO0781	Fatima Obiora	08045416657	\N	express	5	1	5	1	\N	completed	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	14	\N	2026-03-12 05:28:41.453	2026-03-12 05:28:41.453
782	1	4	130	DEMO0782	Ifeoma Adeyemi	08024091314	\N	express	8	5	8	5	\N	completed	paid	17100.00	\N	\N	17100.00	\N	\N	f	\N	13	\N	2026-03-20 05:28:41.459	2026-03-20 05:28:41.459
783	1	4	157	DEMO0783	Tunde Nwosu	08080658899	\N	premium	8	0	0	0	\N	ready	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	16	\N	2026-05-13 05:28:41.464	2026-05-13 05:28:41.464
784	1	4	133	DEMO0784	Chidi Ogundele	08036563927	\N	express	8	0	0	0	\N	pending	unpaid	9600.00	\N	\N	0.00	\N	\N	f	\N	15	\N	2026-06-01 05:28:41.473	2026-06-01 05:28:41.473
785	1	4	127	DEMO0785	Obinna Abubakar	08014057350	\N	standard	7	3	0	0	\N	processing	partial	8600.00	\N	\N	3956.00	\N	\N	f	\N	14	\N	2026-04-23 05:28:41.476	2026-04-23 05:28:41.476
786	1	4	148	DEMO0786	Yusuf Obiora	08069077275	\N	premium	8	5	0	0	\N	ready	partial	22000.00	\N	281.00	14300.00	\N	\N	f	\N	15	\N	2026-05-02 05:28:41.484	2026-05-02 05:28:41.484
787	1	4	154	DEMO0787	Aisha Isa	08064997562	\N	premium	8	5	0	0	\N	ready	paid	22000.00	\N	\N	22000.00	\N	\N	f	\N	16	\N	2026-04-12 05:28:41.495	2026-04-12 05:28:41.495
788	1	4	139	DEMO0788	Kunle Obi	08055367578	\N	express	7	3	0	0	\N	processing	partial	12900.00	\N	\N	4257.00	\N	\N	f	\N	16	\N	2026-06-02 05:28:41.501	2026-06-02 05:28:41.501
789	1	4	137	DEMO0789	Sule Musa	08061440233	\N	standard	6	4	6	4	\N	completed	paid	8800.00	\N	\N	8800.00	\N	\N	f	\N	14	\N	2026-03-11 05:28:41.507	2026-03-11 05:28:41.507
790	1	4	153	DEMO0790	Seun Obiora	08089855224	\N	standard	5	4	0	0	\N	processing	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	13	\N	2026-05-26 05:28:41.513	2026-05-26 05:28:41.513
791	1	4	131	DEMO0791	Fatima Abubakar	08014900020	\N	express	7	2	7	2	\N	completed	paid	11400.00	\N	\N	11400.00	\N	\N	f	\N	14	\N	2026-04-07 05:28:41.519	2026-04-07 05:28:41.519
792	1	4	140	DEMO0792	Adaeze Danjuma	08095011255	\N	premium	8	4	8	4	\N	completed	paid	20000.00	\N	\N	20000.00	\N	\N	f	\N	14	\N	2026-03-30 05:28:41.525	2026-03-30 05:28:41.525
793	1	4	122	DEMO0793	Nkechi Bello	08075507131	\N	premium	2	1	0	0	\N	processing	unpaid	5000.00	\N	720.00	0.00	\N	\N	f	\N	14	\N	2026-05-10 05:28:41.532	2026-05-10 05:28:41.532
794	1	4	129	DEMO0794	Obinna Isa	08042459898	\N	express	5	1	0	0	\N	ready	unpaid	7500.00	\N	\N	0.00	\N	\N	f	\N	15	\N	2026-05-17 05:28:41.543	2026-05-17 05:28:41.543
795	1	4	158	DEMO0795	Fatima Obiora	08045416657	\N	premium	8	5	0	0	\N	pending	paid	22000.00	\N	\N	22000.00	\N	\N	f	\N	14	\N	2026-06-05 05:28:41.546	2026-06-05 05:28:41.546
796	1	4	130	DEMO0796	Ifeoma Adeyemi	08024091314	\N	premium	8	4	0	0	\N	processing	unpaid	20000.00	\N	\N	0.00	\N	\N	f	\N	13	\N	2026-06-04 05:28:41.552	2026-06-04 05:28:41.552
797	1	4	154	DEMO0797	Aisha Isa	08064997562	\N	standard	5	3	0	0	\N	pending	partial	7000.00	\N	\N	3360.00	\N	\N	f	\N	15	\N	2026-05-27 05:28:41.556	2026-05-27 05:28:41.556
798	1	4	146	DEMO0798	Damilola Nwachukwu	08041295494	\N	express	8	3	8	3	\N	completed	paid	14100.00	\N	\N	14100.00	\N	\N	f	\N	15	\N	2026-03-15 05:28:41.562	2026-03-15 05:28:41.562
799	1	4	140	DEMO0799	Adaeze Danjuma	08095011255	\N	premium	7	0	0	0	\N	ready	unpaid	10500.00	\N	406.00	0.00	\N	\N	f	\N	16	\N	2026-05-21 05:28:41.568	2026-05-21 05:28:41.568
800	1	4	148	DEMO0800	Yusuf Obiora	08069077275	\N	premium	5	5	0	0	\N	ready	partial	17500.00	\N	\N	8400.00	\N	\N	f	\N	14	\N	2026-05-13 05:28:41.577	2026-05-13 05:28:41.577
801	1	5	161	DEMO0801	Ibrahim Eze	08010576660	\N	express	1	0	0	0	\N	processing	unpaid	1200.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-05-31 05:28:41.65	2026-05-31 05:28:41.65
802	1	5	184	DEMO0802	Amaka Babatunde	08037261442	\N	standard	1	0	1	0	\N	completed	paid	800.00	\N	489.00	800.00	\N	\N	f	\N	18	\N	2026-03-12 05:28:41.654	2026-03-12 05:28:41.654
803	1	5	199	DEMO0803	Obinna Adeyemi	08065868029	\N	express	7	1	7	1	\N	completed	paid	9900.00	\N	\N	9900.00	\N	\N	f	\N	17	\N	2026-04-02 05:28:41.666	2026-04-02 05:28:41.666
804	1	5	186	DEMO0804	Babajide Nwachukwu	08036315726	\N	premium	8	4	0	0	\N	ready	partial	20000.00	\N	\N	11000.00	\N	\N	f	\N	18	\N	2026-04-21 05:28:41.673	2026-04-21 05:28:41.673
805	1	5	170	DEMO0805	Ade Bello	08093905925	\N	express	7	0	0	0	\N	pending	partial	8400.00	\N	\N	5292.00	\N	\N	f	\N	17	\N	2026-06-01 05:28:41.68	2026-06-01 05:28:41.68
806	1	5	169	DEMO0806	Yusuf Nwosu	08081055103	\N	standard	3	3	3	3	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	19	\N	2026-05-06 05:28:41.686	2026-05-06 05:28:41.686
807	1	5	199	DEMO0807	Obinna Adeyemi	08065868029	\N	premium	4	2	4	2	\N	completed	partial	10000.00	\N	\N	4900.00	\N	\N	f	\N	19	\N	2026-03-18 05:28:41.693	2026-03-18 05:28:41.693
808	1	5	189	DEMO0808	Halima Okafor	08083663184	\N	standard	7	4	0	0	\N	processing	unpaid	9600.00	\N	\N	0.00	\N	\N	f	\N	17	\N	2026-05-08 05:28:41.699	2026-05-08 05:28:41.699
809	1	5	168	DEMO0809	Yusuf Yusuf	08047630361	\N	standard	7	2	7	2	\N	completed	paid	7600.00	\N	\N	7600.00	\N	\N	f	\N	17	\N	2026-04-17 05:28:41.703	2026-04-17 05:28:41.703
810	1	5	183	DEMO0810	Seun Nwosu	08054361022	\N	express	3	3	0	0	\N	processing	partial	8100.00	\N	1278.00	3726.00	\N	\N	f	\N	18	\N	2026-05-07 05:28:41.708	2026-05-07 05:28:41.708
811	1	5	161	DEMO0811	Ibrahim Eze	08010576660	\N	express	2	0	2	0	\N	completed	paid	2400.00	\N	\N	2400.00	\N	\N	f	\N	19	\N	2026-03-26 05:28:41.721	2026-03-26 05:28:41.721
812	1	5	173	DEMO0812	Musa Lawal	08074336026	\N	premium	7	4	0	0	\N	pending	paid	18500.00	\N	\N	18500.00	\N	\N	f	\N	17	\N	2026-05-15 05:28:41.727	2026-05-15 05:28:41.727
813	1	5	195	DEMO0813	Kunle Chukwu	08099811347	\N	standard	2	2	0	0	\N	processing	unpaid	3600.00	\N	\N	0.00	\N	\N	f	\N	17	\N	2026-05-10 05:28:41.733	2026-05-10 05:28:41.733
814	1	5	168	DEMO0814	Yusuf Yusuf	08047630361	\N	express	7	1	0	0	\N	processing	paid	9900.00	\N	\N	9900.00	\N	\N	f	\N	19	\N	2026-04-19 05:28:41.736	2026-04-19 05:28:41.736
815	1	5	175	DEMO0815	Amaka Chukwu	08035042054	\N	express	2	4	2	4	\N	completed	paid	8400.00	\N	543.00	8400.00	\N	\N	f	\N	18	\N	2026-04-30 05:28:41.742	2026-04-30 05:28:41.742
816	1	5	200	DEMO0816	Ifeoma Chukwu	08092117040	\N	express	4	0	0	0	\N	processing	partial	4800.00	\N	\N	2592.00	\N	\N	f	\N	20	\N	2026-04-21 05:28:41.757	2026-04-21 05:28:41.757
817	1	5	163	DEMO0817	Kunle Usman	08033482932	\N	express	2	5	0	0	\N	processing	partial	9900.00	\N	251.00	5841.00	\N	\N	f	\N	18	\N	2026-05-20 05:28:41.767	2026-05-20 05:28:41.767
818	1	5	194	DEMO0818	Yusuf Nwachukwu	08050231307	\N	standard	1	4	1	4	\N	completed	paid	4800.00	\N	\N	4800.00	\N	\N	f	\N	19	\N	2026-05-01 05:28:41.778	2026-05-01 05:28:41.778
819	1	5	161	DEMO0819	Ibrahim Eze	08010576660	\N	premium	4	3	4	3	\N	completed	partial	12000.00	\N	100.00	4200.00	\N	\N	f	\N	19	\N	2026-03-11 05:28:41.784	2026-03-11 05:28:41.784
820	1	5	194	DEMO0820	Yusuf Nwachukwu	08050231307	\N	express	3	2	0	0	\N	ready	unpaid	6600.00	\N	\N	0.00	\N	\N	f	\N	17	\N	2026-05-22 05:28:41.795	2026-05-22 05:28:41.795
821	1	5	188	DEMO0821	Ngozi Yusuf	08031288283	\N	express	5	1	0	0	\N	processing	unpaid	7500.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-04-17 05:28:41.799	2026-04-17 05:28:41.799
822	1	5	176	DEMO0822	Zainab Isa	08052587089	\N	premium	5	0	0	0	\N	processing	partial	7500.00	\N	\N	4500.00	\N	\N	f	\N	20	\N	2026-05-13 05:28:41.803	2026-05-13 05:28:41.803
823	1	5	177	DEMO0823	Nkechi Danjuma	08077427116	\N	standard	3	2	0	0	\N	ready	unpaid	4400.00	\N	401.00	0.00	\N	\N	f	\N	18	\N	2026-04-20 05:28:41.814	2026-04-20 05:28:41.814
824	1	5	175	DEMO0824	Amaka Chukwu	08035042054	\N	premium	3	5	3	5	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	20	\N	2026-03-31 05:28:41.827	2026-03-31 05:28:41.827
825	1	5	162	DEMO0825	Adaeze Bello	08026219065	\N	premium	3	2	0	0	\N	pending	partial	8500.00	\N	\N	5185.00	\N	\N	f	\N	19	\N	2026-05-20 05:28:41.832	2026-05-20 05:28:41.832
826	1	5	178	DEMO0826	Tunde Ogundele	08044376215	\N	standard	8	3	0	0	\N	processing	partial	9400.00	\N	\N	4606.00	\N	\N	f	\N	19	\N	2026-04-28 05:28:41.839	2026-04-28 05:28:41.839
827	1	5	177	DEMO0827	Nkechi Danjuma	08077427116	\N	premium	3	1	3	1	\N	completed	paid	6500.00	\N	\N	6500.00	\N	\N	f	\N	18	\N	2026-04-03 05:28:41.846	2026-04-03 05:28:41.846
828	1	5	174	DEMO0828	Ngozi Ogundele	08087238328	\N	standard	5	5	0	0	\N	ready	partial	9000.00	\N	\N	4140.00	\N	\N	f	\N	18	\N	2026-05-09 05:28:41.852	2026-05-09 05:28:41.852
829	1	5	164	DEMO0829	Nkechi Ogundele	08056305833	\N	express	3	1	0	0	\N	ready	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	20	\N	2026-04-18 05:28:41.858	2026-04-18 05:28:41.858
830	1	5	192	DEMO0830	Obinna Yusuf	08066331422	\N	premium	7	5	0	0	\N	processing	partial	20500.00	\N	232.00	12095.00	\N	\N	f	\N	17	\N	2026-04-26 05:28:41.864	2026-04-26 05:28:41.864
831	1	5	183	DEMO0831	Seun Nwosu	08054361022	\N	standard	4	5	4	5	\N	completed	paid	8200.00	\N	\N	8200.00	\N	\N	f	\N	20	\N	2026-03-20 05:28:41.876	2026-03-20 05:28:41.876
832	1	5	175	DEMO0832	Amaka Chukwu	08035042054	\N	express	5	0	0	0	\N	processing	partial	6000.00	\N	\N	2760.00	\N	\N	f	\N	18	\N	2026-04-23 05:28:41.885	2026-04-23 05:28:41.885
833	1	5	197	DEMO0833	Zainab Ogundele	08087548400	\N	express	5	2	5	2	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	20	\N	2026-04-01 05:28:41.893	2026-04-01 05:28:41.893
834	1	5	196	DEMO0834	Blessing Adeyemi	08041267520	\N	premium	5	2	5	2	\N	completed	paid	11500.00	\N	\N	11500.00	\N	\N	f	\N	20	\N	2026-04-27 05:28:41.9	2026-04-27 05:28:41.9
835	1	5	194	DEMO0835	Yusuf Nwachukwu	08050231307	\N	premium	3	4	0	0	\N	ready	unpaid	12500.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-04-19 05:28:41.906	2026-04-19 05:28:41.906
836	1	5	188	DEMO0836	Ngozi Yusuf	08031288283	\N	standard	1	0	1	0	\N	completed	paid	800.00	\N	\N	800.00	\N	\N	f	\N	20	\N	2026-03-31 05:28:41.91	2026-03-31 05:28:41.91
837	1	5	176	DEMO0837	Zainab Isa	08052587089	\N	express	2	1	2	1	\N	completed	paid	3900.00	\N	\N	3900.00	\N	\N	f	\N	20	\N	2026-03-29 05:28:41.916	2026-03-29 05:28:41.916
838	1	5	196	DEMO0838	Blessing Adeyemi	08041267520	\N	standard	2	0	2	0	\N	completed	partial	1600.00	\N	\N	1056.00	\N	\N	f	\N	17	\N	2026-04-21 05:28:41.922	2026-04-21 05:28:41.922
839	1	5	187	DEMO0839	Kunle Chukwu	08081914480	\N	express	6	4	0	0	\N	pending	paid	13200.00	\N	\N	13200.00	\N	\N	f	\N	18	\N	2026-06-02 05:28:41.927	2026-06-02 05:28:41.927
840	1	5	166	DEMO0840	Zainab Babatunde	08049614566	\N	express	8	0	8	0	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	18	\N	2026-03-19 05:28:41.933	2026-03-19 05:28:41.933
841	1	5	172	DEMO0841	Damilola Bello	08043980356	\N	standard	2	0	0	0	\N	processing	unpaid	1600.00	\N	\N	0.00	\N	\N	f	\N	19	\N	2026-04-18 05:28:41.939	2026-04-18 05:28:41.939
842	1	5	171	DEMO0842	Nneka Ogundele	08087732519	\N	express	4	4	4	4	\N	completed	paid	10800.00	\N	\N	10800.00	\N	\N	f	\N	20	\N	2026-03-28 05:28:41.942	2026-03-28 05:28:41.942
843	1	5	183	DEMO0843	Seun Nwosu	08054361022	\N	premium	2	3	2	3	\N	completed	paid	9000.00	\N	1394.00	9000.00	\N	\N	f	\N	17	\N	2026-05-01 05:28:41.949	2026-05-01 05:28:41.949
844	1	5	196	DEMO0844	Blessing Adeyemi	08041267520	\N	premium	8	5	8	5	\N	completed	paid	22000.00	\N	\N	22000.00	\N	\N	f	\N	17	\N	2026-03-28 05:28:41.964	2026-03-28 05:28:41.964
845	1	5	182	DEMO0845	Yusuf Abubakar	08081054640	\N	premium	3	4	0	0	\N	pending	unpaid	12500.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-05-22 05:28:41.97	2026-05-22 05:28:41.97
846	1	5	174	DEMO0846	Ngozi Ogundele	08087238328	\N	premium	4	3	4	3	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	19	\N	2026-04-25 05:28:41.973	2026-04-25 05:28:41.973
847	1	5	171	DEMO0847	Nneka Ogundele	08087732519	\N	standard	3	3	0	0	\N	ready	unpaid	5400.00	\N	306.00	0.00	\N	\N	f	\N	19	\N	2026-05-11 05:28:41.979	2026-05-11 05:28:41.979
848	1	5	182	DEMO0848	Yusuf Abubakar	08081054640	\N	express	7	3	7	3	\N	completed	paid	12900.00	\N	939.00	12900.00	\N	\N	f	\N	17	\N	2026-03-18 05:28:41.988	2026-03-18 05:28:41.988
849	1	5	182	DEMO0849	Yusuf Abubakar	08081054640	\N	standard	4	1	0	0	\N	processing	partial	4200.00	\N	403.00	2058.00	\N	\N	f	\N	20	\N	2026-06-07 05:28:42.001	2026-06-07 05:28:42.001
850	1	5	192	DEMO0850	Obinna Yusuf	08066331422	\N	standard	4	2	4	2	\N	completed	paid	5200.00	\N	\N	5200.00	\N	\N	f	\N	18	\N	2026-03-14 05:28:42.015	2026-03-14 05:28:42.015
851	1	5	178	DEMO0851	Tunde Ogundele	08044376215	\N	express	4	2	0	0	\N	processing	partial	7800.00	\N	\N	5148.00	\N	\N	f	\N	20	\N	2026-04-22 05:28:42.023	2026-04-22 05:28:42.023
852	1	5	184	DEMO0852	Amaka Babatunde	08037261442	\N	premium	6	2	0	0	\N	processing	paid	13000.00	\N	\N	13000.00	\N	\N	f	\N	18	\N	2026-04-19 05:28:42.029	2026-04-19 05:28:42.029
853	1	5	175	DEMO0853	Amaka Chukwu	08035042054	\N	standard	8	1	0	0	\N	processing	partial	7400.00	\N	\N	4736.00	\N	\N	f	\N	17	\N	2026-05-22 05:28:42.036	2026-05-22 05:28:42.036
854	1	5	175	DEMO0854	Amaka Chukwu	08035042054	\N	premium	4	5	4	5	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	19	\N	2026-03-13 05:28:42.043	2026-03-13 05:28:42.043
855	1	5	169	DEMO0855	Yusuf Nwosu	08081055103	\N	standard	6	5	6	5	\N	completed	paid	9800.00	\N	\N	9800.00	\N	\N	f	\N	19	\N	2026-05-01 05:28:42.049	2026-05-01 05:28:42.049
856	1	5	195	DEMO0856	Kunle Chukwu	08099811347	\N	express	5	5	0	0	\N	processing	paid	13500.00	\N	523.00	13500.00	\N	\N	f	\N	19	\N	2026-06-03 05:28:42.055	2026-06-03 05:28:42.055
857	1	5	161	DEMO0857	Ibrahim Eze	08010576660	\N	premium	5	5	5	5	\N	completed	paid	17500.00	\N	\N	17500.00	\N	\N	f	\N	19	\N	2026-04-17 05:28:42.07	2026-04-17 05:28:42.07
858	1	5	185	DEMO0858	Amaka Usman	08075158960	\N	express	6	0	0	0	\N	ready	partial	7200.00	\N	\N	4680.00	\N	\N	f	\N	19	\N	2026-05-26 05:28:42.077	2026-05-26 05:28:42.077
859	1	5	178	DEMO0859	Tunde Ogundele	08044376215	\N	premium	3	4	3	4	\N	completed	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	17	\N	2026-04-12 05:28:42.083	2026-04-12 05:28:42.083
860	1	5	198	DEMO0860	Ade Nwachukwu	08066938509	\N	express	4	0	0	0	\N	ready	partial	4800.00	\N	\N	2880.00	\N	\N	f	\N	19	\N	2026-05-16 05:28:42.092	2026-05-16 05:28:42.092
861	1	5	192	DEMO0861	Obinna Yusuf	08066331422	\N	express	6	1	6	1	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	19	\N	2026-04-05 05:28:42.098	2026-04-05 05:28:42.098
862	1	5	169	DEMO0862	Yusuf Nwosu	08081055103	\N	standard	7	3	0	0	\N	ready	partial	8600.00	\N	\N	5762.00	\N	\N	f	\N	20	\N	2026-04-21 05:28:42.104	2026-04-21 05:28:42.104
863	1	5	173	DEMO0863	Musa Lawal	08074336026	\N	premium	7	2	7	2	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	19	\N	2026-03-12 05:28:42.11	2026-03-12 05:28:42.11
864	1	5	174	DEMO0864	Ngozi Ogundele	08087238328	\N	express	3	3	0	0	\N	processing	paid	8100.00	\N	\N	8100.00	\N	\N	f	\N	20	\N	2026-05-10 05:28:42.116	2026-05-10 05:28:42.116
865	1	5	200	DEMO0865	Ifeoma Chukwu	08092117040	\N	premium	5	1	0	0	\N	ready	partial	9500.00	\N	\N	6270.00	\N	\N	f	\N	18	\N	2026-04-30 05:28:42.122	2026-04-30 05:28:42.122
866	1	5	166	DEMO0866	Zainab Babatunde	08049614566	\N	premium	2	1	0	0	\N	pending	partial	5000.00	\N	\N	2450.00	\N	\N	f	\N	17	\N	2026-06-04 05:28:42.128	2026-06-04 05:28:42.128
867	1	5	181	DEMO0867	Obinna Bello	08035799549	\N	premium	4	1	4	1	\N	completed	paid	8000.00	\N	\N	8000.00	\N	\N	f	\N	17	\N	2026-03-17 05:28:42.133	2026-03-17 05:28:42.133
868	1	5	176	DEMO0868	Zainab Isa	08052587089	\N	standard	2	3	0	0	\N	pending	unpaid	4600.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-06-03 05:28:42.14	2026-06-03 05:28:42.14
869	1	5	178	DEMO0869	Tunde Ogundele	08044376215	\N	express	8	4	0	0	\N	pending	paid	15600.00	\N	144.00	15600.00	\N	\N	f	\N	20	\N	2026-06-07 05:28:42.143	2026-06-07 05:28:42.143
870	1	5	199	DEMO0870	Obinna Adeyemi	08065868029	\N	standard	3	3	0	0	\N	ready	unpaid	5400.00	\N	\N	0.00	\N	\N	f	\N	17	\N	2026-04-11 05:28:42.158	2026-04-11 05:28:42.158
871	1	5	191	DEMO0871	Fatima Babatunde	08079841604	\N	express	8	3	0	0	\N	ready	paid	14100.00	\N	167.00	14100.00	\N	\N	f	\N	17	\N	2026-05-25 05:28:42.161	2026-05-25 05:28:42.161
872	1	5	167	DEMO0872	Kunle Danjuma	08089275674	\N	standard	7	4	0	0	\N	ready	unpaid	9600.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-04-13 05:28:42.173	2026-04-13 05:28:42.173
873	1	5	177	DEMO0873	Nkechi Danjuma	08077427116	\N	standard	3	2	0	0	\N	ready	unpaid	4400.00	\N	\N	0.00	\N	\N	f	\N	19	\N	2026-05-27 05:28:42.181	2026-05-27 05:28:42.181
874	1	5	200	DEMO0874	Ifeoma Chukwu	08092117040	\N	express	3	1	3	1	\N	completed	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	19	\N	2026-04-17 05:28:42.184	2026-04-17 05:28:42.184
875	1	5	178	DEMO0875	Tunde Ogundele	08044376215	\N	standard	3	3	3	3	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	19	\N	2026-04-07 05:28:42.19	2026-04-07 05:28:42.19
876	1	5	200	DEMO0876	Ifeoma Chukwu	08092117040	\N	standard	3	2	0	0	\N	ready	partial	4400.00	\N	1268.00	1364.00	\N	\N	f	\N	17	\N	2026-04-28 05:28:42.196	2026-04-28 05:28:42.196
877	1	5	161	DEMO0877	Ibrahim Eze	08010576660	\N	standard	1	1	0	0	\N	pending	partial	1800.00	\N	\N	1116.00	\N	\N	f	\N	20	\N	2026-05-10 05:28:42.21	2026-05-10 05:28:42.21
878	1	5	187	DEMO0878	Kunle Chukwu	08081914480	\N	premium	8	2	8	2	\N	completed	paid	16000.00	\N	\N	16000.00	\N	\N	f	\N	20	\N	2026-05-04 05:28:42.22	2026-05-04 05:28:42.22
879	1	5	174	DEMO0879	Ngozi Ogundele	08087238328	\N	standard	2	3	0	0	\N	processing	partial	4600.00	\N	\N	2622.00	\N	\N	f	\N	17	\N	2026-05-24 05:28:42.226	2026-05-24 05:28:42.226
880	1	5	186	DEMO0880	Babajide Nwachukwu	08036315726	\N	express	4	1	0	0	\N	pending	unpaid	6300.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-05-13 05:28:42.232	2026-05-13 05:28:42.232
881	1	5	200	DEMO0881	Ifeoma Chukwu	08092117040	\N	express	5	4	5	4	\N	completed	paid	12000.00	\N	348.00	12000.00	\N	\N	f	\N	20	\N	2026-04-12 05:28:42.235	2026-04-12 05:28:42.235
882	1	5	164	DEMO0882	Nkechi Ogundele	08056305833	\N	premium	3	0	0	0	\N	processing	paid	4500.00	\N	\N	4500.00	\N	\N	f	\N	20	\N	2026-04-12 05:28:42.246	2026-04-12 05:28:42.246
883	1	5	196	DEMO0883	Blessing Adeyemi	08041267520	\N	standard	3	0	0	0	\N	ready	partial	2400.00	\N	\N	1584.00	\N	\N	f	\N	20	\N	2026-04-11 05:28:42.252	2026-04-11 05:28:42.252
884	1	5	165	DEMO0884	Kunle Obi	08033158761	\N	express	1	2	0	0	\N	processing	partial	4200.00	\N	448.00	2688.00	\N	\N	f	\N	20	\N	2026-06-06 05:28:42.257	2026-06-06 05:28:42.257
885	1	5	197	DEMO0885	Zainab Ogundele	08087548400	\N	express	1	1	0	0	\N	ready	partial	2700.00	\N	\N	1404.00	\N	\N	f	\N	18	\N	2026-05-03 05:28:42.27	2026-05-03 05:28:42.27
886	1	5	183	DEMO0886	Seun Nwosu	08054361022	\N	express	5	0	5	0	\N	completed	partial	6000.00	\N	\N	3720.00	\N	\N	f	\N	18	\N	2026-04-07 05:28:42.276	2026-04-07 05:28:42.276
887	1	5	168	DEMO0887	Yusuf Yusuf	08047630361	\N	express	1	2	0	0	\N	processing	paid	4200.00	\N	\N	4200.00	\N	\N	f	\N	20	\N	2026-04-11 05:28:42.282	2026-04-11 05:28:42.282
888	1	5	191	DEMO0888	Fatima Babatunde	08079841604	\N	premium	7	0	0	0	\N	processing	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	18	\N	2026-04-27 05:28:42.288	2026-04-27 05:28:42.288
889	1	5	185	DEMO0889	Amaka Usman	08075158960	\N	standard	1	3	0	0	\N	ready	paid	3800.00	\N	\N	3800.00	\N	\N	f	\N	18	\N	2026-05-21 05:28:42.294	2026-05-21 05:28:42.294
890	1	5	179	DEMO0890	Seun Babatunde	08044178474	\N	standard	5	5	5	5	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	19	\N	2026-03-19 05:28:42.299	2026-03-19 05:28:42.299
891	1	5	186	DEMO0891	Babajide Nwachukwu	08036315726	\N	premium	5	0	5	0	\N	completed	paid	7500.00	\N	\N	7500.00	\N	\N	f	\N	17	\N	2026-03-31 05:28:42.305	2026-03-31 05:28:42.305
892	1	5	194	DEMO0892	Yusuf Nwachukwu	08050231307	\N	express	8	2	8	2	\N	completed	paid	12600.00	\N	\N	12600.00	\N	\N	f	\N	20	\N	2026-03-22 05:28:42.314	2026-03-22 05:28:42.314
893	1	5	189	DEMO0893	Halima Okafor	08083663184	\N	premium	5	5	5	5	\N	completed	paid	17500.00	\N	\N	17500.00	\N	\N	f	\N	20	\N	2026-04-07 05:28:42.321	2026-04-07 05:28:42.321
894	1	5	168	DEMO0894	Yusuf Yusuf	08047630361	\N	premium	8	1	0	0	\N	ready	partial	14000.00	\N	\N	4900.00	\N	\N	f	\N	17	\N	2026-04-13 05:28:42.327	2026-04-13 05:28:42.327
895	1	5	182	DEMO0895	Yusuf Abubakar	08081054640	\N	premium	8	0	8	0	\N	completed	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	18	\N	2026-04-04 05:28:42.334	2026-04-04 05:28:42.334
896	1	5	194	DEMO0896	Yusuf Nwachukwu	08050231307	\N	premium	8	0	0	0	\N	processing	paid	12000.00	\N	\N	12000.00	\N	\N	f	\N	20	\N	2026-06-05 05:28:42.342	2026-06-05 05:28:42.342
897	1	5	194	DEMO0897	Yusuf Nwachukwu	08050231307	\N	premium	6	4	0	0	\N	ready	unpaid	17000.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-05-21 05:28:42.348	2026-05-21 05:28:42.348
898	1	5	170	DEMO0898	Ade Bello	08093905925	\N	standard	6	3	0	0	\N	processing	partial	7800.00	\N	\N	2418.00	\N	\N	f	\N	20	\N	2026-05-29 05:28:42.352	2026-05-29 05:28:42.352
899	1	5	199	DEMO0899	Obinna Adeyemi	08065868029	\N	standard	7	3	7	3	\N	completed	paid	8600.00	\N	\N	8600.00	\N	\N	f	\N	19	\N	2026-04-25 05:28:42.36	2026-04-25 05:28:42.36
900	1	5	181	DEMO0900	Obinna Bello	08035799549	\N	premium	3	5	3	5	\N	completed	partial	14500.00	\N	\N	8845.00	\N	\N	f	\N	20	\N	2026-05-01 05:28:42.367	2026-05-01 05:28:42.367
901	1	5	185	DEMO0901	Amaka Usman	08075158960	\N	standard	4	3	0	0	\N	ready	unpaid	6200.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-04-13 05:28:42.374	2026-04-13 05:28:42.374
902	1	5	197	DEMO0902	Zainab Ogundele	08087548400	\N	standard	6	5	0	0	\N	processing	paid	9800.00	\N	\N	9800.00	\N	\N	f	\N	19	\N	2026-05-28 05:28:42.376	2026-05-28 05:28:42.376
903	1	5	178	DEMO0903	Tunde Ogundele	08044376215	\N	express	3	1	3	1	\N	completed	paid	5100.00	\N	\N	5100.00	\N	\N	f	\N	18	\N	2026-03-24 05:28:42.383	2026-03-24 05:28:42.383
904	1	5	187	DEMO0904	Kunle Chukwu	08081914480	\N	express	5	5	0	0	\N	processing	paid	13500.00	\N	155.00	13500.00	\N	\N	f	\N	19	\N	2026-05-15 05:28:42.389	2026-05-15 05:28:42.389
905	1	5	179	DEMO0905	Seun Babatunde	08044178474	\N	express	3	4	0	0	\N	ready	partial	9600.00	\N	\N	5664.00	\N	\N	f	\N	20	\N	2026-05-26 05:28:42.399	2026-05-26 05:28:42.399
906	1	5	198	DEMO0906	Ade Nwachukwu	08066938509	\N	premium	3	4	0	0	\N	ready	paid	12500.00	\N	\N	12500.00	\N	\N	f	\N	18	\N	2026-05-24 05:28:42.408	2026-05-24 05:28:42.408
907	1	5	174	DEMO0907	Ngozi Ogundele	08087238328	\N	standard	1	2	1	2	\N	completed	paid	2800.00	\N	\N	2800.00	\N	\N	f	\N	19	\N	2026-05-07 05:28:42.414	2026-05-07 05:28:42.414
908	1	5	177	DEMO0908	Nkechi Danjuma	08077427116	\N	express	6	5	0	0	\N	ready	unpaid	14700.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-05-07 05:28:42.42	2026-05-07 05:28:42.42
909	1	5	184	DEMO0909	Amaka Babatunde	08037261442	\N	standard	7	1	7	1	\N	completed	partial	6600.00	\N	\N	2508.00	\N	\N	f	\N	20	\N	2026-03-17 05:28:42.424	2026-03-17 05:28:42.424
910	1	5	177	DEMO0910	Nkechi Danjuma	08077427116	\N	premium	7	2	0	0	\N	ready	unpaid	14500.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-04-14 05:28:42.429	2026-04-14 05:28:42.429
911	1	5	167	DEMO0911	Kunle Danjuma	08089275674	\N	express	6	5	0	0	\N	ready	paid	14700.00	\N	\N	14700.00	\N	\N	f	\N	19	\N	2026-04-29 05:28:42.435	2026-04-29 05:28:42.435
912	1	5	199	DEMO0912	Obinna Adeyemi	08065868029	\N	premium	2	3	2	3	\N	completed	paid	9000.00	\N	\N	9000.00	\N	\N	f	\N	19	\N	2026-03-29 05:28:42.441	2026-03-29 05:28:42.441
913	1	5	199	DEMO0913	Obinna Adeyemi	08065868029	\N	premium	3	1	0	0	\N	ready	unpaid	6500.00	\N	\N	0.00	\N	\N	f	\N	18	\N	2026-05-29 05:28:42.446	2026-05-29 05:28:42.446
914	1	5	191	DEMO0914	Fatima Babatunde	08079841604	\N	express	7	4	7	4	\N	completed	paid	14400.00	\N	\N	14400.00	\N	\N	f	\N	19	\N	2026-04-05 05:28:42.449	2026-04-05 05:28:42.449
915	1	5	178	DEMO0915	Tunde Ogundele	08044376215	\N	standard	8	0	8	0	\N	completed	paid	6400.00	\N	\N	6400.00	\N	\N	f	\N	18	\N	2026-03-31 05:28:42.455	2026-03-31 05:28:42.455
916	1	5	190	DEMO0916	Chidi Okafor	08037832910	\N	standard	3	2	3	2	\N	completed	paid	4400.00	\N	\N	4400.00	\N	\N	f	\N	18	\N	2026-03-20 05:28:42.481	2026-03-20 05:28:42.481
917	1	5	178	DEMO0917	Tunde Ogundele	08044376215	\N	express	6	1	6	1	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	17	\N	2026-03-13 05:28:42.613	2026-03-13 05:28:42.613
918	1	5	173	DEMO0918	Musa Lawal	08074336026	\N	express	4	3	4	3	\N	completed	paid	9300.00	\N	\N	9300.00	\N	\N	f	\N	20	\N	2026-03-31 05:28:42.619	2026-03-31 05:28:42.619
919	1	5	183	DEMO0919	Seun Nwosu	08054361022	\N	standard	3	3	3	3	\N	completed	paid	5400.00	\N	\N	5400.00	\N	\N	f	\N	18	\N	2026-03-25 05:28:42.628	2026-03-25 05:28:42.628
920	1	5	200	DEMO0920	Ifeoma Chukwu	08092117040	\N	express	4	2	4	2	\N	completed	paid	7800.00	\N	\N	7800.00	\N	\N	f	\N	18	\N	2026-03-29 05:28:42.666	2026-03-29 05:28:42.666
921	1	5	180	DEMO0921	Nkechi Lawal	08047580009	\N	express	1	4	0	0	\N	pending	paid	7200.00	\N	\N	7200.00	\N	\N	f	\N	17	\N	2026-06-06 05:28:42.671	2026-06-06 05:28:42.671
922	1	5	197	DEMO0922	Zainab Ogundele	08087548400	\N	express	1	5	1	5	\N	completed	paid	8700.00	\N	\N	8700.00	\N	\N	f	\N	17	\N	2026-03-12 05:28:42.676	2026-03-12 05:28:42.676
923	1	5	162	DEMO0923	Adaeze Bello	08026219065	\N	standard	2	4	0	0	\N	ready	partial	5600.00	\N	253.00	1680.00	\N	\N	f	\N	18	\N	2026-04-27 05:28:42.681	2026-04-27 05:28:42.681
924	1	5	199	DEMO0924	Obinna Adeyemi	08065868029	\N	premium	3	5	3	5	\N	completed	paid	14500.00	\N	\N	14500.00	\N	\N	f	\N	19	\N	2026-04-01 05:28:42.694	2026-04-01 05:28:42.694
925	1	5	177	DEMO0925	Nkechi Danjuma	08077427116	\N	express	5	5	0	0	\N	pending	paid	13500.00	\N	\N	13500.00	\N	\N	f	\N	18	\N	2026-05-14 05:28:42.701	2026-05-14 05:28:42.701
926	1	5	175	DEMO0926	Amaka Chukwu	08035042054	\N	premium	2	0	2	0	\N	completed	paid	3000.00	\N	\N	3000.00	\N	\N	f	\N	17	\N	2026-04-06 05:28:42.707	2026-04-06 05:28:42.707
927	1	5	168	DEMO0927	Yusuf Yusuf	08047630361	\N	standard	7	1	0	0	\N	processing	paid	6600.00	\N	\N	6600.00	\N	\N	f	\N	18	\N	2026-04-19 05:28:42.717	2026-04-19 05:28:42.717
928	1	5	192	DEMO0928	Obinna Yusuf	08066331422	\N	premium	7	0	7	0	\N	completed	paid	10500.00	\N	\N	10500.00	\N	\N	f	\N	19	\N	2026-04-01 05:28:42.723	2026-04-01 05:28:42.723
929	1	5	167	DEMO0929	Kunle Danjuma	08089275674	\N	standard	2	1	0	0	\N	ready	partial	2600.00	\N	\N	1742.00	\N	\N	f	\N	17	\N	2026-04-23 05:28:42.729	2026-04-23 05:28:42.729
930	1	5	164	DEMO0930	Nkechi Ogundele	08056305833	\N	standard	4	1	0	0	\N	ready	partial	4200.00	\N	\N	1722.00	\N	\N	f	\N	17	\N	2026-05-05 05:28:42.738	2026-05-05 05:28:42.738
931	1	5	187	DEMO0931	Kunle Chukwu	08081914480	\N	express	8	4	8	4	\N	completed	paid	15600.00	\N	\N	15600.00	\N	\N	f	\N	18	\N	2026-04-19 05:28:42.746	2026-04-19 05:28:42.746
932	1	5	166	DEMO0932	Zainab Babatunde	08049614566	\N	premium	8	5	0	0	\N	ready	unpaid	22000.00	\N	\N	0.00	\N	\N	f	\N	19	\N	2026-04-10 05:28:42.755	2026-04-10 05:28:42.755
933	1	5	196	DEMO0933	Blessing Adeyemi	08041267520	\N	premium	6	5	0	0	\N	processing	unpaid	19000.00	\N	\N	0.00	\N	\N	f	\N	17	\N	2026-06-03 05:28:42.758	2026-06-03 05:28:42.758
934	1	5	196	DEMO0934	Blessing Adeyemi	08041267520	\N	standard	7	2	0	0	\N	processing	unpaid	7600.00	\N	783.00	0.00	\N	\N	f	\N	18	\N	2026-05-18 05:28:42.761	2026-05-18 05:28:42.761
935	1	5	194	DEMO0935	Yusuf Nwachukwu	08050231307	\N	standard	8	2	8	2	\N	completed	partial	8400.00	\N	\N	2772.00	\N	\N	f	\N	17	\N	2026-03-12 05:28:42.773	2026-03-12 05:28:42.773
936	1	5	166	DEMO0936	Zainab Babatunde	08049614566	\N	premium	7	5	0	0	\N	ready	unpaid	20500.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-04-12 05:28:42.781	2026-04-12 05:28:42.781
937	1	5	166	DEMO0937	Zainab Babatunde	08049614566	\N	standard	1	5	0	0	\N	ready	paid	5800.00	\N	\N	5800.00	\N	\N	f	\N	17	\N	2026-05-17 05:28:42.784	2026-05-17 05:28:42.784
938	1	5	172	DEMO0938	Damilola Bello	08043980356	\N	standard	3	2	3	2	\N	completed	paid	4400.00	\N	\N	4400.00	\N	\N	f	\N	19	\N	2026-03-09 05:28:42.792	2026-03-09 05:28:42.792
939	1	5	187	DEMO0939	Kunle Chukwu	08081914480	\N	premium	4	0	0	0	\N	ready	unpaid	6000.00	\N	\N	0.00	\N	\N	f	\N	17	\N	2026-05-27 05:28:42.798	2026-05-27 05:28:42.798
940	1	5	196	DEMO0940	Blessing Adeyemi	08041267520	\N	premium	6	4	0	0	\N	ready	paid	17000.00	\N	\N	17000.00	\N	\N	f	\N	19	\N	2026-05-10 05:28:42.802	2026-05-10 05:28:42.802
941	1	5	176	DEMO0941	Zainab Isa	08052587089	\N	premium	5	2	5	2	\N	completed	paid	11500.00	\N	\N	11500.00	\N	\N	f	\N	20	\N	2026-03-20 05:28:42.807	2026-03-20 05:28:42.807
942	1	5	169	DEMO0942	Yusuf Nwosu	08081055103	\N	standard	1	3	0	0	\N	ready	paid	3800.00	\N	\N	3800.00	\N	\N	f	\N	19	\N	2026-05-21 05:28:42.813	2026-05-21 05:28:42.813
943	1	5	194	DEMO0943	Yusuf Nwachukwu	08050231307	\N	premium	6	1	6	1	\N	completed	paid	11000.00	\N	\N	11000.00	\N	\N	f	\N	18	\N	2026-03-25 05:28:42.818	2026-03-25 05:28:42.818
944	1	5	175	DEMO0944	Amaka Chukwu	08035042054	\N	premium	1	4	0	0	\N	ready	partial	9500.00	\N	\N	4370.00	\N	\N	f	\N	18	\N	2026-04-24 05:28:42.826	2026-04-24 05:28:42.826
945	1	5	161	DEMO0945	Ibrahim Eze	08010576660	\N	standard	7	5	7	5	\N	completed	paid	10600.00	\N	\N	10600.00	\N	\N	f	\N	19	\N	2026-03-15 05:28:42.832	2026-03-15 05:28:42.832
946	1	5	165	DEMO0946	Kunle Obi	08033158761	\N	standard	3	1	0	0	\N	ready	unpaid	3400.00	\N	\N	0.00	\N	\N	f	\N	19	\N	2026-04-11 05:28:42.838	2026-04-11 05:28:42.838
947	1	5	172	DEMO0947	Damilola Bello	08043980356	\N	premium	5	5	0	0	\N	ready	unpaid	17500.00	\N	\N	0.00	\N	\N	f	\N	20	\N	2026-04-10 05:28:42.84	2026-04-10 05:28:42.84
948	1	5	162	DEMO0948	Adaeze Bello	08026219065	\N	standard	8	1	0	0	\N	processing	paid	7400.00	\N	\N	7400.00	\N	\N	f	\N	18	\N	2026-05-01 05:28:42.845	2026-05-01 05:28:42.845
949	1	5	189	DEMO0949	Halima Okafor	08083663184	\N	standard	7	4	7	4	\N	completed	paid	9600.00	\N	\N	9600.00	\N	\N	f	\N	17	\N	2026-03-23 05:28:42.853	2026-03-23 05:28:42.853
950	1	5	184	DEMO0950	Amaka Babatunde	08037261442	\N	standard	7	1	0	0	\N	pending	partial	6600.00	\N	\N	3762.00	\N	\N	f	\N	19	\N	2026-06-05 05:28:42.859	2026-06-05 05:28:42.859
\.


--
-- Data for Name: payment_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_records (id, order_id, laundry_id, branch_id, receipt_number, amount, method, notes, remaining_balance, recorded_by, worker_id, recorded_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name, deletion_reason) FROM stdin;
1	3	1	1	RCT-20260607-0001	4800.00	pos	\N	0.00	Ifeoma Nwachukwu	3	2026-03-24 11:28:35.61	\N	\N	\N	\N	\N
2	4	1	1	RCT-20260607-0002	1530.00	transfer	\N	1470.00	Ifeoma Nwachukwu	3	2026-04-08 13:28:35.618	\N	\N	\N	\N	\N
3	5	1	1	RCT-20260607-0003	7500.00	cash	\N	0.00	Musa Nwosu	2	2026-05-29 06:28:35.624	\N	\N	\N	\N	\N
4	6	1	1	RCT-20260607-0004	12000.00	cash	\N	0.00	Babajide Danjuma	1	2026-03-11 08:28:35.632	\N	\N	\N	\N	\N
5	7	1	1	RCT-20260607-0005	12600.00	transfer	\N	0.00	Musa Nwosu	2	2026-03-18 15:28:35.638	\N	\N	\N	\N	\N
6	8	1	1	RCT-20260607-0006	14500.00	transfer	\N	0.00	Babajide Danjuma	1	2026-03-19 07:28:35.65	\N	\N	\N	\N	\N
7	9	1	1	RCT-20260607-0007	8100.00	cash	\N	0.00	Gbenga Nwosu	4	2026-05-01 17:28:35.657	\N	\N	\N	\N	\N
8	10	1	1	RCT-20260607-0008	6400.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-05-12 06:28:35.663	\N	\N	\N	\N	\N
9	11	1	1	RCT-20260607-0009	7215.00	transfer	\N	3885.00	Musa Nwosu	2	2026-05-25 17:28:35.67	\N	\N	\N	\N	\N
10	12	1	1	RCT-20260607-0010	1776.00	pos	\N	3024.00	Babajide Danjuma	1	2026-04-17 17:28:35.676	\N	\N	\N	\N	\N
11	13	1	1	RCT-20260607-0011	11400.00	pos	\N	0.00	Babajide Danjuma	1	2026-03-16 15:28:35.682	\N	\N	\N	\N	\N
12	14	1	1	RCT-20260607-0012	5040.00	transfer	\N	8960.00	Gbenga Nwosu	4	2026-04-16 14:28:35.698	\N	\N	\N	\N	\N
13	16	1	1	RCT-20260607-0013	3944.00	pos	\N	2856.00	Musa Nwosu	2	2026-05-20 08:28:35.708	\N	\N	\N	\N	\N
14	17	1	1	RCT-20260607-0014	12500.00	cash	\N	0.00	Gbenga Nwosu	4	2026-04-03 11:28:35.719	\N	\N	\N	\N	\N
15	18	1	1	RCT-20260607-0015	14100.00	transfer	\N	0.00	Babajide Danjuma	1	2026-03-31 12:28:35.73	\N	\N	\N	\N	\N
16	19	1	1	RCT-20260607-0016	1024.00	pos	\N	576.00	Ifeoma Nwachukwu	3	2026-05-18 06:28:35.737	\N	\N	\N	\N	\N
17	20	1	1	RCT-20260607-0017	1600.00	transfer	\N	0.00	Babajide Danjuma	1	2026-05-08 10:28:35.744	\N	\N	\N	\N	\N
18	21	1	1	RCT-20260607-0018	7200.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-02 12:28:35.748	\N	\N	\N	\N	\N
19	22	1	1	RCT-20260607-0019	3700.00	cash	\N	6300.00	Ifeoma Nwachukwu	3	2026-06-01 15:28:35.755	\N	\N	\N	\N	\N
20	23	1	1	RCT-20260607-0020	3600.00	pos	\N	0.00	Babajide Danjuma	1	2026-04-15 06:28:35.764	\N	\N	\N	\N	\N
21	24	1	1	RCT-20260607-0021	15500.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-03-15 08:28:35.774	\N	\N	\N	\N	\N
22	25	1	1	RCT-20260607-0022	9600.00	transfer	\N	0.00	Musa Nwosu	2	2026-03-17 13:28:35.786	\N	\N	\N	\N	\N
23	27	1	1	RCT-20260607-0023	12000.00	pos	\N	0.00	Gbenga Nwosu	4	2026-03-13 11:28:35.796	\N	\N	\N	\N	\N
24	28	1	1	RCT-20260607-0024	8400.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-03-26 07:28:35.803	\N	\N	\N	\N	\N
25	29	1	1	RCT-20260607-0025	5040.00	pos	\N	6960.00	Ifeoma Nwachukwu	3	2026-05-20 07:28:35.813	\N	\N	\N	\N	\N
26	30	1	1	RCT-20260607-0026	10260.00	cash	\N	8740.00	Babajide Danjuma	1	2026-05-10 08:28:35.818	\N	\N	\N	\N	\N
27	31	1	1	RCT-20260607-0027	720.00	transfer	\N	780.00	Musa Nwosu	2	2026-06-04 17:28:35.825	\N	\N	\N	\N	\N
28	32	1	1	RCT-20260607-0028	5400.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-28 06:28:35.832	\N	\N	\N	\N	\N
29	34	1	1	RCT-20260607-0029	5512.00	transfer	\N	4888.00	Babajide Danjuma	1	2026-03-22 17:28:35.841	\N	\N	\N	\N	\N
30	36	1	1	RCT-20260607-0030	5800.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-05-31 16:28:35.854	\N	\N	\N	\N	\N
31	37	1	1	RCT-20260607-0031	3040.00	transfer	\N	6460.00	Babajide Danjuma	1	2026-05-08 16:28:35.86	\N	\N	\N	\N	\N
32	38	1	1	RCT-20260607-0032	5600.00	transfer	\N	0.00	Musa Nwosu	2	2026-05-01 15:28:35.867	\N	\N	\N	\N	\N
33	40	1	1	RCT-20260607-0033	4200.00	cash	\N	0.00	Gbenga Nwosu	4	2026-03-25 16:28:35.884	\N	\N	\N	\N	\N
34	41	1	1	RCT-20260607-0034	9500.00	transfer	\N	0.00	Musa Nwosu	2	2026-03-09 13:28:35.891	\N	\N	\N	\N	\N
35	42	1	1	RCT-20260607-0035	16000.00	cash	\N	0.00	Babajide Danjuma	1	2026-03-26 15:28:35.897	\N	\N	\N	\N	\N
36	43	1	1	RCT-20260607-0036	5200.00	pos	\N	0.00	Gbenga Nwosu	4	2026-05-09 15:28:35.907	\N	\N	\N	\N	\N
37	44	1	1	RCT-20260607-0037	11400.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-11 07:28:35.913	\N	\N	\N	\N	\N
38	45	1	1	RCT-20260607-0038	14700.00	transfer	\N	0.00	Babajide Danjuma	1	2026-05-21 17:28:35.918	\N	\N	\N	\N	\N
39	46	1	1	RCT-20260607-0039	4800.00	cash	\N	0.00	Musa Nwosu	2	2026-04-10 16:28:35.931	\N	\N	\N	\N	\N
40	47	1	1	RCT-20260607-0040	7400.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-04-21 10:28:35.937	\N	\N	\N	\N	\N
41	48	1	1	RCT-20260607-0041	2400.00	pos	\N	0.00	Gbenga Nwosu	4	2026-03-20 15:28:35.944	\N	\N	\N	\N	\N
42	49	1	1	RCT-20260607-0042	17000.00	pos	\N	0.00	Musa Nwosu	2	2026-05-23 07:28:35.951	\N	\N	\N	\N	\N
43	50	1	1	RCT-20260607-0043	6300.00	pos	\N	0.00	Musa Nwosu	2	2026-03-14 10:28:35.957	\N	\N	\N	\N	\N
44	51	1	1	RCT-20260607-0044	4500.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-05-17 14:28:35.964	\N	\N	\N	\N	\N
45	52	1	1	RCT-20260607-0045	7200.00	pos	\N	0.00	Musa Nwosu	2	2026-05-16 13:28:35.97	\N	\N	\N	\N	\N
46	53	1	1	RCT-20260607-0046	6900.00	pos	\N	0.00	Ifeoma Nwachukwu	3	2026-03-26 17:28:35.98	\N	\N	\N	\N	\N
47	54	1	1	RCT-20260607-0047	7600.00	cash	\N	0.00	Musa Nwosu	2	2026-03-15 10:28:35.986	\N	\N	\N	\N	\N
48	55	1	1	RCT-20260607-0048	4756.00	pos	\N	3444.00	Musa Nwosu	2	2026-04-21 09:28:35.992	\N	\N	\N	\N	\N
49	56	1	1	RCT-20260607-0049	5200.00	cash	\N	0.00	Gbenga Nwosu	4	2026-03-27 14:28:35.998	\N	\N	\N	\N	\N
50	57	1	1	RCT-20260607-0050	10800.00	cash	\N	0.00	Babajide Danjuma	1	2026-05-13 07:28:36.004	\N	\N	\N	\N	\N
51	58	1	1	RCT-20260607-0051	9000.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-03-12 15:28:36.011	\N	\N	\N	\N	\N
52	59	1	1	RCT-20260607-0052	15900.00	cash	\N	0.00	Gbenga Nwosu	4	2026-03-23 12:28:36.017	\N	\N	\N	\N	\N
53	60	1	1	RCT-20260607-0053	11100.00	cash	\N	0.00	Musa Nwosu	2	2026-03-23 12:28:36.025	\N	\N	\N	\N	\N
54	62	1	1	RCT-20260607-0054	5100.00	pos	\N	0.00	Gbenga Nwosu	4	2026-04-17 10:28:36.041	\N	\N	\N	\N	\N
55	64	1	1	RCT-20260607-0055	9600.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-05-24 14:28:36.056	\N	\N	\N	\N	\N
56	65	1	1	RCT-20260607-0056	13200.00	pos	\N	0.00	Gbenga Nwosu	4	2026-04-19 07:28:36.063	\N	\N	\N	\N	\N
57	67	1	1	RCT-20260607-0057	10540.00	transfer	\N	4960.00	Gbenga Nwosu	4	2026-04-02 15:28:36.074	\N	\N	\N	\N	\N
58	69	1	1	RCT-20260607-0058	7525.00	cash	\N	9975.00	Ifeoma Nwachukwu	3	2026-05-31 07:28:36.095	\N	\N	\N	\N	\N
59	70	1	1	RCT-20260607-0059	5980.00	pos	\N	5520.00	Musa Nwosu	2	2026-05-20 10:28:36.105	\N	\N	\N	\N	\N
60	74	1	1	RCT-20260607-0060	5500.00	cash	\N	0.00	Gbenga Nwosu	4	2026-05-25 14:28:36.127	\N	\N	\N	\N	\N
61	75	1	1	RCT-20260607-0061	6400.00	pos	\N	0.00	Ifeoma Nwachukwu	3	2026-04-05 08:28:36.134	\N	\N	\N	\N	\N
62	76	1	1	RCT-20260607-0062	14500.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-04-18 12:28:36.141	\N	\N	\N	\N	\N
63	79	1	1	RCT-20260607-0063	14500.00	transfer	\N	0.00	Musa Nwosu	2	2026-04-12 11:28:36.157	\N	\N	\N	\N	\N
64	80	1	1	RCT-20260607-0064	5200.00	cash	\N	0.00	Gbenga Nwosu	4	2026-04-03 11:28:36.165	\N	\N	\N	\N	\N
65	81	1	1	RCT-20260607-0065	12900.00	transfer	\N	0.00	Babajide Danjuma	1	2026-04-02 14:28:36.17	\N	\N	\N	\N	\N
66	82	1	1	RCT-20260607-0066	9000.00	cash	\N	0.00	Gbenga Nwosu	4	2026-03-15 10:28:36.176	\N	\N	\N	\N	\N
67	83	1	1	RCT-20260607-0067	15900.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-03-23 17:28:36.188	\N	\N	\N	\N	\N
68	84	1	1	RCT-20260607-0068	4375.00	pos	\N	8125.00	Babajide Danjuma	1	2026-05-17 17:28:36.194	\N	\N	\N	\N	\N
69	85	1	1	RCT-20260607-0069	12000.00	cash	\N	0.00	Musa Nwosu	2	2026-03-31 06:28:36.201	\N	\N	\N	\N	\N
70	86	1	1	RCT-20260607-0070	7400.00	pos	\N	0.00	Babajide Danjuma	1	2026-06-05 17:28:36.209	\N	\N	\N	\N	\N
71	87	1	1	RCT-20260607-0071	3600.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-03-25 08:28:36.218	\N	\N	\N	\N	\N
72	88	1	1	RCT-20260607-0072	6000.00	cash	\N	6500.00	Musa Nwosu	2	2026-03-22 15:28:36.225	\N	\N	\N	\N	\N
73	89	1	1	RCT-20260607-0073	13000.00	pos	\N	0.00	Babajide Danjuma	1	2026-03-27 07:28:36.233	\N	\N	\N	\N	\N
74	91	1	1	RCT-20260607-0074	5600.00	pos	\N	0.00	Ifeoma Nwachukwu	3	2026-03-09 06:28:36.248	\N	\N	\N	\N	\N
75	92	1	1	RCT-20260607-0075	5808.00	cash	\N	7392.00	Gbenga Nwosu	4	2026-05-17 15:28:36.254	\N	\N	\N	\N	\N
76	93	1	1	RCT-20260607-0076	12000.00	pos	\N	0.00	Gbenga Nwosu	4	2026-03-13 12:28:36.262	\N	\N	\N	\N	\N
77	96	1	1	RCT-20260607-0077	4200.00	cash	\N	0.00	Babajide Danjuma	1	2026-05-19 17:28:36.281	\N	\N	\N	\N	\N
78	97	1	1	RCT-20260607-0078	20500.00	cash	\N	0.00	Musa Nwosu	2	2026-03-09 13:28:36.288	\N	\N	\N	\N	\N
79	98	1	1	RCT-20260607-0079	11400.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-04-28 16:28:36.295	\N	\N	\N	\N	\N
80	99	1	1	RCT-20260607-0080	16000.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-03-16 14:28:36.303	\N	\N	\N	\N	\N
81	100	1	1	RCT-20260607-0081	1560.00	pos	\N	3640.00	Gbenga Nwosu	4	2026-04-26 07:28:36.311	\N	\N	\N	\N	\N
82	102	1	1	RCT-20260607-0082	9400.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-16 06:28:36.327	\N	\N	\N	\N	\N
83	105	1	1	RCT-20260607-0083	4160.00	pos	\N	2240.00	Ifeoma Nwachukwu	3	2026-05-01 14:28:36.358	\N	\N	\N	\N	\N
84	107	1	1	RCT-20260607-0084	4290.00	transfer	\N	8710.00	Gbenga Nwosu	4	2026-05-26 14:28:36.376	\N	\N	\N	\N	\N
85	108	1	1	RCT-20260607-0085	3024.00	cash	\N	4176.00	Babajide Danjuma	1	2026-05-09 17:28:36.383	\N	\N	\N	\N	\N
86	109	1	1	RCT-20260607-0086	8600.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-15 13:28:36.391	\N	\N	\N	\N	\N
87	110	1	1	RCT-20260607-0087	9500.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-03-09 06:28:36.399	\N	\N	\N	\N	\N
88	111	1	1	RCT-20260607-0088	11000.00	transfer	\N	0.00	Musa Nwosu	2	2026-03-18 07:28:36.408	\N	\N	\N	\N	\N
89	112	1	1	RCT-20260607-0089	2156.00	cash	\N	2244.00	Gbenga Nwosu	4	2026-05-31 12:28:36.42	\N	\N	\N	\N	\N
90	113	1	1	RCT-20260607-0090	2400.00	cash	\N	0.00	Musa Nwosu	2	2026-03-16 16:28:36.426	\N	\N	\N	\N	\N
91	114	1	1	RCT-20260607-0091	1254.00	cash	\N	2546.00	Ifeoma Nwachukwu	3	2026-05-27 17:28:36.433	\N	\N	\N	\N	\N
92	116	1	1	RCT-20260607-0092	22000.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-22 07:28:36.442	\N	\N	\N	\N	\N
93	117	1	1	RCT-20260607-0093	20000.00	pos	\N	0.00	Gbenga Nwosu	4	2026-03-11 16:28:36.449	\N	\N	\N	\N	\N
94	118	1	1	RCT-20260607-0094	9300.00	pos	\N	0.00	Babajide Danjuma	1	2026-05-18 09:28:36.456	\N	\N	\N	\N	\N
95	119	1	1	RCT-20260607-0095	1680.00	cash	\N	1320.00	Gbenga Nwosu	4	2026-05-25 16:28:36.462	\N	\N	\N	\N	\N
96	121	1	1	RCT-20260607-0096	6400.00	cash	\N	0.00	Musa Nwosu	2	2026-03-26 15:28:36.475	\N	\N	\N	\N	\N
97	123	1	1	RCT-20260607-0097	9800.00	pos	\N	0.00	Musa Nwosu	2	2026-03-11 08:28:36.484	\N	\N	\N	\N	\N
98	124	1	1	RCT-20260607-0098	6975.00	pos	\N	8525.00	Musa Nwosu	2	2026-05-15 15:28:36.49	\N	\N	\N	\N	\N
99	126	1	1	RCT-20260607-0099	12500.00	pos	\N	0.00	Musa Nwosu	2	2026-03-30 14:28:36.505	\N	\N	\N	\N	\N
100	127	1	1	RCT-20260607-0100	8700.00	pos	\N	0.00	Musa Nwosu	2	2026-03-17 11:28:36.523	\N	\N	\N	\N	\N
101	129	1	1	RCT-20260607-0101	8190.00	cash	\N	4810.00	Gbenga Nwosu	4	2026-04-22 10:28:36.533	\N	\N	\N	\N	\N
102	130	1	1	RCT-20260607-0102	5900.00	transfer	\N	4100.00	Babajide Danjuma	1	2026-04-30 15:28:36.541	\N	\N	\N	\N	\N
103	132	1	1	RCT-20260607-0103	9800.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-06-01 12:28:36.559	\N	\N	\N	\N	\N
104	133	1	1	RCT-20260607-0104	5700.00	transfer	\N	0.00	Babajide Danjuma	1	2026-03-12 11:28:36.567	\N	\N	\N	\N	\N
105	134	1	1	RCT-20260607-0105	7500.00	pos	\N	5000.00	Babajide Danjuma	1	2026-05-16 10:28:36.574	\N	\N	\N	\N	\N
106	135	1	1	RCT-20260607-0106	4505.00	transfer	\N	3995.00	Babajide Danjuma	1	2026-04-12 16:28:36.582	\N	\N	\N	\N	\N
107	136	1	1	RCT-20260607-0107	8700.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-29 11:28:36.59	\N	\N	\N	\N	\N
108	137	1	1	RCT-20260607-0108	9500.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-05-03 13:28:36.6	\N	\N	\N	\N	\N
109	139	1	1	RCT-20260607-0109	9000.00	pos	\N	0.00	Babajide Danjuma	1	2026-03-21 08:28:36.616	\N	\N	\N	\N	\N
110	142	1	1	RCT-20260607-0110	800.00	pos	\N	0.00	Babajide Danjuma	1	2026-04-07 17:28:36.63	\N	\N	\N	\N	\N
111	144	1	1	RCT-20260607-0111	6600.00	cash	\N	0.00	Babajide Danjuma	1	2026-03-11 12:28:36.639	\N	\N	\N	\N	\N
112	145	1	1	RCT-20260607-0112	6200.00	transfer	\N	0.00	Babajide Danjuma	1	2026-03-24 13:28:36.645	\N	\N	\N	\N	\N
113	146	1	1	RCT-20260607-0113	3000.00	transfer	\N	0.00	Musa Nwosu	2	2026-04-22 07:28:36.657	\N	\N	\N	\N	\N
114	147	1	1	RCT-20260607-0114	7600.00	cash	\N	0.00	Gbenga Nwosu	4	2026-04-01 15:28:36.664	\N	\N	\N	\N	\N
115	148	1	1	RCT-20260607-0115	12900.00	transfer	\N	0.00	Babajide Danjuma	1	2026-03-25 07:28:36.671	\N	\N	\N	\N	\N
116	149	1	1	RCT-20260607-0116	2646.00	pos	\N	2754.00	Gbenga Nwosu	4	2026-04-22 11:28:36.678	\N	\N	\N	\N	\N
117	150	1	1	RCT-20260607-0117	7000.00	cash	\N	0.00	Musa Nwosu	2	2026-04-04 09:28:36.685	\N	\N	\N	\N	\N
118	151	1	1	RCT-20260607-0118	4860.00	pos	\N	4140.00	Babajide Danjuma	1	2026-05-04 14:28:36.696	\N	\N	\N	\N	\N
119	153	1	1	RCT-20260607-0119	7150.00	cash	\N	3850.00	Babajide Danjuma	1	2026-05-16 14:28:36.712	\N	\N	\N	\N	\N
120	154	1	1	RCT-20260607-0120	7000.00	pos	\N	0.00	Gbenga Nwosu	4	2026-04-29 16:28:36.719	\N	\N	\N	\N	\N
121	155	1	1	RCT-20260607-0121	7000.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-10 07:28:36.727	\N	\N	\N	\N	\N
122	156	1	1	RCT-20260607-0122	7600.00	pos	\N	0.00	Musa Nwosu	2	2026-05-04 10:28:36.734	\N	\N	\N	\N	\N
123	158	1	1	RCT-20260607-0123	8575.00	transfer	\N	8925.00	Babajide Danjuma	1	2026-03-09 16:28:36.751	\N	\N	\N	\N	\N
124	159	1	1	RCT-20260607-0124	5600.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-03-23 06:28:36.757	\N	\N	\N	\N	\N
125	160	1	1	RCT-20260607-0125	9500.00	cash	\N	0.00	Musa Nwosu	2	2026-06-05 16:28:36.765	\N	\N	\N	\N	\N
126	161	1	1	RCT-20260607-0126	2220.00	pos	\N	5180.00	Musa Nwosu	2	2026-05-13 16:28:36.771	\N	\N	\N	\N	\N
127	164	1	1	RCT-20260607-0127	10800.00	cash	\N	0.00	Gbenga Nwosu	4	2026-05-12 17:28:36.786	\N	\N	\N	\N	\N
128	167	1	1	RCT-20260607-0128	7800.00	cash	\N	0.00	Gbenga Nwosu	4	2026-03-25 09:28:36.799	\N	\N	\N	\N	\N
129	168	1	1	RCT-20260607-0129	12500.00	transfer	\N	0.00	Gbenga Nwosu	4	2026-03-22 06:28:36.806	\N	\N	\N	\N	\N
130	169	1	1	RCT-20260607-0130	855.00	transfer	\N	645.00	Musa Nwosu	2	2026-05-26 06:28:36.813	\N	\N	\N	\N	\N
131	170	1	1	RCT-20260607-0131	6600.00	pos	\N	0.00	Musa Nwosu	2	2026-04-05 08:28:36.82	\N	\N	\N	\N	\N
132	171	1	1	RCT-20260607-0132	16000.00	cash	\N	0.00	Ifeoma Nwachukwu	3	2026-04-18 17:28:36.827	\N	\N	\N	\N	\N
133	172	1	1	RCT-20260607-0133	4860.00	transfer	\N	8640.00	Gbenga Nwosu	4	2026-05-03 06:28:36.833	\N	\N	\N	\N	\N
134	173	1	1	RCT-20260607-0134	8000.00	cash	\N	0.00	Babajide Danjuma	1	2026-04-12 15:28:36.84	\N	\N	\N	\N	\N
135	174	1	1	RCT-20260607-0135	4998.00	transfer	\N	4802.00	Ifeoma Nwachukwu	3	2026-05-16 10:28:36.846	\N	\N	\N	\N	\N
136	175	1	1	RCT-20260607-0136	6800.00	pos	\N	0.00	Gbenga Nwosu	4	2026-03-11 09:28:36.853	\N	\N	\N	\N	\N
137	176	1	1	RCT-20260607-0137	5000.00	cash	\N	0.00	Babajide Danjuma	1	2026-04-11 10:28:36.859	\N	\N	\N	\N	\N
138	177	1	1	RCT-20260607-0138	840.00	cash	\N	1560.00	Musa Nwosu	2	2026-04-20 06:28:36.866	\N	\N	\N	\N	\N
139	178	1	1	RCT-20260607-0139	9000.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-04-08 16:28:36.873	\N	\N	\N	\N	\N
140	179	1	1	RCT-20260607-0140	4418.00	cash	\N	4982.00	Babajide Danjuma	1	2026-06-03 12:28:36.881	\N	\N	\N	\N	\N
141	180	1	1	RCT-20260607-0141	9500.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-05-26 15:28:36.887	\N	\N	\N	\N	\N
142	181	1	1	RCT-20260607-0142	6000.00	pos	\N	0.00	Gbenga Nwosu	4	2026-03-27 13:28:36.896	\N	\N	\N	\N	\N
143	182	1	1	RCT-20260607-0143	4836.00	cash	\N	4464.00	Musa Nwosu	2	2026-04-10 12:28:36.902	\N	\N	\N	\N	\N
144	183	1	1	RCT-20260607-0144	12600.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-04-18 08:28:36.918	\N	\N	\N	\N	\N
145	184	1	1	RCT-20260607-0145	10017.00	transfer	\N	5883.00	Babajide Danjuma	1	2026-05-15 07:28:36.924	\N	\N	\N	\N	\N
146	185	1	1	RCT-20260607-0146	6000.00	transfer	\N	0.00	Musa Nwosu	2	2026-03-13 17:28:36.933	\N	\N	\N	\N	\N
147	186	1	1	RCT-20260607-0147	8600.00	pos	\N	0.00	Musa Nwosu	2	2026-03-11 07:28:36.939	\N	\N	\N	\N	\N
148	187	1	1	RCT-20260607-0148	4092.00	transfer	\N	2508.00	Babajide Danjuma	1	2026-04-03 13:28:36.946	\N	\N	\N	\N	\N
149	188	1	1	RCT-20260607-0149	11400.00	pos	\N	0.00	Musa Nwosu	2	2026-05-13 17:28:36.952	\N	\N	\N	\N	\N
150	189	1	1	RCT-20260607-0150	8600.00	transfer	\N	0.00	Ifeoma Nwachukwu	3	2026-05-09 17:28:36.96	\N	\N	\N	\N	\N
151	190	1	1	RCT-20260607-0151	5400.00	pos	\N	0.00	Ifeoma Nwachukwu	3	2026-03-20 14:28:36.971	\N	\N	\N	\N	\N
152	191	1	1	RCT-20260607-0152	1200.00	pos	\N	0.00	Musa Nwosu	2	2026-05-30 11:28:36.977	\N	\N	\N	\N	\N
153	192	1	1	RCT-20260607-0153	1782.00	transfer	\N	918.00	Babajide Danjuma	1	2026-05-24 13:28:36.986	\N	\N	\N	\N	\N
154	193	1	1	RCT-20260607-0154	6800.00	transfer	\N	0.00	Babajide Danjuma	1	2026-04-02 12:28:36.992	\N	\N	\N	\N	\N
155	194	1	1	RCT-20260607-0155	4092.00	cash	\N	9108.00	Babajide Danjuma	1	2026-05-29 12:28:36.998	\N	\N	\N	\N	\N
156	195	1	1	RCT-20260607-0156	7500.00	cash	\N	0.00	Musa Nwosu	2	2026-03-16 15:28:37.013	\N	\N	\N	\N	\N
157	196	1	1	RCT-20260607-0157	4560.00	cash	\N	6840.00	Ifeoma Nwachukwu	3	2026-04-29 14:28:37.022	\N	\N	\N	\N	\N
158	198	1	1	RCT-20260607-0158	9000.00	cash	\N	0.00	Babajide Danjuma	1	2026-04-10 06:28:37.032	\N	\N	\N	\N	\N
159	199	1	1	RCT-20260607-0159	6300.00	cash	\N	0.00	Musa Nwosu	2	2026-03-30 16:28:37.038	\N	\N	\N	\N	\N
160	200	1	1	RCT-20260607-0160	5600.00	cash	\N	0.00	Musa Nwosu	2	2026-03-27 17:28:37.045	\N	\N	\N	\N	\N
161	201	1	2	RCT-20260607-0161	12300.00	transfer	\N	0.00	Ifeoma Musa	8	2026-03-22 09:28:37.121	\N	\N	\N	\N	\N
162	202	1	2	RCT-20260607-0162	9300.00	transfer	\N	0.00	Amaka Eze	6	2026-03-12 11:28:37.127	\N	\N	\N	\N	\N
163	203	1	2	RCT-20260607-0163	6000.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-04-04 11:28:37.132	\N	\N	\N	\N	\N
164	204	1	2	RCT-20260607-0164	7000.00	transfer	\N	10500.00	Amaka Eze	6	2026-05-28 15:28:37.139	\N	\N	\N	\N	\N
165	205	1	2	RCT-20260607-0165	14000.00	transfer	\N	0.00	Amaka Eze	6	2026-03-23 07:28:37.145	\N	\N	\N	\N	\N
166	206	1	2	RCT-20260607-0166	2688.00	cash	\N	2112.00	Amaka Eze	6	2026-04-11 13:28:37.152	\N	\N	\N	\N	\N
167	207	1	2	RCT-20260607-0167	3600.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-05-30 11:28:37.158	\N	\N	\N	\N	\N
168	208	1	2	RCT-20260607-0168	16500.00	transfer	\N	0.00	Ibrahim Bello	5	2026-04-01 15:28:37.169	\N	\N	\N	\N	\N
169	210	1	2	RCT-20260607-0169	1900.00	pos	\N	3100.00	Amaka Eze	6	2026-05-09 14:28:37.182	\N	\N	\N	\N	\N
170	211	1	2	RCT-20260607-0170	17100.00	transfer	\N	0.00	Ifeoma Musa	8	2026-04-03 07:28:37.188	\N	\N	\N	\N	\N
171	212	1	2	RCT-20260607-0171	15500.00	transfer	\N	0.00	Amaka Eze	6	2026-05-05 13:28:37.203	\N	\N	\N	\N	\N
172	213	1	2	RCT-20260607-0172	8800.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-03-30 12:28:37.213	\N	\N	\N	\N	\N
173	214	1	2	RCT-20260607-0173	7200.00	transfer	\N	0.00	Ibrahim Bello	5	2026-04-02 09:28:37.22	\N	\N	\N	\N	\N
174	215	1	2	RCT-20260607-0174	5400.00	transfer	\N	0.00	Amaka Eze	6	2026-03-14 12:28:37.235	\N	\N	\N	\N	\N
175	216	1	2	RCT-20260607-0175	13500.00	cash	\N	0.00	Amaka Eze	6	2026-04-10 09:28:37.242	\N	\N	\N	\N	\N
176	217	1	2	RCT-20260607-0176	10500.00	cash	\N	0.00	Ifeoma Musa	8	2026-05-17 13:28:37.248	\N	\N	\N	\N	\N
177	218	1	2	RCT-20260607-0177	14400.00	pos	\N	0.00	Ifeoma Musa	8	2026-04-02 13:28:37.254	\N	\N	\N	\N	\N
178	219	1	2	RCT-20260607-0178	10400.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-17 10:28:37.267	\N	\N	\N	\N	\N
179	220	1	2	RCT-20260607-0179	8400.00	transfer	\N	0.00	Ibrahim Bello	5	2026-05-25 10:28:37.274	\N	\N	\N	\N	\N
180	221	1	2	RCT-20260607-0180	3600.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-03-27 14:28:37.281	\N	\N	\N	\N	\N
181	222	1	2	RCT-20260607-0181	10800.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-05-27 11:28:37.288	\N	\N	\N	\N	\N
182	224	1	2	RCT-20260607-0182	1500.00	cash	\N	0.00	Ibrahim Bello	5	2026-03-23 12:28:37.301	\N	\N	\N	\N	\N
183	225	1	2	RCT-20260607-0183	7040.00	transfer	\N	14960.00	Amaka Eze	6	2026-05-18 09:28:37.306	\N	\N	\N	\N	\N
184	226	1	2	RCT-20260607-0184	12500.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-03-29 13:28:37.312	\N	\N	\N	\N	\N
185	228	1	2	RCT-20260607-0185	7200.00	pos	\N	0.00	Ibrahim Bello	5	2026-06-01 14:28:37.331	\N	\N	\N	\N	\N
186	229	1	2	RCT-20260607-0186	3600.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-10 10:28:37.341	\N	\N	\N	\N	\N
187	230	1	2	RCT-20260607-0187	11700.00	transfer	\N	0.00	Amaka Eze	6	2026-05-03 09:28:37.348	\N	\N	\N	\N	\N
188	231	1	2	RCT-20260607-0188	4000.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-05-25 08:28:37.357	\N	\N	\N	\N	\N
189	232	1	2	RCT-20260607-0189	4200.00	cash	\N	0.00	Ibrahim Bello	5	2026-05-15 15:28:37.364	\N	\N	\N	\N	\N
190	233	1	2	RCT-20260607-0190	5952.00	pos	\N	3648.00	Ibrahim Nwosu	7	2026-04-04 10:28:37.369	\N	\N	\N	\N	\N
191	234	1	2	RCT-20260607-0191	3102.00	cash	\N	3498.00	Ifeoma Musa	8	2026-03-20 13:28:37.375	\N	\N	\N	\N	\N
192	235	1	2	RCT-20260607-0192	6000.00	transfer	\N	0.00	Amaka Eze	6	2026-04-28 06:28:37.382	\N	\N	\N	\N	\N
193	236	1	2	RCT-20260607-0193	8400.00	transfer	\N	0.00	Amaka Eze	6	2026-03-15 17:28:37.394	\N	\N	\N	\N	\N
194	237	1	2	RCT-20260607-0194	10500.00	cash	\N	0.00	Ibrahim Bello	5	2026-04-19 15:28:37.408	\N	\N	\N	\N	\N
195	238	1	2	RCT-20260607-0195	17000.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-04-23 11:28:37.415	\N	\N	\N	\N	\N
196	239	1	2	RCT-20260607-0196	20500.00	cash	\N	0.00	Amaka Eze	6	2026-05-26 13:28:37.422	\N	\N	\N	\N	\N
197	240	1	2	RCT-20260607-0197	5800.00	pos	\N	0.00	Ibrahim Bello	5	2026-05-09 16:28:37.428	\N	\N	\N	\N	\N
198	242	1	2	RCT-20260607-0198	13500.00	pos	\N	0.00	Ifeoma Musa	8	2026-06-04 16:28:37.438	\N	\N	\N	\N	\N
199	244	1	2	RCT-20260607-0199	928.00	pos	\N	672.00	Amaka Eze	6	2026-04-04 13:28:37.447	\N	\N	\N	\N	\N
200	245	1	2	RCT-20260607-0200	4845.00	pos	\N	4655.00	Ibrahim Bello	5	2026-04-22 14:28:37.459	\N	\N	\N	\N	\N
201	246	1	2	RCT-20260607-0201	15500.00	transfer	\N	0.00	Ifeoma Musa	8	2026-04-05 07:28:37.465	\N	\N	\N	\N	\N
202	247	1	2	RCT-20260607-0202	7208.00	transfer	\N	3392.00	Amaka Eze	6	2026-03-31 08:28:37.471	\N	\N	\N	\N	\N
203	249	1	2	RCT-20260607-0203	10500.00	pos	\N	0.00	Amaka Eze	6	2026-05-05 14:28:37.489	\N	\N	\N	\N	\N
204	250	1	2	RCT-20260607-0204	1800.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-04-24 08:28:37.504	\N	\N	\N	\N	\N
205	251	1	2	RCT-20260607-0205	5700.00	transfer	\N	0.00	Ibrahim Bello	5	2026-03-09 17:28:37.51	\N	\N	\N	\N	\N
206	252	1	2	RCT-20260607-0206	6400.00	pos	\N	0.00	Amaka Eze	6	2026-05-16 06:28:37.525	\N	\N	\N	\N	\N
207	253	1	2	RCT-20260607-0207	15500.00	transfer	\N	0.00	Amaka Eze	6	2026-05-05 17:28:37.538	\N	\N	\N	\N	\N
208	254	1	2	RCT-20260607-0208	13000.00	pos	\N	0.00	Amaka Eze	6	2026-04-12 16:28:37.544	\N	\N	\N	\N	\N
209	255	1	2	RCT-20260607-0209	7524.00	pos	\N	9576.00	Ifeoma Musa	8	2026-04-29 16:28:37.559	\N	\N	\N	\N	\N
210	256	1	2	RCT-20260607-0210	3500.00	cash	\N	0.00	Amaka Eze	6	2026-04-29 14:28:37.565	\N	\N	\N	\N	\N
211	257	1	2	RCT-20260607-0211	6600.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-19 14:28:37.571	\N	\N	\N	\N	\N
212	258	1	2	RCT-20260607-0212	3200.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-10 08:28:37.576	\N	\N	\N	\N	\N
213	259	1	2	RCT-20260607-0213	15180.00	cash	\N	6820.00	Amaka Eze	6	2026-03-24 17:28:37.586	\N	\N	\N	\N	\N
214	260	1	2	RCT-20260607-0214	9400.00	pos	\N	0.00	Ifeoma Musa	8	2026-03-28 10:28:37.591	\N	\N	\N	\N	\N
215	261	1	2	RCT-20260607-0215	5500.00	cash	\N	0.00	Ifeoma Musa	8	2026-03-18 08:28:37.601	\N	\N	\N	\N	\N
216	262	1	2	RCT-20260607-0216	2442.00	cash	\N	4958.00	Amaka Eze	6	2026-05-06 14:28:37.606	\N	\N	\N	\N	\N
217	264	1	2	RCT-20260607-0217	6400.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-05-13 11:28:37.621	\N	\N	\N	\N	\N
218	265	1	2	RCT-20260607-0218	8280.00	transfer	\N	3720.00	Ibrahim Nwosu	7	2026-05-01 11:28:37.627	\N	\N	\N	\N	\N
219	268	1	2	RCT-20260607-0219	12500.00	pos	\N	0.00	Ifeoma Musa	8	2026-05-31 07:28:37.64	\N	\N	\N	\N	\N
220	269	1	2	RCT-20260607-0220	13200.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-03-12 16:28:37.647	\N	\N	\N	\N	\N
221	270	1	2	RCT-20260607-0221	2178.00	cash	\N	4422.00	Ibrahim Bello	5	2026-05-07 09:28:37.654	\N	\N	\N	\N	\N
222	271	1	2	RCT-20260607-0222	18000.00	transfer	\N	0.00	Amaka Eze	6	2026-04-04 07:28:37.659	\N	\N	\N	\N	\N
223	273	1	2	RCT-20260607-0223	9600.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-05-02 12:28:37.677	\N	\N	\N	\N	\N
224	274	1	2	RCT-20260607-0224	1920.00	cash	\N	4480.00	Ibrahim Bello	5	2026-06-03 13:28:37.683	\N	\N	\N	\N	\N
225	275	1	2	RCT-20260607-0225	3306.00	cash	\N	5394.00	Ibrahim Nwosu	7	2026-04-21 11:28:37.693	\N	\N	\N	\N	\N
226	276	1	2	RCT-20260607-0226	5494.00	cash	\N	2706.00	Ibrahim Nwosu	7	2026-05-15 08:28:37.7	\N	\N	\N	\N	\N
227	277	1	2	RCT-20260607-0227	2478.00	cash	\N	1722.00	Ibrahim Nwosu	7	2026-03-14 08:28:37.71	\N	\N	\N	\N	\N
228	278	1	2	RCT-20260607-0228	4950.00	cash	\N	4050.00	Ibrahim Nwosu	7	2026-04-24 06:28:37.717	\N	\N	\N	\N	\N
229	279	1	2	RCT-20260607-0229	2700.00	pos	\N	0.00	Ifeoma Musa	8	2026-06-06 07:28:37.727	\N	\N	\N	\N	\N
230	281	1	2	RCT-20260607-0230	11100.00	transfer	\N	0.00	Amaka Eze	6	2026-04-05 11:28:37.736	\N	\N	\N	\N	\N
231	283	1	2	RCT-20260607-0231	9000.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-05-15 12:28:37.748	\N	\N	\N	\N	\N
232	284	1	2	RCT-20260607-0232	5304.00	pos	\N	2496.00	Amaka Eze	6	2026-05-09 11:28:37.754	\N	\N	\N	\N	\N
233	285	1	2	RCT-20260607-0233	3660.00	cash	\N	2340.00	Amaka Eze	6	2026-05-16 06:28:37.76	\N	\N	\N	\N	\N
234	286	1	2	RCT-20260607-0234	11000.00	cash	\N	0.00	Ibrahim Bello	5	2026-05-02 17:28:37.768	\N	\N	\N	\N	\N
235	287	1	2	RCT-20260607-0235	7700.00	transfer	\N	3300.00	Amaka Eze	6	2026-05-14 08:28:37.774	\N	\N	\N	\N	\N
236	288	1	2	RCT-20260607-0236	6000.00	transfer	\N	0.00	Ibrahim Bello	5	2026-03-16 09:28:37.78	\N	\N	\N	\N	\N
237	289	1	2	RCT-20260607-0237	8500.00	cash	\N	0.00	Amaka Eze	6	2026-03-22 15:28:37.788	\N	\N	\N	\N	\N
238	290	1	2	RCT-20260607-0238	2652.00	transfer	\N	2448.00	Amaka Eze	6	2026-06-01 09:28:37.794	\N	\N	\N	\N	\N
239	291	1	2	RCT-20260607-0239	9010.00	transfer	\N	7990.00	Ibrahim Bello	5	2026-06-04 16:28:37.8	\N	\N	\N	\N	\N
240	292	1	2	RCT-20260607-0240	11500.00	transfer	\N	0.00	Amaka Eze	6	2026-04-20 15:28:37.806	\N	\N	\N	\N	\N
241	293	1	2	RCT-20260607-0241	14400.00	transfer	\N	0.00	Amaka Eze	6	2026-04-26 17:28:37.812	\N	\N	\N	\N	\N
242	294	1	2	RCT-20260607-0242	9425.00	cash	\N	5075.00	Ibrahim Bello	5	2026-05-16 12:28:37.818	\N	\N	\N	\N	\N
243	295	1	2	RCT-20260607-0243	18000.00	pos	\N	0.00	Ibrahim Bello	5	2026-04-07 10:28:37.824	\N	\N	\N	\N	\N
244	296	1	2	RCT-20260607-0244	6400.00	transfer	\N	0.00	Ibrahim Bello	5	2026-04-10 12:28:37.831	\N	\N	\N	\N	\N
245	297	1	2	RCT-20260607-0245	962.00	pos	\N	1638.00	Ibrahim Nwosu	7	2026-04-24 16:28:37.846	\N	\N	\N	\N	\N
246	298	1	2	RCT-20260607-0246	14000.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-03-31 11:28:37.852	\N	\N	\N	\N	\N
247	300	1	2	RCT-20260607-0247	16000.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-03-26 16:28:37.867	\N	\N	\N	\N	\N
248	301	1	2	RCT-20260607-0248	14400.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-19 09:28:37.881	\N	\N	\N	\N	\N
249	302	1	2	RCT-20260607-0249	7500.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-04-24 12:28:37.887	\N	\N	\N	\N	\N
250	303	1	2	RCT-20260607-0250	12300.00	transfer	\N	0.00	Ifeoma Musa	8	2026-03-29 15:28:37.894	\N	\N	\N	\N	\N
251	304	1	2	RCT-20260607-0251	7200.00	cash	\N	0.00	Amaka Eze	6	2026-04-05 14:28:37.9	\N	\N	\N	\N	\N
252	305	1	2	RCT-20260607-0252	6440.00	cash	\N	5060.00	Ifeoma Musa	8	2026-05-19 15:28:37.907	\N	\N	\N	\N	\N
253	306	1	2	RCT-20260607-0253	7200.00	cash	\N	0.00	Ifeoma Musa	8	2026-04-21 06:28:37.915	\N	\N	\N	\N	\N
254	307	1	2	RCT-20260607-0254	3264.00	pos	\N	6336.00	Amaka Eze	6	2026-06-02 06:28:37.922	\N	\N	\N	\N	\N
255	308	1	2	RCT-20260607-0255	7600.00	transfer	\N	0.00	Amaka Eze	6	2026-05-26 16:28:37.928	\N	\N	\N	\N	\N
256	309	1	2	RCT-20260607-0256	6200.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-19 08:28:37.941	\N	\N	\N	\N	\N
257	310	1	2	RCT-20260607-0257	6400.00	pos	\N	0.00	Amaka Eze	6	2026-03-17 10:28:37.947	\N	\N	\N	\N	\N
258	311	1	2	RCT-20260607-0258	5280.00	pos	\N	7920.00	Ibrahim Nwosu	7	2026-05-28 10:28:37.953	\N	\N	\N	\N	\N
259	312	1	2	RCT-20260607-0259	13500.00	transfer	\N	0.00	Ifeoma Musa	8	2026-03-14 13:28:37.959	\N	\N	\N	\N	\N
260	313	1	2	RCT-20260607-0260	3600.00	cash	\N	0.00	Ifeoma Musa	8	2026-04-28 15:28:37.966	\N	\N	\N	\N	\N
261	314	1	2	RCT-20260607-0261	11100.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-05-03 16:28:37.973	\N	\N	\N	\N	\N
262	316	1	2	RCT-20260607-0262	7400.00	pos	\N	0.00	Amaka Eze	6	2026-03-17 11:28:37.983	\N	\N	\N	\N	\N
263	318	1	2	RCT-20260607-0263	4480.00	cash	\N	2520.00	Amaka Eze	6	2026-05-06 06:28:37.993	\N	\N	\N	\N	\N
264	319	1	2	RCT-20260607-0264	5439.00	cash	\N	5661.00	Ibrahim Bello	5	2026-05-08 09:28:38.002	\N	\N	\N	\N	\N
265	320	1	2	RCT-20260607-0265	5100.00	cash	\N	0.00	Ibrahim Bello	5	2026-03-14 13:28:38.008	\N	\N	\N	\N	\N
266	321	1	2	RCT-20260607-0266	14000.00	cash	\N	0.00	Ifeoma Musa	8	2026-04-07 14:28:38.018	\N	\N	\N	\N	\N
267	323	1	2	RCT-20260607-0267	1600.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-04-06 07:28:38.029	\N	\N	\N	\N	\N
268	324	1	2	RCT-20260607-0268	11055.00	pos	\N	5445.00	Ibrahim Bello	5	2026-05-30 14:28:38.041	\N	\N	\N	\N	\N
269	325	1	2	RCT-20260607-0269	9600.00	pos	\N	0.00	Ibrahim Bello	5	2026-04-01 06:28:38.047	\N	\N	\N	\N	\N
270	326	1	2	RCT-20260607-0270	8600.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-04-28 08:28:38.054	\N	\N	\N	\N	\N
271	327	1	2	RCT-20260607-0271	16000.00	cash	\N	0.00	Ifeoma Musa	8	2026-03-28 12:28:38.07	\N	\N	\N	\N	\N
272	328	1	2	RCT-20260607-0272	2808.00	pos	\N	4392.00	Ibrahim Bello	5	2026-06-06 06:28:38.077	\N	\N	\N	\N	\N
273	329	1	2	RCT-20260607-0273	8000.00	pos	\N	0.00	Ifeoma Musa	8	2026-03-14 16:28:38.094	\N	\N	\N	\N	\N
274	330	1	2	RCT-20260607-0274	800.00	transfer	\N	0.00	Ibrahim Bello	5	2026-06-06 14:28:38.102	\N	\N	\N	\N	\N
275	331	1	2	RCT-20260607-0275	2700.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-03-14 14:28:38.111	\N	\N	\N	\N	\N
276	332	1	2	RCT-20260607-0276	3960.00	transfer	\N	8040.00	Ibrahim Nwosu	7	2026-04-28 13:28:38.118	\N	\N	\N	\N	\N
277	333	1	2	RCT-20260607-0277	4800.00	cash	\N	0.00	Ifeoma Musa	8	2026-03-10 16:28:38.128	\N	\N	\N	\N	\N
278	334	1	2	RCT-20260607-0278	7800.00	pos	\N	0.00	Ifeoma Musa	8	2026-05-27 10:28:38.141	\N	\N	\N	\N	\N
279	335	1	2	RCT-20260607-0279	7800.00	cash	\N	0.00	Amaka Eze	6	2026-03-25 13:28:38.147	\N	\N	\N	\N	\N
280	336	1	2	RCT-20260607-0280	1800.00	pos	\N	0.00	Ibrahim Bello	5	2026-04-10 07:28:38.154	\N	\N	\N	\N	\N
281	338	1	2	RCT-20260607-0281	2400.00	pos	\N	0.00	Ibrahim Bello	5	2026-03-24 07:28:38.164	\N	\N	\N	\N	\N
282	339	1	2	RCT-20260607-0282	12300.00	cash	\N	0.00	Ibrahim Bello	5	2026-04-03 15:28:38.176	\N	\N	\N	\N	\N
283	340	1	2	RCT-20260607-0283	8800.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-03-20 08:28:38.188	\N	\N	\N	\N	\N
284	341	1	2	RCT-20260607-0284	7000.00	pos	\N	0.00	Ifeoma Musa	8	2026-03-17 14:28:38.194	\N	\N	\N	\N	\N
285	343	1	2	RCT-20260607-0285	11100.00	cash	\N	0.00	Ibrahim Bello	5	2026-04-07 12:28:38.203	\N	\N	\N	\N	\N
286	344	1	2	RCT-20260607-0286	3800.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-03-17 15:28:38.216	\N	\N	\N	\N	\N
287	345	1	2	RCT-20260607-0287	9900.00	pos	\N	0.00	Ifeoma Musa	8	2026-03-18 06:28:38.222	\N	\N	\N	\N	\N
288	346	1	2	RCT-20260607-0288	8000.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-04-15 06:28:38.234	\N	\N	\N	\N	\N
289	347	1	2	RCT-20260607-0289	6396.00	cash	\N	5904.00	Ibrahim Bello	5	2026-05-26 11:28:38.24	\N	\N	\N	\N	\N
290	348	1	2	RCT-20260607-0290	3870.00	pos	\N	9030.00	Amaka Eze	6	2026-04-26 14:28:38.245	\N	\N	\N	\N	\N
291	350	1	2	RCT-20260607-0291	2700.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-05-06 09:28:38.254	\N	\N	\N	\N	\N
292	351	1	2	RCT-20260607-0292	13000.00	cash	\N	0.00	Ibrahim Bello	5	2026-05-04 17:28:38.259	\N	\N	\N	\N	\N
293	352	1	2	RCT-20260607-0293	12000.00	transfer	\N	0.00	Amaka Eze	6	2026-05-18 10:28:38.264	\N	\N	\N	\N	\N
294	353	1	2	RCT-20260607-0294	17100.00	cash	\N	0.00	Ifeoma Musa	8	2026-03-25 16:28:38.27	\N	\N	\N	\N	\N
295	355	1	2	RCT-20260607-0295	12300.00	transfer	\N	0.00	Ibrahim Bello	5	2026-03-21 07:28:38.28	\N	\N	\N	\N	\N
296	358	1	2	RCT-20260607-0296	4488.00	cash	\N	8712.00	Ifeoma Musa	8	2026-06-06 15:28:38.295	\N	\N	\N	\N	\N
297	359	1	2	RCT-20260607-0297	2438.00	pos	\N	2162.00	Ibrahim Bello	5	2026-05-14 07:28:38.301	\N	\N	\N	\N	\N
298	361	1	2	RCT-20260607-0298	18000.00	cash	\N	0.00	Amaka Eze	6	2026-04-13 07:28:38.311	\N	\N	\N	\N	\N
299	362	1	2	RCT-20260607-0299	7400.00	cash	\N	0.00	Ifeoma Musa	8	2026-03-10 07:28:38.32	\N	\N	\N	\N	\N
300	363	1	2	RCT-20260607-0300	9600.00	transfer	\N	0.00	Ibrahim Nwosu	7	2026-04-21 08:28:38.326	\N	\N	\N	\N	\N
301	364	1	2	RCT-20260607-0301	14500.00	pos	\N	0.00	Ibrahim Nwosu	7	2026-03-13 15:28:38.336	\N	\N	\N	\N	\N
302	365	1	2	RCT-20260607-0302	1890.00	transfer	\N	2610.00	Ibrahim Nwosu	7	2026-05-09 12:28:38.343	\N	\N	\N	\N	\N
303	366	1	2	RCT-20260607-0303	13000.00	cash	\N	0.00	Ibrahim Bello	5	2026-04-17 07:28:38.352	\N	\N	\N	\N	\N
304	367	1	2	RCT-20260607-0304	9400.00	pos	\N	0.00	Ifeoma Musa	8	2026-04-13 06:28:38.361	\N	\N	\N	\N	\N
305	368	1	2	RCT-20260607-0305	4437.00	transfer	\N	4263.00	Amaka Eze	6	2026-05-22 07:28:38.367	\N	\N	\N	\N	\N
306	369	1	2	RCT-20260607-0306	4860.00	transfer	\N	8640.00	Ifeoma Musa	8	2026-05-04 16:28:38.383	\N	\N	\N	\N	\N
307	370	1	2	RCT-20260607-0307	16500.00	transfer	\N	0.00	Ibrahim Bello	5	2026-04-05 08:28:38.39	\N	\N	\N	\N	\N
308	371	1	2	RCT-20260607-0308	5950.00	transfer	\N	2550.00	Ifeoma Musa	8	2026-04-04 17:28:38.396	\N	\N	\N	\N	\N
309	373	1	2	RCT-20260607-0309	5724.00	transfer	\N	10176.00	Amaka Eze	6	2026-04-10 11:28:38.416	\N	\N	\N	\N	\N
310	374	1	2	RCT-20260607-0310	13000.00	cash	\N	0.00	Ibrahim Nwosu	7	2026-03-15 12:28:38.423	\N	\N	\N	\N	\N
311	375	1	2	RCT-20260607-0311	5940.00	transfer	\N	5060.00	Ibrahim Bello	5	2026-05-19 15:28:38.431	\N	\N	\N	\N	\N
312	376	1	2	RCT-20260607-0312	18000.00	cash	\N	0.00	Ibrahim Bello	5	2026-03-11 10:28:38.437	\N	\N	\N	\N	\N
313	377	1	2	RCT-20260607-0313	15500.00	transfer	\N	0.00	Ifeoma Musa	8	2026-04-06 10:28:38.444	\N	\N	\N	\N	\N
314	378	1	2	RCT-20260607-0314	8000.00	cash	\N	0.00	Amaka Eze	6	2026-04-27 09:28:38.452	\N	\N	\N	\N	\N
315	379	1	2	RCT-20260607-0315	7800.00	pos	\N	0.00	Amaka Eze	6	2026-04-19 10:28:38.458	\N	\N	\N	\N	\N
316	383	1	2	RCT-20260607-0316	9072.00	pos	\N	5328.00	Amaka Eze	6	2026-05-21 15:28:38.49	\N	\N	\N	\N	\N
317	384	1	2	RCT-20260607-0317	14700.00	cash	\N	0.00	Amaka Eze	6	2026-04-19 15:28:38.497	\N	\N	\N	\N	\N
318	386	1	2	RCT-20260607-0318	4800.00	pos	\N	2700.00	Amaka Eze	6	2026-04-27 09:28:38.517	\N	\N	\N	\N	\N
319	387	1	2	RCT-20260607-0319	3800.00	pos	\N	0.00	Ifeoma Musa	8	2026-04-16 09:28:38.524	\N	\N	\N	\N	\N
320	388	1	2	RCT-20260607-0320	8500.00	cash	\N	0.00	Ibrahim Bello	5	2026-03-18 15:28:38.53	\N	\N	\N	\N	\N
321	389	1	2	RCT-20260607-0321	1904.00	cash	\N	1496.00	Ifeoma Musa	8	2026-06-01 16:28:38.541	\N	\N	\N	\N	\N
322	390	1	2	RCT-20260607-0322	9300.00	pos	\N	0.00	Ibrahim Bello	5	2026-04-18 13:28:38.548	\N	\N	\N	\N	\N
323	392	1	2	RCT-20260607-0323	13500.00	cash	\N	0.00	Amaka Eze	6	2026-03-21 08:28:38.558	\N	\N	\N	\N	\N
324	394	1	2	RCT-20260607-0324	1500.00	transfer	\N	0.00	Ibrahim Bello	5	2026-04-05 08:28:38.568	\N	\N	\N	\N	\N
325	395	1	2	RCT-20260607-0325	6642.00	transfer	\N	5658.00	Ibrahim Nwosu	7	2026-04-27 17:28:38.575	\N	\N	\N	\N	\N
326	396	1	2	RCT-20260607-0326	8990.00	pos	\N	6510.00	Ibrahim Nwosu	7	2026-04-25 08:28:38.581	\N	\N	\N	\N	\N
327	397	1	2	RCT-20260607-0327	9500.00	transfer	\N	0.00	Ifeoma Musa	8	2026-04-06 16:28:38.591	\N	\N	\N	\N	\N
328	399	1	2	RCT-20260607-0328	744.00	transfer	\N	456.00	Ibrahim Nwosu	7	2026-04-26 09:28:38.606	\N	\N	\N	\N	\N
329	401	1	3	RCT-20260607-0329	2232.00	cash	\N	4968.00	Zainab Lawal	9	2026-04-12 15:28:38.686	\N	\N	\N	\N	\N
330	402	1	3	RCT-20260607-0330	15500.00	transfer	\N	0.00	Babajide Bello	11	2026-05-29 13:28:38.692	\N	\N	\N	\N	\N
331	403	1	3	RCT-20260607-0331	2400.00	transfer	\N	0.00	Zainab Lawal	9	2026-03-21 10:28:38.706	\N	\N	\N	\N	\N
332	405	1	3	RCT-20260607-0332	9600.00	cash	\N	0.00	Ngozi Eze	12	2026-04-06 16:28:38.719	\N	\N	\N	\N	\N
333	406	1	3	RCT-20260607-0333	4500.00	pos	\N	0.00	Halima Abubakar	10	2026-03-10 14:28:38.725	\N	\N	\N	\N	\N
334	408	1	3	RCT-20260607-0334	2400.00	pos	\N	0.00	Zainab Lawal	9	2026-03-23 07:28:38.734	\N	\N	\N	\N	\N
335	409	1	3	RCT-20260607-0335	4200.00	transfer	\N	0.00	Zainab Lawal	9	2026-03-26 15:28:38.741	\N	\N	\N	\N	\N
336	411	1	3	RCT-20260607-0336	16000.00	cash	\N	0.00	Halima Abubakar	10	2026-05-28 16:28:38.756	\N	\N	\N	\N	\N
337	412	1	3	RCT-20260607-0337	8000.00	cash	\N	0.00	Zainab Lawal	9	2026-05-31 17:28:38.764	\N	\N	\N	\N	\N
338	413	1	3	RCT-20260607-0338	3900.00	pos	\N	0.00	Ngozi Eze	12	2026-04-22 09:28:38.77	\N	\N	\N	\N	\N
339	414	1	3	RCT-20260607-0339	6300.00	pos	\N	0.00	Zainab Lawal	9	2026-03-12 09:28:38.785	\N	\N	\N	\N	\N
340	415	1	3	RCT-20260607-0340	18500.00	transfer	\N	0.00	Ngozi Eze	12	2026-04-02 14:28:38.792	\N	\N	\N	\N	\N
341	417	1	3	RCT-20260607-0341	15600.00	cash	\N	0.00	Halima Abubakar	10	2026-04-03 14:28:38.81	\N	\N	\N	\N	\N
342	418	1	3	RCT-20260607-0342	2800.00	pos	\N	0.00	Ngozi Eze	12	2026-06-04 09:28:38.823	\N	\N	\N	\N	\N
343	419	1	3	RCT-20260607-0343	5500.00	pos	\N	0.00	Zainab Lawal	9	2026-05-18 10:28:38.83	\N	\N	\N	\N	\N
344	420	1	3	RCT-20260607-0344	2400.00	transfer	\N	0.00	Halima Abubakar	10	2026-06-07 09:28:38.836	\N	\N	\N	\N	\N
345	421	1	3	RCT-20260607-0345	15000.00	transfer	\N	0.00	Ngozi Eze	12	2026-04-01 11:28:38.843	\N	\N	\N	\N	\N
346	422	1	3	RCT-20260607-0346	6080.00	cash	\N	9920.00	Babajide Bello	11	2026-04-13 14:28:38.855	\N	\N	\N	\N	\N
347	423	1	3	RCT-20260607-0347	6750.00	cash	\N	5750.00	Babajide Bello	11	2026-05-22 08:28:38.865	\N	\N	\N	\N	\N
348	424	1	3	RCT-20260607-0348	7000.00	transfer	\N	0.00	Babajide Bello	11	2026-05-30 12:28:38.878	\N	\N	\N	\N	\N
349	426	1	3	RCT-20260607-0349	3800.00	transfer	\N	0.00	Babajide Bello	11	2026-05-09 16:28:38.889	\N	\N	\N	\N	\N
350	427	1	3	RCT-20260607-0350	5100.00	pos	\N	0.00	Zainab Lawal	9	2026-05-27 06:28:38.896	\N	\N	\N	\N	\N
351	428	1	3	RCT-20260607-0351	8125.00	cash	\N	4375.00	Zainab Lawal	9	2026-04-22 07:28:38.902	\N	\N	\N	\N	\N
352	429	1	3	RCT-20260607-0352	16000.00	pos	\N	0.00	Halima Abubakar	10	2026-04-06 15:28:38.908	\N	\N	\N	\N	\N
353	430	1	3	RCT-20260607-0353	4480.00	cash	\N	9520.00	Ngozi Eze	12	2026-03-29 17:28:38.917	\N	\N	\N	\N	\N
354	434	1	3	RCT-20260607-0354	5655.00	cash	\N	8845.00	Zainab Lawal	9	2026-05-09 07:28:38.934	\N	\N	\N	\N	\N
355	435	1	3	RCT-20260607-0355	10500.00	pos	\N	0.00	Babajide Bello	11	2026-03-10 13:28:38.95	\N	\N	\N	\N	\N
356	436	1	3	RCT-20260607-0356	1938.00	pos	\N	1862.00	Ngozi Eze	12	2026-05-30 08:28:38.957	\N	\N	\N	\N	\N
357	437	1	3	RCT-20260607-0357	8800.00	cash	\N	0.00	Zainab Lawal	9	2026-04-16 07:28:38.966	\N	\N	\N	\N	\N
358	438	1	3	RCT-20260607-0358	6528.00	transfer	\N	3672.00	Ngozi Eze	12	2026-04-27 06:28:38.972	\N	\N	\N	\N	\N
359	439	1	3	RCT-20260607-0359	5922.00	transfer	\N	3478.00	Halima Abubakar	10	2026-04-17 14:28:38.979	\N	\N	\N	\N	\N
360	440	1	3	RCT-20260607-0360	11500.00	pos	\N	0.00	Ngozi Eze	12	2026-05-15 06:28:38.985	\N	\N	\N	\N	\N
361	441	1	3	RCT-20260607-0361	12500.00	transfer	\N	0.00	Halima Abubakar	10	2026-05-25 11:28:38.995	\N	\N	\N	\N	\N
362	442	1	3	RCT-20260607-0362	8000.00	cash	\N	0.00	Zainab Lawal	9	2026-03-19 09:28:39.001	\N	\N	\N	\N	\N
363	443	1	3	RCT-20260607-0363	5200.00	cash	\N	0.00	Ngozi Eze	12	2026-04-27 07:28:39.012	\N	\N	\N	\N	\N
364	444	1	3	RCT-20260607-0364	1600.00	transfer	\N	0.00	Ngozi Eze	12	2026-03-20 07:28:39.017	\N	\N	\N	\N	\N
365	445	1	3	RCT-20260607-0365	1500.00	cash	\N	0.00	Zainab Lawal	9	2026-06-04 07:28:39.023	\N	\N	\N	\N	\N
366	446	1	3	RCT-20260607-0366	4800.00	cash	\N	0.00	Babajide Bello	11	2026-04-25 06:28:39.028	\N	\N	\N	\N	\N
367	448	1	3	RCT-20260607-0367	2240.00	cash	\N	1260.00	Ngozi Eze	12	2026-03-24 10:28:39.039	\N	\N	\N	\N	\N
368	449	1	3	RCT-20260607-0368	2400.00	cash	\N	0.00	Ngozi Eze	12	2026-04-30 08:28:39.045	\N	\N	\N	\N	\N
369	451	1	3	RCT-20260607-0369	7000.00	transfer	\N	0.00	Ngozi Eze	12	2026-03-18 13:28:39.055	\N	\N	\N	\N	\N
370	452	1	3	RCT-20260607-0370	9450.00	transfer	\N	4050.00	Halima Abubakar	10	2026-05-07 17:28:39.061	\N	\N	\N	\N	\N
371	453	1	3	RCT-20260607-0371	16500.00	pos	\N	0.00	Halima Abubakar	10	2026-04-01 07:28:39.077	\N	\N	\N	\N	\N
372	454	1	3	RCT-20260607-0372	2600.00	transfer	\N	0.00	Babajide Bello	11	2026-04-27 16:28:39.088	\N	\N	\N	\N	\N
373	457	1	3	RCT-20260607-0373	7400.00	transfer	\N	0.00	Ngozi Eze	12	2026-03-26 10:28:39.106	\N	\N	\N	\N	\N
374	458	1	3	RCT-20260607-0374	6600.00	pos	\N	0.00	Ngozi Eze	12	2026-03-20 12:28:39.112	\N	\N	\N	\N	\N
375	460	1	3	RCT-20260607-0375	8037.00	transfer	\N	6063.00	Zainab Lawal	9	2026-04-06 12:28:39.124	\N	\N	\N	\N	\N
376	461	1	3	RCT-20260607-0376	3416.00	cash	\N	2184.00	Babajide Bello	11	2026-05-28 11:28:39.131	\N	\N	\N	\N	\N
377	462	1	3	RCT-20260607-0377	5600.00	pos	\N	0.00	Ngozi Eze	12	2026-03-20 15:28:39.138	\N	\N	\N	\N	\N
378	466	1	3	RCT-20260607-0378	14100.00	pos	\N	0.00	Ngozi Eze	12	2026-05-01 16:28:39.157	\N	\N	\N	\N	\N
379	467	1	3	RCT-20260607-0379	7600.00	cash	\N	0.00	Zainab Lawal	9	2026-05-29 10:28:39.164	\N	\N	\N	\N	\N
380	468	1	3	RCT-20260607-0380	3600.00	pos	\N	0.00	Ngozi Eze	12	2026-06-02 06:28:39.17	\N	\N	\N	\N	\N
381	469	1	3	RCT-20260607-0381	7000.00	pos	\N	0.00	Babajide Bello	11	2026-04-17 06:28:39.176	\N	\N	\N	\N	\N
382	471	1	3	RCT-20260607-0382	2964.00	pos	\N	2236.00	Ngozi Eze	12	2026-05-01 17:28:39.186	\N	\N	\N	\N	\N
383	472	1	3	RCT-20260607-0383	2442.00	pos	\N	4158.00	Ngozi Eze	12	2026-05-29 15:28:39.199	\N	\N	\N	\N	\N
384	473	1	3	RCT-20260607-0384	15000.00	cash	\N	0.00	Halima Abubakar	10	2026-04-01 08:28:39.205	\N	\N	\N	\N	\N
385	475	1	3	RCT-20260607-0385	8500.00	cash	\N	0.00	Halima Abubakar	10	2026-04-16 10:28:39.214	\N	\N	\N	\N	\N
386	476	1	3	RCT-20260607-0386	13000.00	pos	\N	0.00	Ngozi Eze	12	2026-05-05 13:28:39.22	\N	\N	\N	\N	\N
387	478	1	3	RCT-20260607-0387	10800.00	transfer	\N	0.00	Zainab Lawal	9	2026-05-20 15:28:39.233	\N	\N	\N	\N	\N
388	479	1	3	RCT-20260607-0388	6600.00	cash	\N	0.00	Babajide Bello	11	2026-03-09 06:28:39.24	\N	\N	\N	\N	\N
389	480	1	3	RCT-20260607-0389	8400.00	pos	\N	0.00	Halima Abubakar	10	2026-04-26 09:28:39.245	\N	\N	\N	\N	\N
390	481	1	3	RCT-20260607-0390	15600.00	transfer	\N	0.00	Babajide Bello	11	2026-05-12 15:28:39.251	\N	\N	\N	\N	\N
391	482	1	3	RCT-20260607-0391	15900.00	transfer	\N	0.00	Babajide Bello	11	2026-05-12 16:28:39.256	\N	\N	\N	\N	\N
392	483	1	3	RCT-20260607-0392	2808.00	transfer	\N	2592.00	Babajide Bello	11	2026-03-12 17:28:39.269	\N	\N	\N	\N	\N
393	484	1	3	RCT-20260607-0393	2400.00	transfer	\N	0.00	Babajide Bello	11	2026-03-26 17:28:39.275	\N	\N	\N	\N	\N
394	485	1	3	RCT-20260607-0394	6785.00	transfer	\N	4715.00	Zainab Lawal	9	2026-04-14 09:28:39.281	\N	\N	\N	\N	\N
395	486	1	3	RCT-20260607-0395	15600.00	pos	\N	0.00	Zainab Lawal	9	2026-04-12 17:28:39.286	\N	\N	\N	\N	\N
396	488	1	3	RCT-20260607-0396	8400.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-20 06:28:39.295	\N	\N	\N	\N	\N
397	489	1	3	RCT-20260607-0397	6174.00	cash	\N	3626.00	Zainab Lawal	9	2026-04-18 14:28:39.3	\N	\N	\N	\N	\N
398	490	1	3	RCT-20260607-0398	17100.00	transfer	\N	0.00	Ngozi Eze	12	2026-05-02 10:28:39.305	\N	\N	\N	\N	\N
399	491	1	3	RCT-20260607-0399	18500.00	cash	\N	0.00	Zainab Lawal	9	2026-03-12 12:28:39.312	\N	\N	\N	\N	\N
400	492	1	3	RCT-20260607-0400	4400.00	transfer	\N	0.00	Babajide Bello	11	2026-05-18 12:28:39.318	\N	\N	\N	\N	\N
401	493	1	3	RCT-20260607-0401	9000.00	cash	\N	0.00	Zainab Lawal	9	2026-03-28 14:28:39.324	\N	\N	\N	\N	\N
402	495	1	3	RCT-20260607-0402	2100.00	pos	\N	4900.00	Ngozi Eze	12	2026-03-31 16:28:39.334	\N	\N	\N	\N	\N
403	496	1	3	RCT-20260607-0403	4200.00	cash	\N	0.00	Halima Abubakar	10	2026-06-07 14:28:39.34	\N	\N	\N	\N	\N
404	497	1	3	RCT-20260607-0404	7500.00	cash	\N	0.00	Ngozi Eze	12	2026-03-18 07:28:39.355	\N	\N	\N	\N	\N
405	498	1	3	RCT-20260607-0405	5000.00	cash	\N	0.00	Babajide Bello	11	2026-03-13 06:28:39.362	\N	\N	\N	\N	\N
406	500	1	3	RCT-20260607-0406	12000.00	cash	\N	0.00	Halima Abubakar	10	2026-05-03 15:28:39.373	\N	\N	\N	\N	\N
407	501	1	3	RCT-20260607-0407	18500.00	pos	\N	0.00	Zainab Lawal	9	2026-04-16 15:28:39.38	\N	\N	\N	\N	\N
408	502	1	3	RCT-20260607-0408	22000.00	transfer	\N	0.00	Halima Abubakar	10	2026-05-07 17:28:39.39	\N	\N	\N	\N	\N
409	503	1	3	RCT-20260607-0409	6200.00	pos	\N	0.00	Halima Abubakar	10	2026-03-17 09:28:39.396	\N	\N	\N	\N	\N
410	504	1	3	RCT-20260607-0410	8000.00	cash	\N	0.00	Zainab Lawal	9	2026-05-22 16:28:39.411	\N	\N	\N	\N	\N
411	505	1	3	RCT-20260607-0411	5800.00	cash	\N	0.00	Zainab Lawal	9	2026-03-30 11:28:39.42	\N	\N	\N	\N	\N
412	507	1	3	RCT-20260607-0412	480.00	pos	\N	720.00	Zainab Lawal	9	2026-05-04 14:28:39.434	\N	\N	\N	\N	\N
413	508	1	3	RCT-20260607-0413	2992.00	pos	\N	3808.00	Babajide Bello	11	2026-05-12 15:28:39.44	\N	\N	\N	\N	\N
414	509	1	3	RCT-20260607-0414	14500.00	cash	\N	0.00	Ngozi Eze	12	2026-03-30 17:28:39.446	\N	\N	\N	\N	\N
415	511	1	3	RCT-20260607-0415	9900.00	transfer	\N	0.00	Ngozi Eze	12	2026-04-25 07:28:39.455	\N	\N	\N	\N	\N
416	515	1	3	RCT-20260607-0416	5600.00	cash	\N	0.00	Ngozi Eze	12	2026-06-04 10:28:39.49	\N	\N	\N	\N	\N
417	516	1	3	RCT-20260607-0417	6600.00	transfer	\N	0.00	Ngozi Eze	12	2026-03-25 06:28:39.497	\N	\N	\N	\N	\N
418	517	1	3	RCT-20260607-0418	14000.00	transfer	\N	0.00	Halima Abubakar	10	2026-05-03 07:28:39.509	\N	\N	\N	\N	\N
419	518	1	3	RCT-20260607-0419	1600.00	cash	\N	0.00	Ngozi Eze	12	2026-04-28 12:28:39.518	\N	\N	\N	\N	\N
420	519	1	3	RCT-20260607-0420	14700.00	cash	\N	0.00	Ngozi Eze	12	2026-04-28 10:28:39.527	\N	\N	\N	\N	\N
421	520	1	3	RCT-20260607-0421	8600.00	cash	\N	0.00	Ngozi Eze	12	2026-04-23 07:28:39.533	\N	\N	\N	\N	\N
422	521	1	3	RCT-20260607-0422	7000.00	cash	\N	0.00	Babajide Bello	11	2026-03-18 10:28:39.538	\N	\N	\N	\N	\N
423	522	1	3	RCT-20260607-0423	9000.00	pos	\N	0.00	Halima Abubakar	10	2026-05-05 14:28:39.543	\N	\N	\N	\N	\N
424	523	1	3	RCT-20260607-0424	12900.00	transfer	\N	0.00	Zainab Lawal	9	2026-06-07 06:28:39.551	\N	\N	\N	\N	\N
425	525	1	3	RCT-20260607-0425	14080.00	cash	\N	7920.00	Babajide Bello	11	2026-05-13 09:28:39.56	\N	\N	\N	\N	\N
426	526	1	3	RCT-20260607-0426	5000.00	cash	\N	0.00	Babajide Bello	11	2026-04-14 07:28:39.566	\N	\N	\N	\N	\N
427	527	1	3	RCT-20260607-0427	11000.00	cash	\N	0.00	Halima Abubakar	10	2026-05-14 11:28:39.571	\N	\N	\N	\N	\N
428	528	1	3	RCT-20260607-0428	18000.00	transfer	\N	0.00	Ngozi Eze	12	2026-05-06 14:28:39.581	\N	\N	\N	\N	\N
429	529	1	3	RCT-20260607-0429	9000.00	cash	\N	0.00	Zainab Lawal	9	2026-04-04 10:28:39.586	\N	\N	\N	\N	\N
430	530	1	3	RCT-20260607-0430	6400.00	transfer	\N	0.00	Zainab Lawal	9	2026-04-06 06:28:39.592	\N	\N	\N	\N	\N
431	531	1	3	RCT-20260607-0431	10000.00	pos	\N	0.00	Babajide Bello	11	2026-03-20 15:28:39.598	\N	\N	\N	\N	\N
432	533	1	3	RCT-20260607-0432	3900.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-23 12:28:39.61	\N	\N	\N	\N	\N
433	536	1	3	RCT-20260607-0433	20000.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-09 17:28:39.622	\N	\N	\N	\N	\N
434	537	1	3	RCT-20260607-0434	12000.00	pos	\N	0.00	Halima Abubakar	10	2026-03-10 14:28:39.628	\N	\N	\N	\N	\N
435	538	1	3	RCT-20260607-0435	8427.00	transfer	\N	7473.00	Halima Abubakar	10	2026-04-12 08:28:39.635	\N	\N	\N	\N	\N
436	539	1	3	RCT-20260607-0436	6400.00	cash	\N	0.00	Halima Abubakar	10	2026-04-17 12:28:39.647	\N	\N	\N	\N	\N
437	540	1	3	RCT-20260607-0437	13000.00	transfer	\N	0.00	Babajide Bello	11	2026-03-29 06:28:39.652	\N	\N	\N	\N	\N
438	541	1	3	RCT-20260607-0438	3400.00	transfer	\N	1600.00	Halima Abubakar	10	2026-04-16 08:28:39.658	\N	\N	\N	\N	\N
439	542	1	3	RCT-20260607-0439	14500.00	transfer	\N	0.00	Babajide Bello	11	2026-05-19 08:28:39.665	\N	\N	\N	\N	\N
440	543	1	3	RCT-20260607-0440	10200.00	transfer	\N	0.00	Zainab Lawal	9	2026-03-11 14:28:39.68	\N	\N	\N	\N	\N
441	544	1	3	RCT-20260607-0441	9600.00	transfer	\N	0.00	Babajide Bello	11	2026-05-01 09:28:39.685	\N	\N	\N	\N	\N
442	545	1	3	RCT-20260607-0442	7500.00	cash	\N	0.00	Ngozi Eze	12	2026-03-23 15:28:39.694	\N	\N	\N	\N	\N
443	546	1	3	RCT-20260607-0443	14500.00	pos	\N	0.00	Zainab Lawal	9	2026-03-24 14:28:39.699	\N	\N	\N	\N	\N
444	547	1	3	RCT-20260607-0444	5100.00	pos	\N	0.00	Zainab Lawal	9	2026-05-25 15:28:39.705	\N	\N	\N	\N	\N
445	548	1	3	RCT-20260607-0445	19000.00	transfer	\N	0.00	Ngozi Eze	12	2026-04-18 11:28:39.71	\N	\N	\N	\N	\N
446	549	1	3	RCT-20260607-0446	6000.00	pos	\N	0.00	Zainab Lawal	9	2026-05-23 09:28:39.715	\N	\N	\N	\N	\N
447	550	1	3	RCT-20260607-0447	7200.00	transfer	\N	4800.00	Halima Abubakar	10	2026-05-26 16:28:39.721	\N	\N	\N	\N	\N
448	551	1	3	RCT-20260607-0448	7685.00	transfer	\N	6815.00	Babajide Bello	11	2026-03-25 17:28:39.727	\N	\N	\N	\N	\N
449	552	1	3	RCT-20260607-0449	4992.00	pos	\N	4608.00	Babajide Bello	11	2026-06-04 16:28:39.733	\N	\N	\N	\N	\N
450	553	1	3	RCT-20260607-0450	5400.00	cash	\N	0.00	Zainab Lawal	9	2026-04-21 08:28:39.74	\N	\N	\N	\N	\N
451	554	1	3	RCT-20260607-0451	3600.00	pos	\N	0.00	Halima Abubakar	10	2026-03-10 13:28:39.746	\N	\N	\N	\N	\N
452	556	1	3	RCT-20260607-0452	1200.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-18 06:28:39.756	\N	\N	\N	\N	\N
453	557	1	3	RCT-20260607-0453	6400.00	pos	\N	0.00	Ngozi Eze	12	2026-05-10 12:28:39.762	\N	\N	\N	\N	\N
454	558	1	3	RCT-20260607-0454	10500.00	transfer	\N	0.00	Ngozi Eze	12	2026-03-28 12:28:39.767	\N	\N	\N	\N	\N
455	559	1	3	RCT-20260607-0455	752.00	transfer	\N	848.00	Zainab Lawal	9	2026-04-29 10:28:39.774	\N	\N	\N	\N	\N
456	562	1	3	RCT-20260607-0456	8500.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-21 16:28:39.795	\N	\N	\N	\N	\N
457	563	1	3	RCT-20260607-0457	6600.00	pos	\N	0.00	Halima Abubakar	10	2026-03-31 13:28:39.801	\N	\N	\N	\N	\N
458	564	1	3	RCT-20260607-0458	3400.00	transfer	\N	0.00	Babajide Bello	11	2026-04-07 07:28:39.808	\N	\N	\N	\N	\N
459	565	1	3	RCT-20260607-0459	5940.00	transfer	\N	3060.00	Babajide Bello	11	2026-05-29 08:28:39.815	\N	\N	\N	\N	\N
460	566	1	3	RCT-20260607-0460	3500.00	transfer	\N	0.00	Zainab Lawal	9	2026-06-04 16:28:39.823	\N	\N	\N	\N	\N
461	567	1	3	RCT-20260607-0461	3200.00	transfer	\N	0.00	Babajide Bello	11	2026-03-15 12:28:39.831	\N	\N	\N	\N	\N
462	570	1	3	RCT-20260607-0462	4998.00	cash	\N	9702.00	Babajide Bello	11	2026-04-23 15:28:39.844	\N	\N	\N	\N	\N
463	571	1	3	RCT-20260607-0463	12000.00	transfer	\N	0.00	Zainab Lawal	9	2026-05-12 12:28:39.851	\N	\N	\N	\N	\N
464	574	1	3	RCT-20260607-0464	14000.00	pos	\N	0.00	Halima Abubakar	10	2026-04-09 16:28:39.866	\N	\N	\N	\N	\N
465	575	1	3	RCT-20260607-0465	2760.00	cash	\N	3240.00	Halima Abubakar	10	2026-03-09 12:28:39.873	\N	\N	\N	\N	\N
466	576	1	3	RCT-20260607-0466	12600.00	transfer	\N	0.00	Zainab Lawal	9	2026-04-22 07:28:39.879	\N	\N	\N	\N	\N
467	577	1	3	RCT-20260607-0467	1600.00	cash	\N	0.00	Zainab Lawal	9	2026-03-30 06:28:39.892	\N	\N	\N	\N	\N
468	578	1	3	RCT-20260607-0468	7150.00	transfer	\N	5850.00	Babajide Bello	11	2026-05-22 12:28:39.897	\N	\N	\N	\N	\N
469	579	1	3	RCT-20260607-0469	5360.00	cash	\N	2640.00	Babajide Bello	11	2026-06-01 12:28:39.903	\N	\N	\N	\N	\N
470	580	1	3	RCT-20260607-0470	22000.00	transfer	\N	0.00	Babajide Bello	11	2026-03-25 06:28:39.909	\N	\N	\N	\N	\N
471	582	1	3	RCT-20260607-0471	7400.00	transfer	\N	0.00	Zainab Lawal	9	2026-05-27 17:28:39.918	\N	\N	\N	\N	\N
472	583	1	3	RCT-20260607-0472	12300.00	pos	\N	0.00	Babajide Bello	11	2026-03-10 07:28:39.923	\N	\N	\N	\N	\N
473	584	1	3	RCT-20260607-0473	1800.00	transfer	\N	0.00	Zainab Lawal	9	2026-03-15 10:28:39.929	\N	\N	\N	\N	\N
474	585	1	3	RCT-20260607-0474	14100.00	cash	\N	0.00	Halima Abubakar	10	2026-05-02 14:28:39.934	\N	\N	\N	\N	\N
475	586	1	3	RCT-20260607-0475	4680.00	pos	\N	3120.00	Ngozi Eze	12	2026-05-14 09:28:39.942	\N	\N	\N	\N	\N
476	587	1	3	RCT-20260607-0476	4800.00	transfer	\N	0.00	Halima Abubakar	10	2026-04-14 13:28:39.952	\N	\N	\N	\N	\N
477	588	1	3	RCT-20260607-0477	4000.00	cash	\N	0.00	Ngozi Eze	12	2026-05-19 09:28:39.965	\N	\N	\N	\N	\N
478	589	1	3	RCT-20260607-0478	8500.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-29 10:28:39.977	\N	\N	\N	\N	\N
479	590	1	3	RCT-20260607-0479	2970.00	cash	\N	6030.00	Babajide Bello	11	2026-04-23 08:28:39.988	\N	\N	\N	\N	\N
480	592	1	3	RCT-20260607-0480	13000.00	pos	\N	0.00	Babajide Bello	11	2026-04-20 14:28:40.004	\N	\N	\N	\N	\N
481	593	1	3	RCT-20260607-0481	8600.00	pos	\N	0.00	Babajide Bello	11	2026-03-11 11:28:40.01	\N	\N	\N	\N	\N
482	594	1	3	RCT-20260607-0482	6600.00	pos	\N	0.00	Babajide Bello	11	2026-04-22 16:28:40.018	\N	\N	\N	\N	\N
483	595	1	3	RCT-20260607-0483	12000.00	transfer	\N	0.00	Halima Abubakar	10	2026-03-24 14:28:40.028	\N	\N	\N	\N	\N
484	597	1	3	RCT-20260607-0484	13500.00	transfer	\N	0.00	Babajide Bello	11	2026-04-02 11:28:40.036	\N	\N	\N	\N	\N
485	599	1	3	RCT-20260607-0485	2700.00	transfer	\N	0.00	Zainab Lawal	9	2026-03-16 11:28:40.051	\N	\N	\N	\N	\N
486	600	1	3	RCT-20260607-0486	1800.00	pos	\N	0.00	Halima Abubakar	10	2026-05-28 14:28:40.056	\N	\N	\N	\N	\N
487	601	1	4	RCT-20260607-0487	13000.00	cash	\N	0.00	Gbenga Bello	16	2026-04-14 17:28:40.136	\N	\N	\N	\N	\N
488	603	1	4	RCT-20260607-0488	3192.00	cash	\N	5208.00	Olu Okonkwo	13	2026-04-20 17:28:40.152	\N	\N	\N	\N	\N
489	604	1	4	RCT-20260607-0489	8000.00	pos	\N	0.00	Gbenga Bello	16	2026-04-11 15:28:40.158	\N	\N	\N	\N	\N
490	606	1	4	RCT-20260607-0490	8600.00	cash	\N	0.00	Gbenga Bello	16	2026-03-24 10:28:40.168	\N	\N	\N	\N	\N
491	607	1	4	RCT-20260607-0491	2464.00	pos	\N	3136.00	Tobi Okafor	15	2026-06-03 09:28:40.174	\N	\N	\N	\N	\N
492	608	1	4	RCT-20260607-0492	10500.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-03-26 10:28:40.181	\N	\N	\N	\N	\N
493	609	1	4	RCT-20260607-0493	9000.00	pos	\N	0.00	Olu Okonkwo	13	2026-04-25 07:28:40.187	\N	\N	\N	\N	\N
494	611	1	4	RCT-20260607-0494	10200.00	pos	\N	0.00	Tobi Okafor	15	2026-03-24 12:28:40.197	\N	\N	\N	\N	\N
495	612	1	4	RCT-20260607-0495	4600.00	cash	\N	0.00	Adaeze Babatunde	14	2026-05-15 16:28:40.204	\N	\N	\N	\N	\N
496	613	1	4	RCT-20260607-0496	17000.00	transfer	\N	0.00	Gbenga Bello	16	2026-05-15 11:28:40.213	\N	\N	\N	\N	\N
497	614	1	4	RCT-20260607-0497	10800.00	pos	\N	0.00	Olu Okonkwo	13	2026-03-19 13:28:40.225	\N	\N	\N	\N	\N
498	615	1	4	RCT-20260607-0498	4800.00	pos	\N	0.00	Adaeze Babatunde	14	2026-03-09 13:28:40.231	\N	\N	\N	\N	\N
499	616	1	4	RCT-20260607-0499	3400.00	transfer	\N	0.00	Gbenga Bello	16	2026-06-05 09:28:40.236	\N	\N	\N	\N	\N
500	617	1	4	RCT-20260607-0500	8700.00	pos	\N	0.00	Tobi Okafor	15	2026-03-23 15:28:40.252	\N	\N	\N	\N	\N
501	618	1	4	RCT-20260607-0501	8235.00	cash	\N	5265.00	Olu Okonkwo	13	2026-04-21 14:28:40.257	\N	\N	\N	\N	\N
502	619	1	4	RCT-20260607-0502	10500.00	transfer	\N	0.00	Gbenga Bello	16	2026-03-10 10:28:40.271	\N	\N	\N	\N	\N
503	620	1	4	RCT-20260607-0503	8500.00	cash	\N	0.00	Tobi Okafor	15	2026-04-28 11:28:40.277	\N	\N	\N	\N	\N
504	622	1	4	RCT-20260607-0504	4800.00	pos	\N	0.00	Gbenga Bello	16	2026-04-20 17:28:40.294	\N	\N	\N	\N	\N
505	623	1	4	RCT-20260607-0505	4000.00	cash	\N	0.00	Gbenga Bello	16	2026-04-03 17:28:40.3	\N	\N	\N	\N	\N
506	624	1	4	RCT-20260607-0506	15000.00	transfer	\N	0.00	Olu Okonkwo	13	2026-04-13 16:28:40.306	\N	\N	\N	\N	\N
507	625	1	4	RCT-20260607-0507	4896.00	cash	\N	2304.00	Tobi Okafor	15	2026-04-02 07:28:40.317	\N	\N	\N	\N	\N
508	627	1	4	RCT-20260607-0508	7000.00	transfer	\N	0.00	Tobi Okafor	15	2026-04-29 15:28:40.327	\N	\N	\N	\N	\N
509	628	1	4	RCT-20260607-0509	4704.00	cash	\N	3696.00	Adaeze Babatunde	14	2026-05-08 13:28:40.332	\N	\N	\N	\N	\N
510	629	1	4	RCT-20260607-0510	2106.00	pos	\N	3294.00	Olu Okonkwo	13	2026-05-08 06:28:40.338	\N	\N	\N	\N	\N
511	630	1	4	RCT-20260607-0511	1800.00	cash	\N	0.00	Adaeze Babatunde	14	2026-03-19 16:28:40.344	\N	\N	\N	\N	\N
512	631	1	4	RCT-20260607-0512	5800.00	transfer	\N	0.00	Gbenga Bello	16	2026-03-15 06:28:40.35	\N	\N	\N	\N	\N
513	632	1	4	RCT-20260607-0513	9000.00	transfer	\N	9000.00	Tobi Okafor	15	2026-05-25 14:28:40.356	\N	\N	\N	\N	\N
514	633	1	4	RCT-20260607-0514	8700.00	cash	\N	0.00	Tobi Okafor	15	2026-05-22 13:28:40.361	\N	\N	\N	\N	\N
515	634	1	4	RCT-20260607-0515	11400.00	pos	\N	0.00	Adaeze Babatunde	14	2026-04-07 15:28:40.367	\N	\N	\N	\N	\N
516	635	1	4	RCT-20260607-0516	13500.00	cash	\N	0.00	Tobi Okafor	15	2026-03-11 07:28:40.378	\N	\N	\N	\N	\N
517	637	1	4	RCT-20260607-0517	14400.00	transfer	\N	0.00	Gbenga Bello	16	2026-03-20 08:28:40.389	\N	\N	\N	\N	\N
518	638	1	4	RCT-20260607-0518	2907.00	transfer	\N	2793.00	Gbenga Bello	16	2026-05-02 13:28:40.396	\N	\N	\N	\N	\N
519	639	1	4	RCT-20260607-0519	2700.00	pos	\N	6300.00	Adaeze Babatunde	14	2026-03-12 10:28:40.404	\N	\N	\N	\N	\N
520	640	1	4	RCT-20260607-0520	11400.00	pos	\N	0.00	Tobi Okafor	15	2026-04-07 10:28:40.411	\N	\N	\N	\N	\N
521	641	1	4	RCT-20260607-0521	7200.00	transfer	\N	0.00	Tobi Okafor	15	2026-04-05 17:28:40.417	\N	\N	\N	\N	\N
522	642	1	4	RCT-20260607-0522	11100.00	transfer	\N	0.00	Olu Okonkwo	13	2026-03-31 15:28:40.423	\N	\N	\N	\N	\N
523	643	1	4	RCT-20260607-0523	4200.00	transfer	\N	0.00	Gbenga Bello	16	2026-04-12 14:28:40.43	\N	\N	\N	\N	\N
524	644	1	4	RCT-20260607-0524	1500.00	transfer	\N	0.00	Olu Okonkwo	13	2026-05-04 11:28:40.44	\N	\N	\N	\N	\N
525	646	1	4	RCT-20260607-0525	6200.00	pos	\N	0.00	Tobi Okafor	15	2026-06-04 06:28:40.453	\N	\N	\N	\N	\N
526	647	1	4	RCT-20260607-0526	2064.00	pos	\N	2736.00	Olu Okonkwo	13	2026-06-07 06:28:40.461	\N	\N	\N	\N	\N
527	648	1	4	RCT-20260607-0527	3000.00	pos	\N	0.00	Tobi Okafor	15	2026-03-17 06:28:40.468	\N	\N	\N	\N	\N
528	649	1	4	RCT-20260607-0528	7788.00	transfer	\N	5412.00	Tobi Okafor	15	2026-05-31 11:28:40.48	\N	\N	\N	\N	\N
529	650	1	4	RCT-20260607-0529	7500.00	pos	\N	0.00	Adaeze Babatunde	14	2026-05-16 11:28:40.487	\N	\N	\N	\N	\N
530	651	1	4	RCT-20260607-0530	14400.00	pos	\N	0.00	Tobi Okafor	15	2026-03-13 17:28:40.499	\N	\N	\N	\N	\N
531	652	1	4	RCT-20260607-0531	1240.00	transfer	\N	2760.00	Tobi Okafor	15	2026-06-04 12:28:40.509	\N	\N	\N	\N	\N
532	653	1	4	RCT-20260607-0532	3960.00	cash	\N	5040.00	Tobi Okafor	15	2026-05-21 15:28:40.516	\N	\N	\N	\N	\N
533	654	1	4	RCT-20260607-0533	1800.00	pos	\N	0.00	Tobi Okafor	15	2026-05-29 16:28:40.528	\N	\N	\N	\N	\N
534	655	1	4	RCT-20260607-0534	4800.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-04-06 07:28:40.538	\N	\N	\N	\N	\N
535	656	1	4	RCT-20260607-0535	4080.00	cash	\N	7920.00	Gbenga Bello	16	2026-05-09 08:28:40.545	\N	\N	\N	\N	\N
536	657	1	4	RCT-20260607-0536	7400.00	pos	\N	0.00	Olu Okonkwo	13	2026-03-30 15:28:40.552	\N	\N	\N	\N	\N
537	658	1	4	RCT-20260607-0537	11400.00	transfer	\N	0.00	Gbenga Bello	16	2026-03-10 09:28:40.558	\N	\N	\N	\N	\N
538	659	1	4	RCT-20260607-0538	9000.00	transfer	\N	0.00	Gbenga Bello	16	2026-04-22 10:28:40.564	\N	\N	\N	\N	\N
539	660	1	4	RCT-20260607-0539	15600.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-04-01 16:28:40.576	\N	\N	\N	\N	\N
540	661	1	4	RCT-20260607-0540	9500.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-03-13 16:28:40.582	\N	\N	\N	\N	\N
541	662	1	4	RCT-20260607-0541	11400.00	pos	\N	0.00	Olu Okonkwo	13	2026-04-09 13:28:40.589	\N	\N	\N	\N	\N
542	663	1	4	RCT-20260607-0542	11100.00	cash	\N	0.00	Gbenga Bello	16	2026-06-06 11:28:40.597	\N	\N	\N	\N	\N
543	664	1	4	RCT-20260607-0543	9600.00	cash	\N	0.00	Tobi Okafor	15	2026-04-02 09:28:40.603	\N	\N	\N	\N	\N
544	666	1	4	RCT-20260607-0544	9800.00	pos	\N	0.00	Tobi Okafor	15	2026-04-13 11:28:40.613	\N	\N	\N	\N	\N
545	667	1	4	RCT-20260607-0545	14000.00	cash	\N	0.00	Adaeze Babatunde	14	2026-04-04 16:28:40.62	\N	\N	\N	\N	\N
546	668	1	4	RCT-20260607-0546	6500.00	transfer	\N	0.00	Olu Okonkwo	13	2026-04-01 14:28:40.627	\N	\N	\N	\N	\N
547	669	1	4	RCT-20260607-0547	9500.00	cash	\N	0.00	Olu Okonkwo	13	2026-04-14 17:28:40.633	\N	\N	\N	\N	\N
548	670	1	4	RCT-20260607-0548	8600.00	pos	\N	0.00	Gbenga Bello	16	2026-04-04 14:28:40.642	\N	\N	\N	\N	\N
549	671	1	4	RCT-20260607-0549	2184.00	pos	\N	3416.00	Olu Okonkwo	13	2026-04-29 07:28:40.652	\N	\N	\N	\N	\N
550	673	1	4	RCT-20260607-0550	18500.00	transfer	\N	0.00	Gbenga Bello	16	2026-05-18 15:28:40.667	\N	\N	\N	\N	\N
551	674	1	4	RCT-20260607-0551	8800.00	pos	\N	0.00	Olu Okonkwo	13	2026-04-30 07:28:40.673	\N	\N	\N	\N	\N
552	675	1	4	RCT-20260607-0552	7000.00	cash	\N	0.00	Olu Okonkwo	13	2026-04-14 17:28:40.679	\N	\N	\N	\N	\N
553	676	1	4	RCT-20260607-0553	5400.00	pos	\N	0.00	Gbenga Bello	16	2026-03-09 14:28:40.685	\N	\N	\N	\N	\N
554	677	1	4	RCT-20260607-0554	11700.00	pos	\N	0.00	Olu Okonkwo	13	2026-03-27 09:28:40.69	\N	\N	\N	\N	\N
555	678	1	4	RCT-20260607-0555	14700.00	cash	\N	0.00	Adaeze Babatunde	14	2026-05-19 07:28:40.696	\N	\N	\N	\N	\N
556	679	1	4	RCT-20260607-0556	4107.00	cash	\N	6993.00	Olu Okonkwo	13	2026-04-08 06:28:40.703	\N	\N	\N	\N	\N
557	680	1	4	RCT-20260607-0557	7440.00	cash	\N	8060.00	Gbenga Bello	16	2026-04-15 06:28:40.712	\N	\N	\N	\N	\N
558	681	1	4	RCT-20260607-0558	1274.00	pos	\N	1326.00	Olu Okonkwo	13	2026-03-27 06:28:40.719	\N	\N	\N	\N	\N
559	682	1	4	RCT-20260607-0559	7200.00	transfer	\N	0.00	Gbenga Bello	16	2026-03-13 15:28:40.725	\N	\N	\N	\N	\N
560	683	1	4	RCT-20260607-0560	17500.00	transfer	\N	0.00	Olu Okonkwo	13	2026-04-29 12:28:40.736	\N	\N	\N	\N	\N
561	684	1	4	RCT-20260607-0561	3600.00	cash	\N	0.00	Adaeze Babatunde	14	2026-05-05 06:28:40.741	\N	\N	\N	\N	\N
562	685	1	4	RCT-20260607-0562	9500.00	cash	\N	0.00	Gbenga Bello	16	2026-03-22 17:28:40.749	\N	\N	\N	\N	\N
563	686	1	4	RCT-20260607-0563	9300.00	transfer	\N	0.00	Tobi Okafor	15	2026-05-30 09:28:40.757	\N	\N	\N	\N	\N
564	687	1	4	RCT-20260607-0564	8000.00	cash	\N	0.00	Tobi Okafor	15	2026-06-04 11:28:40.763	\N	\N	\N	\N	\N
565	688	1	4	RCT-20260607-0565	8400.00	transfer	\N	0.00	Gbenga Bello	16	2026-04-23 14:28:40.769	\N	\N	\N	\N	\N
566	689	1	4	RCT-20260607-0566	7200.00	cash	\N	0.00	Olu Okonkwo	13	2026-03-21 08:28:40.775	\N	\N	\N	\N	\N
567	690	1	4	RCT-20260607-0567	2600.00	pos	\N	0.00	Adaeze Babatunde	14	2026-05-25 12:28:40.787	\N	\N	\N	\N	\N
568	691	1	4	RCT-20260607-0568	5600.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-03-17 13:28:40.795	\N	\N	\N	\N	\N
569	692	1	4	RCT-20260607-0569	6300.00	pos	\N	0.00	Tobi Okafor	15	2026-05-16 09:28:40.801	\N	\N	\N	\N	\N
570	693	1	4	RCT-20260607-0570	17000.00	transfer	\N	0.00	Gbenga Bello	16	2026-06-06 15:28:40.807	\N	\N	\N	\N	\N
571	694	1	4	RCT-20260607-0571	3500.00	transfer	\N	0.00	Olu Okonkwo	13	2026-03-16 11:28:40.813	\N	\N	\N	\N	\N
572	695	1	4	RCT-20260607-0572	7800.00	cash	\N	0.00	Tobi Okafor	15	2026-05-14 16:28:40.819	\N	\N	\N	\N	\N
573	696	1	4	RCT-20260607-0573	10600.00	cash	\N	0.00	Tobi Okafor	15	2026-03-29 06:28:40.826	\N	\N	\N	\N	\N
574	697	1	4	RCT-20260607-0574	6370.00	pos	\N	3430.00	Tobi Okafor	15	2026-04-19 09:28:40.832	\N	\N	\N	\N	\N
575	698	1	4	RCT-20260607-0575	12900.00	cash	\N	0.00	Adaeze Babatunde	14	2026-03-31 07:28:40.839	\N	\N	\N	\N	\N
576	699	1	4	RCT-20260607-0576	3900.00	pos	\N	0.00	Adaeze Babatunde	14	2026-05-02 12:28:40.847	\N	\N	\N	\N	\N
577	701	1	4	RCT-20260607-0577	8700.00	cash	\N	0.00	Adaeze Babatunde	14	2026-03-25 09:28:40.863	\N	\N	\N	\N	\N
578	702	1	4	RCT-20260607-0578	12500.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-04-21 09:28:40.869	\N	\N	\N	\N	\N
579	704	1	4	RCT-20260607-0579	4750.00	transfer	\N	7750.00	Olu Okonkwo	13	2026-06-02 15:28:40.89	\N	\N	\N	\N	\N
580	706	1	4	RCT-20260607-0580	800.00	pos	\N	0.00	Gbenga Bello	16	2026-03-17 13:28:40.909	\N	\N	\N	\N	\N
581	707	1	4	RCT-20260607-0581	8112.00	transfer	\N	7488.00	Adaeze Babatunde	14	2026-04-29 07:28:40.915	\N	\N	\N	\N	\N
582	708	1	4	RCT-20260607-0582	5800.00	cash	\N	0.00	Olu Okonkwo	13	2026-03-20 16:28:40.925	\N	\N	\N	\N	\N
583	709	1	4	RCT-20260607-0583	5400.00	pos	\N	8100.00	Tobi Okafor	15	2026-05-31 12:28:40.934	\N	\N	\N	\N	\N
584	710	1	4	RCT-20260607-0584	2970.00	transfer	\N	6930.00	Olu Okonkwo	13	2026-05-02 09:28:40.941	\N	\N	\N	\N	\N
585	711	1	4	RCT-20260607-0585	1456.00	transfer	\N	1144.00	Gbenga Bello	16	2026-05-23 15:28:40.948	\N	\N	\N	\N	\N
586	712	1	4	RCT-20260607-0586	8400.00	cash	\N	0.00	Tobi Okafor	15	2026-04-24 08:28:40.954	\N	\N	\N	\N	\N
587	713	1	4	RCT-20260607-0587	15500.00	transfer	\N	0.00	Tobi Okafor	15	2026-04-26 15:28:40.966	\N	\N	\N	\N	\N
588	714	1	4	RCT-20260607-0588	5328.00	cash	\N	9072.00	Olu Okonkwo	13	2026-05-16 11:28:40.972	\N	\N	\N	\N	\N
589	716	1	4	RCT-20260607-0589	16500.00	pos	\N	0.00	Adaeze Babatunde	14	2026-03-16 17:28:40.983	\N	\N	\N	\N	\N
590	717	1	4	RCT-20260607-0590	8800.00	pos	\N	0.00	Adaeze Babatunde	14	2026-03-27 07:28:40.989	\N	\N	\N	\N	\N
591	719	1	4	RCT-20260607-0591	2820.00	pos	\N	3180.00	Tobi Okafor	15	2026-05-23 07:28:40.999	\N	\N	\N	\N	\N
592	721	1	4	RCT-20260607-0592	7480.00	cash	\N	3520.00	Olu Okonkwo	13	2026-06-06 07:28:41.014	\N	\N	\N	\N	\N
593	723	1	4	RCT-20260607-0593	7200.00	pos	\N	0.00	Tobi Okafor	15	2026-04-15 07:28:41.023	\N	\N	\N	\N	\N
594	724	1	4	RCT-20260607-0594	7400.00	pos	\N	0.00	Tobi Okafor	15	2026-03-13 08:28:41.03	\N	\N	\N	\N	\N
595	725	1	4	RCT-20260607-0595	3828.00	pos	\N	4872.00	Tobi Okafor	15	2026-04-25 07:28:41.047	\N	\N	\N	\N	\N
596	726	1	4	RCT-20260607-0596	560.00	transfer	\N	240.00	Adaeze Babatunde	14	2026-05-09 14:28:41.054	\N	\N	\N	\N	\N
597	727	1	4	RCT-20260607-0597	2880.00	transfer	\N	6120.00	Tobi Okafor	15	2026-05-05 14:28:41.06	\N	\N	\N	\N	\N
598	728	1	4	RCT-20260607-0598	4800.00	cash	\N	0.00	Tobi Okafor	15	2026-03-11 14:28:41.066	\N	\N	\N	\N	\N
599	729	1	4	RCT-20260607-0599	5088.00	pos	\N	10812.00	Olu Okonkwo	13	2026-06-04 10:28:41.076	\N	\N	\N	\N	\N
600	730	1	4	RCT-20260607-0600	6400.00	cash	\N	0.00	Tobi Okafor	15	2026-03-22 10:28:41.083	\N	\N	\N	\N	\N
601	731	1	4	RCT-20260607-0601	3196.00	cash	\N	6204.00	Tobi Okafor	15	2026-05-11 12:28:41.09	\N	\N	\N	\N	\N
602	732	1	4	RCT-20260607-0602	8400.00	pos	\N	11600.00	Tobi Okafor	15	2026-06-05 08:28:41.097	\N	\N	\N	\N	\N
603	734	1	4	RCT-20260607-0603	15600.00	pos	\N	0.00	Gbenga Bello	16	2026-03-10 13:28:41.117	\N	\N	\N	\N	\N
604	735	1	4	RCT-20260607-0604	15500.00	cash	\N	0.00	Olu Okonkwo	13	2026-03-15 15:28:41.132	\N	\N	\N	\N	\N
605	736	1	4	RCT-20260607-0605	13000.00	transfer	\N	0.00	Olu Okonkwo	13	2026-04-28 11:28:41.138	\N	\N	\N	\N	\N
606	737	1	4	RCT-20260607-0606	3420.00	pos	\N	2280.00	Tobi Okafor	15	2026-04-16 08:28:41.144	\N	\N	\N	\N	\N
607	738	1	4	RCT-20260607-0607	12000.00	cash	\N	0.00	Tobi Okafor	15	2026-03-12 15:28:41.151	\N	\N	\N	\N	\N
608	739	1	4	RCT-20260607-0608	5100.00	pos	\N	0.00	Gbenga Bello	16	2026-04-18 14:28:41.158	\N	\N	\N	\N	\N
609	740	1	4	RCT-20260607-0609	6600.00	transfer	\N	0.00	Tobi Okafor	15	2026-05-03 17:28:41.164	\N	\N	\N	\N	\N
610	741	1	4	RCT-20260607-0610	17000.00	cash	\N	0.00	Gbenga Bello	16	2026-03-27 12:28:41.169	\N	\N	\N	\N	\N
611	742	1	4	RCT-20260607-0611	6237.00	cash	\N	3663.00	Gbenga Bello	16	2026-03-17 12:28:41.175	\N	\N	\N	\N	\N
612	743	1	4	RCT-20260607-0612	9000.00	cash	\N	0.00	Adaeze Babatunde	14	2026-03-14 06:28:41.182	\N	\N	\N	\N	\N
613	746	1	4	RCT-20260607-0613	6300.00	pos	\N	0.00	Olu Okonkwo	13	2026-04-15 14:28:41.218	\N	\N	\N	\N	\N
614	747	1	4	RCT-20260607-0614	9500.00	pos	\N	0.00	Olu Okonkwo	13	2026-03-12 09:28:41.224	\N	\N	\N	\N	\N
615	748	1	4	RCT-20260607-0615	1600.00	pos	\N	0.00	Gbenga Bello	16	2026-04-25 09:28:41.23	\N	\N	\N	\N	\N
616	749	1	4	RCT-20260607-0616	6000.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-05-15 08:28:41.241	\N	\N	\N	\N	\N
617	750	1	4	RCT-20260607-0617	6300.00	pos	\N	4200.00	Gbenga Bello	16	2026-04-27 17:28:41.247	\N	\N	\N	\N	\N
618	751	1	4	RCT-20260607-0618	4350.00	transfer	\N	4350.00	Adaeze Babatunde	14	2026-05-02 12:28:41.257	\N	\N	\N	\N	\N
619	752	1	4	RCT-20260607-0619	1785.00	transfer	\N	3315.00	Tobi Okafor	15	2026-06-05 09:28:41.262	\N	\N	\N	\N	\N
620	754	1	4	RCT-20260607-0620	17500.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-03-22 15:28:41.279	\N	\N	\N	\N	\N
621	755	1	4	RCT-20260607-0621	8000.00	pos	\N	0.00	Gbenga Bello	16	2026-03-17 07:28:41.285	\N	\N	\N	\N	\N
622	756	1	4	RCT-20260607-0622	9400.00	pos	\N	0.00	Olu Okonkwo	13	2026-04-06 14:28:41.297	\N	\N	\N	\N	\N
623	758	1	4	RCT-20260607-0623	6480.00	cash	\N	5520.00	Adaeze Babatunde	14	2026-05-30 10:28:41.309	\N	\N	\N	\N	\N
624	759	1	4	RCT-20260607-0624	9800.00	transfer	\N	0.00	Gbenga Bello	16	2026-04-16 06:28:41.316	\N	\N	\N	\N	\N
625	760	1	4	RCT-20260607-0625	12000.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-05-28 09:28:41.322	\N	\N	\N	\N	\N
626	762	1	4	RCT-20260607-0626	12500.00	transfer	\N	0.00	Tobi Okafor	15	2026-04-07 17:28:41.332	\N	\N	\N	\N	\N
627	763	1	4	RCT-20260607-0627	3720.00	transfer	\N	8280.00	Adaeze Babatunde	14	2026-05-28 08:28:41.339	\N	\N	\N	\N	\N
628	765	1	4	RCT-20260607-0628	11700.00	cash	\N	0.00	Olu Okonkwo	13	2026-03-15 09:28:41.351	\N	\N	\N	\N	\N
629	766	1	4	RCT-20260607-0629	516.00	transfer	\N	684.00	Tobi Okafor	15	2026-03-24 13:28:41.359	\N	\N	\N	\N	\N
630	767	1	4	RCT-20260607-0630	1500.00	pos	\N	0.00	Olu Okonkwo	13	2026-03-23 13:28:41.371	\N	\N	\N	\N	\N
631	768	1	4	RCT-20260607-0631	16000.00	transfer	\N	0.00	Gbenga Bello	16	2026-05-29 08:28:41.378	\N	\N	\N	\N	\N
632	769	1	4	RCT-20260607-0632	9900.00	transfer	\N	0.00	Gbenga Bello	16	2026-04-08 14:28:41.385	\N	\N	\N	\N	\N
633	770	1	4	RCT-20260607-0633	12500.00	transfer	\N	0.00	Gbenga Bello	16	2026-05-22 15:28:41.392	\N	\N	\N	\N	\N
634	771	1	4	RCT-20260607-0634	464.00	transfer	\N	336.00	Olu Okonkwo	13	2026-05-27 14:28:41.398	\N	\N	\N	\N	\N
635	772	1	4	RCT-20260607-0635	7200.00	pos	\N	0.00	Olu Okonkwo	13	2026-03-17 12:28:41.407	\N	\N	\N	\N	\N
636	774	1	4	RCT-20260607-0636	7750.00	transfer	\N	4750.00	Tobi Okafor	15	2026-05-03 15:28:41.419	\N	\N	\N	\N	\N
637	775	1	4	RCT-20260607-0637	9300.00	transfer	\N	0.00	Olu Okonkwo	13	2026-04-06 06:28:41.425	\N	\N	\N	\N	\N
638	776	1	4	RCT-20260607-0638	11285.00	transfer	\N	7215.00	Gbenga Bello	16	2026-05-28 10:28:41.431	\N	\N	\N	\N	\N
639	779	1	4	RCT-20260607-0639	12000.00	pos	\N	0.00	Gbenga Bello	16	2026-04-04 17:28:41.443	\N	\N	\N	\N	\N
640	780	1	4	RCT-20260607-0640	4324.00	pos	\N	5076.00	Gbenga Bello	16	2026-05-30 07:28:41.448	\N	\N	\N	\N	\N
641	781	1	4	RCT-20260607-0641	7500.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-03-12 17:28:41.453	\N	\N	\N	\N	\N
642	782	1	4	RCT-20260607-0642	17100.00	transfer	\N	0.00	Olu Okonkwo	13	2026-03-20 07:28:41.459	\N	\N	\N	\N	\N
643	783	1	4	RCT-20260607-0643	12000.00	cash	\N	0.00	Gbenga Bello	16	2026-05-13 10:28:41.464	\N	\N	\N	\N	\N
644	785	1	4	RCT-20260607-0644	3956.00	cash	\N	4644.00	Adaeze Babatunde	14	2026-04-23 13:28:41.476	\N	\N	\N	\N	\N
645	786	1	4	RCT-20260607-0645	14300.00	pos	\N	7700.00	Tobi Okafor	15	2026-05-02 08:28:41.484	\N	\N	\N	\N	\N
646	787	1	4	RCT-20260607-0646	22000.00	cash	\N	0.00	Gbenga Bello	16	2026-04-12 11:28:41.495	\N	\N	\N	\N	\N
647	788	1	4	RCT-20260607-0647	4257.00	cash	\N	8643.00	Gbenga Bello	16	2026-06-02 15:28:41.501	\N	\N	\N	\N	\N
648	789	1	4	RCT-20260607-0648	8800.00	cash	\N	0.00	Adaeze Babatunde	14	2026-03-11 17:28:41.507	\N	\N	\N	\N	\N
649	790	1	4	RCT-20260607-0649	8000.00	transfer	\N	0.00	Olu Okonkwo	13	2026-05-26 15:28:41.513	\N	\N	\N	\N	\N
650	791	1	4	RCT-20260607-0650	11400.00	transfer	\N	0.00	Adaeze Babatunde	14	2026-04-07 17:28:41.519	\N	\N	\N	\N	\N
651	792	1	4	RCT-20260607-0651	20000.00	cash	\N	0.00	Adaeze Babatunde	14	2026-03-30 10:28:41.525	\N	\N	\N	\N	\N
652	795	1	4	RCT-20260607-0652	22000.00	pos	\N	0.00	Adaeze Babatunde	14	2026-06-05 09:28:41.546	\N	\N	\N	\N	\N
653	797	1	4	RCT-20260607-0653	3360.00	transfer	\N	3640.00	Tobi Okafor	15	2026-05-27 09:28:41.556	\N	\N	\N	\N	\N
654	798	1	4	RCT-20260607-0654	14100.00	cash	\N	0.00	Tobi Okafor	15	2026-03-15 13:28:41.562	\N	\N	\N	\N	\N
655	800	1	4	RCT-20260607-0655	8400.00	cash	\N	9100.00	Adaeze Babatunde	14	2026-05-13 17:28:41.577	\N	\N	\N	\N	\N
656	802	1	5	RCT-20260607-0656	800.00	transfer	\N	0.00	Sule Adeyemi	18	2026-03-12 15:28:41.654	\N	\N	\N	\N	\N
657	803	1	5	RCT-20260607-0657	9900.00	transfer	\N	0.00	Sule Danjuma	17	2026-04-02 07:28:41.666	\N	\N	\N	\N	\N
658	804	1	5	RCT-20260607-0658	11000.00	cash	\N	9000.00	Sule Adeyemi	18	2026-04-21 10:28:41.673	\N	\N	\N	\N	\N
659	805	1	5	RCT-20260607-0659	5292.00	pos	\N	3108.00	Sule Danjuma	17	2026-06-01 15:28:41.68	\N	\N	\N	\N	\N
660	806	1	5	RCT-20260607-0660	5400.00	cash	\N	0.00	Yusuf Alabi	19	2026-05-06 06:28:41.686	\N	\N	\N	\N	\N
661	807	1	5	RCT-20260607-0661	4900.00	transfer	\N	5100.00	Yusuf Alabi	19	2026-03-18 09:28:41.693	\N	\N	\N	\N	\N
662	809	1	5	RCT-20260607-0662	7600.00	transfer	\N	0.00	Sule Danjuma	17	2026-04-17 06:28:41.703	\N	\N	\N	\N	\N
663	810	1	5	RCT-20260607-0663	3726.00	cash	\N	4374.00	Sule Adeyemi	18	2026-05-07 17:28:41.708	\N	\N	\N	\N	\N
664	811	1	5	RCT-20260607-0664	2400.00	transfer	\N	0.00	Yusuf Alabi	19	2026-03-26 06:28:41.721	\N	\N	\N	\N	\N
665	812	1	5	RCT-20260607-0665	18500.00	pos	\N	0.00	Sule Danjuma	17	2026-05-15 09:28:41.727	\N	\N	\N	\N	\N
666	814	1	5	RCT-20260607-0666	9900.00	transfer	\N	0.00	Yusuf Alabi	19	2026-04-19 15:28:41.736	\N	\N	\N	\N	\N
667	815	1	5	RCT-20260607-0667	8400.00	transfer	\N	0.00	Sule Adeyemi	18	2026-04-30 12:28:41.742	\N	\N	\N	\N	\N
668	816	1	5	RCT-20260607-0668	2592.00	cash	\N	2208.00	Sule Nwachukwu	20	2026-04-21 14:28:41.757	\N	\N	\N	\N	\N
669	817	1	5	RCT-20260607-0669	5841.00	cash	\N	4059.00	Sule Adeyemi	18	2026-05-20 12:28:41.767	\N	\N	\N	\N	\N
670	818	1	5	RCT-20260607-0670	4800.00	transfer	\N	0.00	Yusuf Alabi	19	2026-05-01 14:28:41.778	\N	\N	\N	\N	\N
671	819	1	5	RCT-20260607-0671	4200.00	pos	\N	7800.00	Yusuf Alabi	19	2026-03-11 17:28:41.784	\N	\N	\N	\N	\N
672	822	1	5	RCT-20260607-0672	4500.00	cash	\N	3000.00	Sule Nwachukwu	20	2026-05-13 10:28:41.803	\N	\N	\N	\N	\N
673	824	1	5	RCT-20260607-0673	14500.00	pos	\N	0.00	Sule Nwachukwu	20	2026-03-31 13:28:41.827	\N	\N	\N	\N	\N
674	825	1	5	RCT-20260607-0674	5185.00	pos	\N	3315.00	Yusuf Alabi	19	2026-05-20 06:28:41.832	\N	\N	\N	\N	\N
675	826	1	5	RCT-20260607-0675	4606.00	transfer	\N	4794.00	Yusuf Alabi	19	2026-04-28 13:28:41.839	\N	\N	\N	\N	\N
676	827	1	5	RCT-20260607-0676	6500.00	pos	\N	0.00	Sule Adeyemi	18	2026-04-03 13:28:41.846	\N	\N	\N	\N	\N
677	828	1	5	RCT-20260607-0677	4140.00	pos	\N	4860.00	Sule Adeyemi	18	2026-05-09 17:28:41.852	\N	\N	\N	\N	\N
678	829	1	5	RCT-20260607-0678	5100.00	pos	\N	0.00	Sule Nwachukwu	20	2026-04-18 16:28:41.858	\N	\N	\N	\N	\N
679	830	1	5	RCT-20260607-0679	12095.00	transfer	\N	8405.00	Sule Danjuma	17	2026-04-26 08:28:41.864	\N	\N	\N	\N	\N
680	831	1	5	RCT-20260607-0680	8200.00	transfer	\N	0.00	Sule Nwachukwu	20	2026-03-20 16:28:41.876	\N	\N	\N	\N	\N
681	832	1	5	RCT-20260607-0681	2760.00	pos	\N	3240.00	Sule Adeyemi	18	2026-04-23 09:28:41.885	\N	\N	\N	\N	\N
682	833	1	5	RCT-20260607-0682	9000.00	transfer	\N	0.00	Sule Nwachukwu	20	2026-04-01 14:28:41.893	\N	\N	\N	\N	\N
683	834	1	5	RCT-20260607-0683	11500.00	pos	\N	0.00	Sule Nwachukwu	20	2026-04-27 13:28:41.9	\N	\N	\N	\N	\N
684	836	1	5	RCT-20260607-0684	800.00	cash	\N	0.00	Sule Nwachukwu	20	2026-03-31 14:28:41.91	\N	\N	\N	\N	\N
685	837	1	5	RCT-20260607-0685	3900.00	pos	\N	0.00	Sule Nwachukwu	20	2026-03-29 13:28:41.916	\N	\N	\N	\N	\N
686	838	1	5	RCT-20260607-0686	1056.00	pos	\N	544.00	Sule Danjuma	17	2026-04-21 13:28:41.922	\N	\N	\N	\N	\N
687	839	1	5	RCT-20260607-0687	13200.00	cash	\N	0.00	Sule Adeyemi	18	2026-06-02 15:28:41.927	\N	\N	\N	\N	\N
688	840	1	5	RCT-20260607-0688	9600.00	cash	\N	0.00	Sule Adeyemi	18	2026-03-19 10:28:41.933	\N	\N	\N	\N	\N
689	842	1	5	RCT-20260607-0689	10800.00	transfer	\N	0.00	Sule Nwachukwu	20	2026-03-28 09:28:41.942	\N	\N	\N	\N	\N
690	843	1	5	RCT-20260607-0690	9000.00	transfer	\N	0.00	Sule Danjuma	17	2026-05-01 17:28:41.949	\N	\N	\N	\N	\N
691	844	1	5	RCT-20260607-0691	22000.00	transfer	\N	0.00	Sule Danjuma	17	2026-03-28 16:28:41.964	\N	\N	\N	\N	\N
692	846	1	5	RCT-20260607-0692	12000.00	transfer	\N	0.00	Yusuf Alabi	19	2026-04-25 16:28:41.973	\N	\N	\N	\N	\N
693	848	1	5	RCT-20260607-0693	12900.00	pos	\N	0.00	Sule Danjuma	17	2026-03-18 14:28:41.988	\N	\N	\N	\N	\N
694	849	1	5	RCT-20260607-0694	2058.00	transfer	\N	2142.00	Sule Nwachukwu	20	2026-06-07 15:28:42.001	\N	\N	\N	\N	\N
695	850	1	5	RCT-20260607-0695	5200.00	pos	\N	0.00	Sule Adeyemi	18	2026-03-14 06:28:42.015	\N	\N	\N	\N	\N
696	851	1	5	RCT-20260607-0696	5148.00	cash	\N	2652.00	Sule Nwachukwu	20	2026-04-22 07:28:42.023	\N	\N	\N	\N	\N
697	852	1	5	RCT-20260607-0697	13000.00	pos	\N	0.00	Sule Adeyemi	18	2026-04-19 09:28:42.029	\N	\N	\N	\N	\N
698	853	1	5	RCT-20260607-0698	4736.00	pos	\N	2664.00	Sule Danjuma	17	2026-05-22 15:28:42.036	\N	\N	\N	\N	\N
699	854	1	5	RCT-20260607-0699	16000.00	transfer	\N	0.00	Yusuf Alabi	19	2026-03-13 17:28:42.043	\N	\N	\N	\N	\N
700	855	1	5	RCT-20260607-0700	9800.00	cash	\N	0.00	Yusuf Alabi	19	2026-05-01 10:28:42.049	\N	\N	\N	\N	\N
701	856	1	5	RCT-20260607-0701	13500.00	cash	\N	0.00	Yusuf Alabi	19	2026-06-03 08:28:42.055	\N	\N	\N	\N	\N
702	857	1	5	RCT-20260607-0702	17500.00	transfer	\N	0.00	Yusuf Alabi	19	2026-04-17 12:28:42.07	\N	\N	\N	\N	\N
703	858	1	5	RCT-20260607-0703	4680.00	cash	\N	2520.00	Yusuf Alabi	19	2026-05-26 06:28:42.077	\N	\N	\N	\N	\N
704	859	1	5	RCT-20260607-0704	12500.00	cash	\N	0.00	Sule Danjuma	17	2026-04-12 09:28:42.083	\N	\N	\N	\N	\N
705	860	1	5	RCT-20260607-0705	2880.00	transfer	\N	1920.00	Yusuf Alabi	19	2026-05-16 15:28:42.092	\N	\N	\N	\N	\N
706	861	1	5	RCT-20260607-0706	8700.00	pos	\N	0.00	Yusuf Alabi	19	2026-04-05 13:28:42.098	\N	\N	\N	\N	\N
707	862	1	5	RCT-20260607-0707	5762.00	cash	\N	2838.00	Sule Nwachukwu	20	2026-04-21 10:28:42.104	\N	\N	\N	\N	\N
708	863	1	5	RCT-20260607-0708	14500.00	cash	\N	0.00	Yusuf Alabi	19	2026-03-12 13:28:42.11	\N	\N	\N	\N	\N
709	864	1	5	RCT-20260607-0709	8100.00	cash	\N	0.00	Sule Nwachukwu	20	2026-05-10 14:28:42.116	\N	\N	\N	\N	\N
710	865	1	5	RCT-20260607-0710	6270.00	transfer	\N	3230.00	Sule Adeyemi	18	2026-04-30 12:28:42.122	\N	\N	\N	\N	\N
711	866	1	5	RCT-20260607-0711	2450.00	cash	\N	2550.00	Sule Danjuma	17	2026-06-04 10:28:42.128	\N	\N	\N	\N	\N
712	867	1	5	RCT-20260607-0712	8000.00	pos	\N	0.00	Sule Danjuma	17	2026-03-17 14:28:42.133	\N	\N	\N	\N	\N
713	869	1	5	RCT-20260607-0713	15600.00	transfer	\N	0.00	Sule Nwachukwu	20	2026-06-07 13:28:42.143	\N	\N	\N	\N	\N
714	871	1	5	RCT-20260607-0714	14100.00	pos	\N	0.00	Sule Danjuma	17	2026-05-25 15:28:42.161	\N	\N	\N	\N	\N
715	874	1	5	RCT-20260607-0715	5100.00	pos	\N	0.00	Yusuf Alabi	19	2026-04-17 09:28:42.184	\N	\N	\N	\N	\N
716	875	1	5	RCT-20260607-0716	5400.00	transfer	\N	0.00	Yusuf Alabi	19	2026-04-07 08:28:42.19	\N	\N	\N	\N	\N
717	876	1	5	RCT-20260607-0717	1364.00	pos	\N	3036.00	Sule Danjuma	17	2026-04-28 06:28:42.196	\N	\N	\N	\N	\N
718	877	1	5	RCT-20260607-0718	1116.00	cash	\N	684.00	Sule Nwachukwu	20	2026-05-10 11:28:42.21	\N	\N	\N	\N	\N
719	878	1	5	RCT-20260607-0719	16000.00	cash	\N	0.00	Sule Nwachukwu	20	2026-05-04 13:28:42.22	\N	\N	\N	\N	\N
720	879	1	5	RCT-20260607-0720	2622.00	pos	\N	1978.00	Sule Danjuma	17	2026-05-24 14:28:42.226	\N	\N	\N	\N	\N
721	881	1	5	RCT-20260607-0721	12000.00	transfer	\N	0.00	Sule Nwachukwu	20	2026-04-12 13:28:42.235	\N	\N	\N	\N	\N
722	882	1	5	RCT-20260607-0722	4500.00	pos	\N	0.00	Sule Nwachukwu	20	2026-04-12 10:28:42.246	\N	\N	\N	\N	\N
723	883	1	5	RCT-20260607-0723	1584.00	pos	\N	816.00	Sule Nwachukwu	20	2026-04-11 11:28:42.252	\N	\N	\N	\N	\N
724	884	1	5	RCT-20260607-0724	2688.00	transfer	\N	1512.00	Sule Nwachukwu	20	2026-06-06 06:28:42.257	\N	\N	\N	\N	\N
725	885	1	5	RCT-20260607-0725	1404.00	cash	\N	1296.00	Sule Adeyemi	18	2026-05-03 12:28:42.27	\N	\N	\N	\N	\N
726	886	1	5	RCT-20260607-0726	3720.00	transfer	\N	2280.00	Sule Adeyemi	18	2026-04-07 09:28:42.276	\N	\N	\N	\N	\N
727	887	1	5	RCT-20260607-0727	4200.00	pos	\N	0.00	Sule Nwachukwu	20	2026-04-11 17:28:42.282	\N	\N	\N	\N	\N
728	888	1	5	RCT-20260607-0728	10500.00	transfer	\N	0.00	Sule Adeyemi	18	2026-04-27 15:28:42.288	\N	\N	\N	\N	\N
729	889	1	5	RCT-20260607-0729	3800.00	pos	\N	0.00	Sule Adeyemi	18	2026-05-21 13:28:42.294	\N	\N	\N	\N	\N
730	890	1	5	RCT-20260607-0730	9000.00	pos	\N	0.00	Yusuf Alabi	19	2026-03-19 07:28:42.299	\N	\N	\N	\N	\N
731	891	1	5	RCT-20260607-0731	7500.00	transfer	\N	0.00	Sule Danjuma	17	2026-03-31 14:28:42.305	\N	\N	\N	\N	\N
732	892	1	5	RCT-20260607-0732	12600.00	cash	\N	0.00	Sule Nwachukwu	20	2026-03-22 06:28:42.314	\N	\N	\N	\N	\N
733	893	1	5	RCT-20260607-0733	17500.00	cash	\N	0.00	Sule Nwachukwu	20	2026-04-07 08:28:42.321	\N	\N	\N	\N	\N
734	894	1	5	RCT-20260607-0734	4900.00	pos	\N	9100.00	Sule Danjuma	17	2026-04-13 06:28:42.327	\N	\N	\N	\N	\N
735	895	1	5	RCT-20260607-0735	12000.00	cash	\N	0.00	Sule Adeyemi	18	2026-04-04 15:28:42.334	\N	\N	\N	\N	\N
736	896	1	5	RCT-20260607-0736	12000.00	transfer	\N	0.00	Sule Nwachukwu	20	2026-06-05 07:28:42.342	\N	\N	\N	\N	\N
737	898	1	5	RCT-20260607-0737	2418.00	transfer	\N	5382.00	Sule Nwachukwu	20	2026-05-29 15:28:42.352	\N	\N	\N	\N	\N
738	899	1	5	RCT-20260607-0738	8600.00	cash	\N	0.00	Yusuf Alabi	19	2026-04-25 07:28:42.36	\N	\N	\N	\N	\N
739	900	1	5	RCT-20260607-0739	8845.00	pos	\N	5655.00	Sule Nwachukwu	20	2026-05-01 06:28:42.367	\N	\N	\N	\N	\N
740	902	1	5	RCT-20260607-0740	9800.00	pos	\N	0.00	Yusuf Alabi	19	2026-05-28 13:28:42.376	\N	\N	\N	\N	\N
741	903	1	5	RCT-20260607-0741	5100.00	transfer	\N	0.00	Sule Adeyemi	18	2026-03-24 16:28:42.383	\N	\N	\N	\N	\N
742	904	1	5	RCT-20260607-0742	13500.00	cash	\N	0.00	Yusuf Alabi	19	2026-05-15 14:28:42.389	\N	\N	\N	\N	\N
743	905	1	5	RCT-20260607-0743	5664.00	pos	\N	3936.00	Sule Nwachukwu	20	2026-05-26 10:28:42.399	\N	\N	\N	\N	\N
744	906	1	5	RCT-20260607-0744	12500.00	transfer	\N	0.00	Sule Adeyemi	18	2026-05-24 15:28:42.408	\N	\N	\N	\N	\N
745	907	1	5	RCT-20260607-0745	2800.00	cash	\N	0.00	Yusuf Alabi	19	2026-05-07 13:28:42.414	\N	\N	\N	\N	\N
746	909	1	5	RCT-20260607-0746	2508.00	cash	\N	4092.00	Sule Nwachukwu	20	2026-03-17 17:28:42.424	\N	\N	\N	\N	\N
747	911	1	5	RCT-20260607-0747	14700.00	transfer	\N	0.00	Yusuf Alabi	19	2026-04-29 13:28:42.435	\N	\N	\N	\N	\N
748	912	1	5	RCT-20260607-0748	9000.00	transfer	\N	0.00	Yusuf Alabi	19	2026-03-29 08:28:42.441	\N	\N	\N	\N	\N
749	914	1	5	RCT-20260607-0749	14400.00	transfer	\N	0.00	Yusuf Alabi	19	2026-04-05 16:28:42.449	\N	\N	\N	\N	\N
750	915	1	5	RCT-20260607-0750	6400.00	cash	\N	0.00	Sule Adeyemi	18	2026-03-31 15:28:42.455	\N	\N	\N	\N	\N
751	916	1	5	RCT-20260607-0751	4400.00	cash	\N	0.00	Sule Adeyemi	18	2026-03-20 06:28:42.481	\N	\N	\N	\N	\N
752	917	1	5	RCT-20260607-0752	8700.00	cash	\N	0.00	Sule Danjuma	17	2026-03-13 14:28:42.613	\N	\N	\N	\N	\N
753	918	1	5	RCT-20260607-0753	9300.00	pos	\N	0.00	Sule Nwachukwu	20	2026-03-31 06:28:42.619	\N	\N	\N	\N	\N
754	919	1	5	RCT-20260607-0754	5400.00	pos	\N	0.00	Sule Adeyemi	18	2026-03-25 07:28:42.628	\N	\N	\N	\N	\N
755	920	1	5	RCT-20260607-0755	7800.00	pos	\N	0.00	Sule Adeyemi	18	2026-03-29 13:28:42.666	\N	\N	\N	\N	\N
756	921	1	5	RCT-20260607-0756	7200.00	transfer	\N	0.00	Sule Danjuma	17	2026-06-06 11:28:42.671	\N	\N	\N	\N	\N
757	922	1	5	RCT-20260607-0757	8700.00	pos	\N	0.00	Sule Danjuma	17	2026-03-12 09:28:42.676	\N	\N	\N	\N	\N
758	923	1	5	RCT-20260607-0758	1680.00	pos	\N	3920.00	Sule Adeyemi	18	2026-04-27 17:28:42.681	\N	\N	\N	\N	\N
759	924	1	5	RCT-20260607-0759	14500.00	pos	\N	0.00	Yusuf Alabi	19	2026-04-01 12:28:42.694	\N	\N	\N	\N	\N
760	925	1	5	RCT-20260607-0760	13500.00	cash	\N	0.00	Sule Adeyemi	18	2026-05-14 16:28:42.701	\N	\N	\N	\N	\N
761	926	1	5	RCT-20260607-0761	3000.00	pos	\N	0.00	Sule Danjuma	17	2026-04-06 16:28:42.707	\N	\N	\N	\N	\N
762	927	1	5	RCT-20260607-0762	6600.00	transfer	\N	0.00	Sule Adeyemi	18	2026-04-19 08:28:42.717	\N	\N	\N	\N	\N
763	928	1	5	RCT-20260607-0763	10500.00	pos	\N	0.00	Yusuf Alabi	19	2026-04-01 09:28:42.723	\N	\N	\N	\N	\N
764	929	1	5	RCT-20260607-0764	1742.00	pos	\N	858.00	Sule Danjuma	17	2026-04-23 10:28:42.729	\N	\N	\N	\N	\N
765	930	1	5	RCT-20260607-0765	1722.00	pos	\N	2478.00	Sule Danjuma	17	2026-05-05 15:28:42.738	\N	\N	\N	\N	\N
766	931	1	5	RCT-20260607-0766	15600.00	transfer	\N	0.00	Sule Adeyemi	18	2026-04-19 15:28:42.746	\N	\N	\N	\N	\N
767	935	1	5	RCT-20260607-0767	2772.00	cash	\N	5628.00	Sule Danjuma	17	2026-03-12 07:28:42.773	\N	\N	\N	\N	\N
768	937	1	5	RCT-20260607-0768	5800.00	pos	\N	0.00	Sule Danjuma	17	2026-05-17 07:28:42.784	\N	\N	\N	\N	\N
769	938	1	5	RCT-20260607-0769	4400.00	transfer	\N	0.00	Yusuf Alabi	19	2026-03-09 15:28:42.792	\N	\N	\N	\N	\N
770	940	1	5	RCT-20260607-0770	17000.00	cash	\N	0.00	Yusuf Alabi	19	2026-05-10 06:28:42.802	\N	\N	\N	\N	\N
771	941	1	5	RCT-20260607-0771	11500.00	cash	\N	0.00	Sule Nwachukwu	20	2026-03-20 13:28:42.807	\N	\N	\N	\N	\N
772	942	1	5	RCT-20260607-0772	3800.00	pos	\N	0.00	Yusuf Alabi	19	2026-05-21 13:28:42.813	\N	\N	\N	\N	\N
773	943	1	5	RCT-20260607-0773	11000.00	pos	\N	0.00	Sule Adeyemi	18	2026-03-25 14:28:42.818	\N	\N	\N	\N	\N
774	944	1	5	RCT-20260607-0774	4370.00	cash	\N	5130.00	Sule Adeyemi	18	2026-04-24 16:28:42.826	\N	\N	\N	\N	\N
775	945	1	5	RCT-20260607-0775	10600.00	pos	\N	0.00	Yusuf Alabi	19	2026-03-15 11:28:42.832	\N	\N	\N	\N	\N
776	948	1	5	RCT-20260607-0776	7400.00	transfer	\N	0.00	Sule Adeyemi	18	2026-05-01 15:28:42.845	\N	\N	\N	\N	\N
777	949	1	5	RCT-20260607-0777	9600.00	pos	\N	0.00	Sule Danjuma	17	2026-03-23 10:28:42.853	\N	\N	\N	\N	\N
778	950	1	5	RCT-20260607-0778	3762.00	transfer	\N	2838.00	Yusuf Alabi	19	2026-06-05 07:28:42.859	\N	\N	\N	\N	\N
\.


--
-- Data for Name: pickup_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pickup_records (id, laundry_id, order_id, shirts_picked_up, trousers_picked_up, item_pickups, notes, processed_by, recorded_by, created_at) FROM stdin;
\.


--
-- Data for Name: platform_admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_admins (id, name, email, password_hash, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: price_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_adjustments (id, order_id, laundry_id, type, amount, reason, applied_by, created_at) FROM stdin;
1	13	1	discount	837.00	Approved discount — Item delay compensation	Babajide Danjuma	2026-06-07 05:28:35.69307
2	16	1	discount	314.00	Loyal customer	Musa Nwosu	2026-06-07 05:28:35.714001
3	17	1	discount	219.00	Repeat customer	Gbenga Nwosu	2026-06-07 05:28:35.725492
4	24	1	discount	281.00	Early drop-off	Ifeoma Nwachukwu	2026-06-07 05:28:35.781847
5	28	1	discount	234.00	Early drop-off	Ifeoma Nwachukwu	2026-06-07 05:28:35.808594
6	39	1	discount	407.00	Early drop-off	Babajide Danjuma	2026-06-07 05:28:35.878851
7	45	1	discount	239.00	Early drop-off	Babajide Danjuma	2026-06-07 05:28:35.92659
8	60	1	discount	436.00	Repeat customer	Musa Nwosu	2026-06-07 05:28:36.03335
9	67	1	discount	529.00	Approved discount — Item delay compensation	Gbenga Nwosu	2026-06-07 05:28:36.085316
10	73	1	discount	498.00	Loyal customer	Babajide Danjuma	2026-06-07 05:28:36.122711
11	82	1	discount	347.00	Minor stain issue	Gbenga Nwosu	2026-06-07 05:28:36.183125
12	95	1	discount	425.00	Minor stain issue	Musa Nwosu	2026-06-07 05:28:36.276324
13	103	1	discount	202.00	Loyal customer	Babajide Danjuma	2026-06-07 05:28:36.338312
14	104	1	discount	1242.00	Approved discount — Item delay compensation	Gbenga Nwosu	2026-06-07 05:28:36.353074
15	105	1	discount	473.00	Early drop-off	Ifeoma Nwachukwu	2026-06-07 05:28:36.366518
16	124	1	discount	193.00	Loyal customer	Musa Nwosu	2026-06-07 05:28:36.496921
17	126	1	discount	658.00	Approved discount — Item delay compensation	Musa Nwosu	2026-06-07 05:28:36.518048
18	130	1	discount	179.00	Repeat customer	Babajide Danjuma	2026-06-07 05:28:36.549485
19	138	1	discount	477.00	Repeat customer	Musa Nwosu	2026-06-07 05:28:36.611043
20	145	1	discount	450.00	Early drop-off	Babajide Danjuma	2026-06-07 05:28:36.65193
21	152	1	discount	291.00	Early drop-off	Ifeoma Nwachukwu	2026-06-07 05:28:36.706749
22	156	1	discount	279.00	Loyal customer	Musa Nwosu	2026-06-07 05:28:36.741987
23	182	1	discount	1449.00	Approved discount — Customer escalation resolved	Musa Nwosu	2026-06-07 05:28:36.912423
24	189	1	discount	489.00	Loyal customer	Ifeoma Nwachukwu	2026-06-07 05:28:36.966801
25	194	1	discount	653.00	Approved discount — Customer escalation resolved	Babajide Danjuma	2026-06-07 05:28:37.008185
26	207	1	discount	252.00	Loyal customer	Ibrahim Nwosu	2026-06-07 05:28:37.164856
27	211	1	discount	439.00	Loyal customer	Ifeoma Musa	2026-06-07 05:28:37.194499
28	226	1	discount	1331.00	Approved discount — Management approval	Ibrahim Nwosu	2026-06-07 05:28:37.322406
29	235	1	discount	191.00	Loyal customer	Amaka Eze	2026-06-07 05:28:37.389494
30	236	1	discount	686.00	Approved discount — Customer escalation resolved	Amaka Eze	2026-06-07 05:28:37.403545
31	244	1	discount	410.00	Loyal customer	Amaka Eze	2026-06-07 05:28:37.453629
32	247	1	discount	972.00	Approved discount — Management approval	Amaka Eze	2026-06-07 05:28:37.480916
33	249	1	discount	620.00	Approved discount — Management approval	Amaka Eze	2026-06-07 05:28:37.498657
34	251	1	discount	270.00	Minor stain issue	Ibrahim Bello	2026-06-07 05:28:37.51972
35	252	1	discount	281.00	Minor stain issue	Amaka Eze	2026-06-07 05:28:37.532948
36	254	1	discount	1047.00	Approved discount — Item delay compensation	Amaka Eze	2026-06-07 05:28:37.554447
37	272	1	discount	944.00	Approved discount — Customer escalation resolved	Ibrahim Bello	2026-06-07 05:28:37.672132
38	296	1	discount	530.00	Approved discount — Management approval	Ibrahim Bello	2026-06-07 05:28:37.841199
39	299	1	discount	390.00	Repeat customer	Ibrahim Bello	2026-06-07 05:28:37.862901
40	300	1	discount	364.00	Loyal customer	Ibrahim Nwosu	2026-06-07 05:28:37.875948
41	308	1	discount	122.00	Loyal customer	Amaka Eze	2026-06-07 05:28:37.935995
42	323	1	discount	164.00	Loyal customer	Ibrahim Nwosu	2026-06-07 05:28:38.035822
43	326	1	discount	768.00	Approved discount — Item delay compensation	Ibrahim Nwosu	2026-06-07 05:28:38.064857
44	328	1	discount	983.00	Approved discount — Customer escalation resolved	Ibrahim Bello	2026-06-07 05:28:38.088868
45	333	1	discount	126.00	Minor stain issue	Ifeoma Musa	2026-06-07 05:28:38.136146
46	338	1	discount	320.00	Minor stain issue	Ibrahim Bello	2026-06-07 05:28:38.171833
47	339	1	discount	278.00	Minor stain issue	Ibrahim Bello	2026-06-07 05:28:38.183444
48	343	1	discount	726.00	Approved discount — Management approval	Ibrahim Bello	2026-06-07 05:28:38.211884
49	345	1	discount	884.00	Approved discount — Customer escalation resolved	Ifeoma Musa	2026-06-07 05:28:38.229828
50	368	1	discount	250.00	Repeat customer	Amaka Eze	2026-06-07 05:28:38.377346
51	371	1	discount	753.00	Approved discount — Item delay compensation	Ifeoma Musa	2026-06-07 05:28:38.406057
52	381	1	discount	1078.00	Approved discount — Management approval	Ifeoma Musa	2026-06-07 05:28:38.475865
53	382	1	discount	449.00	Minor stain issue	Ifeoma Musa	2026-06-07 05:28:38.485525
54	384	1	discount	992.00	Approved discount — Item delay compensation	Amaka Eze	2026-06-07 05:28:38.506798
55	388	1	discount	360.00	Loyal customer	Ibrahim Bello	2026-06-07 05:28:38.537158
56	396	1	discount	294.00	Loyal customer	Ibrahim Nwosu	2026-06-07 05:28:38.587257
57	397	1	discount	417.00	Loyal customer	Ifeoma Musa	2026-06-07 05:28:38.598825
58	402	1	discount	325.00	Loyal customer	Babajide Bello	2026-06-07 05:28:38.700548
59	403	1	discount	380.00	Minor stain issue	Zainab Lawal	2026-06-07 05:28:38.712251
60	409	1	discount	408.00	Early drop-off	Zainab Lawal	2026-06-07 05:28:38.748496
61	413	1	discount	1071.00	Approved discount — Customer escalation resolved	Ngozi Eze	2026-06-07 05:28:38.780633
62	415	1	discount	804.00	Approved discount — Item delay compensation	Ngozi Eze	2026-06-07 05:28:38.801618
63	417	1	discount	333.00	Repeat customer	Halima Abubakar	2026-06-07 05:28:38.818406
64	421	1	discount	459.00	Repeat customer	Ngozi Eze	2026-06-07 05:28:38.850738
65	423	1	discount	338.00	Minor stain issue	Babajide Bello	2026-06-07 05:28:38.872727
66	434	1	discount	764.00	Approved discount — Item delay compensation	Zainab Lawal	2026-06-07 05:28:38.945431
67	440	1	discount	119.00	Repeat customer	Ngozi Eze	2026-06-07 05:28:38.991644
68	442	1	discount	310.00	Repeat customer	Zainab Lawal	2026-06-07 05:28:39.00746
69	452	1	discount	845.00	Approved discount — Management approval	Halima Abubakar	2026-06-07 05:28:39.072148
70	471	1	discount	232.00	Repeat customer	Ngozi Eze	2026-06-07 05:28:39.194429
71	482	1	discount	541.00	Approved discount — Item delay compensation	Babajide Bello	2026-06-07 05:28:39.264353
72	496	1	discount	119.00	Repeat customer	Halima Abubakar	2026-06-07 05:28:39.349459
73	503	1	discount	919.00	Approved discount — Customer escalation resolved	Halima Abubakar	2026-06-07 05:28:39.405771
74	512	1	discount	597.00	Approved discount — Customer escalation resolved	Babajide Bello	2026-06-07 05:28:39.470417
75	513	1	discount	1486.00	Approved discount — Management approval	Zainab Lawal	2026-06-07 05:28:39.482893
76	516	1	discount	198.00	Minor stain issue	Ngozi Eze	2026-06-07 05:28:39.50394
77	527	1	discount	477.00	Early drop-off	Halima Abubakar	2026-06-07 05:28:39.576722
78	538	1	discount	120.00	Minor stain issue	Halima Abubakar	2026-06-07 05:28:39.641756
79	542	1	discount	1203.00	Approved discount — Customer escalation resolved	Babajide Bello	2026-06-07 05:28:39.674284
80	561	1	discount	1054.00	Approved discount — Item delay compensation	Ngozi Eze	2026-06-07 05:28:39.789784
81	576	1	discount	820.00	Approved discount — Management approval	Zainab Lawal	2026-06-07 05:28:39.887732
82	587	1	discount	1440.00	Approved discount — Customer escalation resolved	Halima Abubakar	2026-06-07 05:28:39.961741
83	588	1	discount	344.00	Early drop-off	Ngozi Eze	2026-06-07 05:28:39.972726
84	589	1	discount	449.00	Loyal customer	Halima Abubakar	2026-06-07 05:28:39.983744
85	591	1	discount	124.00	Loyal customer	Ngozi Eze	2026-06-07 05:28:39.99894
86	598	1	discount	262.00	Repeat customer	Halima Abubakar	2026-06-07 05:28:40.046598
87	601	1	discount	151.00	Minor stain issue	Gbenga Bello	2026-06-07 05:28:40.143336
88	613	1	discount	411.00	Minor stain issue	Gbenga Bello	2026-06-07 05:28:40.219482
89	616	1	discount	1317.00	Approved discount — Item delay compensation	Gbenga Bello	2026-06-07 05:28:40.246822
90	618	1	discount	922.00	Approved discount — Management approval	Olu Okonkwo	2026-06-07 05:28:40.267336
91	620	1	discount	1109.00	Approved discount — Management approval	Tobi Okafor	2026-06-07 05:28:40.285582
92	624	1	discount	377.00	Repeat customer	Olu Okonkwo	2026-06-07 05:28:40.312814
93	650	1	discount	404.00	Minor stain issue	Adaeze Babatunde	2026-06-07 05:28:40.49402
94	653	1	discount	237.00	Minor stain issue	Tobi Okafor	2026-06-07 05:28:40.52375
95	659	1	discount	255.00	Minor stain issue	Gbenga Bello	2026-06-07 05:28:40.571655
96	672	1	discount	348.00	Early drop-off	Adaeze Babatunde	2026-06-07 05:28:40.662119
97	682	1	discount	388.00	Early drop-off	Gbenga Bello	2026-06-07 05:28:40.73141
98	689	1	discount	393.00	Minor stain issue	Olu Okonkwo	2026-06-07 05:28:40.781732
99	700	1	discount	474.00	Early drop-off	Adaeze Babatunde	2026-06-07 05:28:40.858011
100	702	1	discount	393.00	Minor stain issue	Adaeze Babatunde	2026-06-07 05:28:40.876096
101	703	1	discount	103.00	Repeat customer	Adaeze Babatunde	2026-06-07 05:28:40.885547
102	705	1	discount	114.00	Minor stain issue	Gbenga Bello	2026-06-07 05:28:40.903623
103	712	1	discount	383.00	Early drop-off	Tobi Okafor	2026-06-07 05:28:40.961451
104	719	1	discount	117.00	Loyal customer	Tobi Okafor	2026-06-07 05:28:41.005812
105	724	1	discount	1471.00	Approved discount — Management approval	Tobi Okafor	2026-06-07 05:28:41.039365
106	733	1	discount	1221.00	Approved discount — Management approval	Adaeze Babatunde	2026-06-07 05:28:41.111821
107	734	1	discount	676.00	Approved discount — Customer escalation resolved	Gbenga Bello	2026-06-07 05:28:41.127199
108	743	1	discount	301.00	Minor stain issue	Adaeze Babatunde	2026-06-07 05:28:41.19228
109	744	1	discount	1048.00	Approved discount — Customer escalation resolved	Tobi Okafor	2026-06-07 05:28:41.206757
110	748	1	discount	354.00	Early drop-off	Gbenga Bello	2026-06-07 05:28:41.237018
111	752	1	discount	623.00	Approved discount — Management approval	Tobi Okafor	2026-06-07 05:28:41.271307
112	755	1	discount	484.00	Early drop-off	Gbenga Bello	2026-06-07 05:28:41.292398
113	786	1	discount	281.00	Minor stain issue	Tobi Okafor	2026-06-07 05:28:41.490571
114	793	1	discount	720.00	Approved discount — Item delay compensation	Adaeze Babatunde	2026-06-07 05:28:41.53889
115	799	1	discount	406.00	Repeat customer	Gbenga Bello	2026-06-07 05:28:41.571854
116	802	1	discount	489.00	Early drop-off	Sule Adeyemi	2026-06-07 05:28:41.661417
117	810	1	discount	1278.00	Approved discount — Customer escalation resolved	Sule Adeyemi	2026-06-07 05:28:41.716734
118	815	1	discount	543.00	Approved discount — Management approval	Sule Adeyemi	2026-06-07 05:28:41.752508
119	817	1	discount	251.00	Minor stain issue	Sule Adeyemi	2026-06-07 05:28:41.773603
120	819	1	discount	100.00	Repeat customer	Yusuf Alabi	2026-06-07 05:28:41.791031
121	823	1	discount	401.00	Loyal customer	Sule Adeyemi	2026-06-07 05:28:41.821642
122	830	1	discount	232.00	Loyal customer	Sule Danjuma	2026-06-07 05:28:41.870876
123	843	1	discount	1394.00	Approved discount — Management approval	Sule Danjuma	2026-06-07 05:28:41.95905
124	847	1	discount	306.00	Repeat customer	Yusuf Alabi	2026-06-07 05:28:41.983257
125	848	1	discount	939.00	Approved discount — Customer escalation resolved	Sule Danjuma	2026-06-07 05:28:41.997288
126	849	1	discount	403.00	Early drop-off	Sule Nwachukwu	2026-06-07 05:28:42.00839
127	856	1	discount	523.00	Approved discount — Item delay compensation	Yusuf Alabi	2026-06-07 05:28:42.064699
128	869	1	discount	144.00	Loyal customer	Sule Nwachukwu	2026-06-07 05:28:42.153372
129	871	1	discount	167.00	Early drop-off	Sule Danjuma	2026-06-07 05:28:42.168656
130	876	1	discount	1268.00	Approved discount — Customer escalation resolved	Sule Danjuma	2026-06-07 05:28:42.205708
131	881	1	discount	348.00	Early drop-off	Sule Nwachukwu	2026-06-07 05:28:42.241648
132	884	1	discount	448.00	Early drop-off	Sule Nwachukwu	2026-06-07 05:28:42.264978
133	904	1	discount	155.00	Loyal customer	Yusuf Alabi	2026-06-07 05:28:42.395764
134	923	1	discount	253.00	Minor stain issue	Sule Adeyemi	2026-06-07 05:28:42.689017
135	934	1	discount	783.00	Approved discount — Customer escalation resolved	Sule Adeyemi	2026-06-07 05:28:42.76762
\.


--
-- Data for Name: provider_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_configs (id, laundry_id, provider, config, is_active, is_verified, last_tested_at, last_test_result, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: receipt_number_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipt_number_counters (date_part, counter) FROM stdin;
\.


--
-- Data for Name: schema_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_snapshots (id, snapshot_type, triggered_by, table_count, index_count, db_size_bytes, table_list, notes, created_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, laundry_id, name, category, standard_price, express_price, premium_price, is_active, created_at, updated_at) FROM stdin;
1	1	Shirts (Wash & Iron)	clothing	800.00	1200.00	1500.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
2	1	Trousers (Wash & Iron)	clothing	1000.00	1500.00	2000.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
3	1	Suits (Full Dry Clean)	formal	4000.00	6000.00	8000.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
4	1	Dresses	clothing	1500.00	2200.00	3000.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
5	1	Bedsheets (Single)	bedding	1200.00	1800.00	2500.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
6	1	Duvet / Comforter	bedding	3500.00	5000.00	7000.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
7	1	Agbada (Full Set)	traditional	5000.00	7500.00	10000.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
8	1	Ankara Fabric (Piece)	traditional	1800.00	2500.00	3500.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
9	1	Sneakers (Pair)	footwear	2500.00	3500.00	5000.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
10	1	Leather Shoes (Pair)	footwear	2000.00	3000.00	4500.00	t	2026-06-07 05:28:34.80634	2026-06-07 05:28:34.80634
\.


--
-- Data for Name: subscription_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_logs (id, laundry_id, from_status, to_status, from_plan, to_plan, reason, changed_by, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: worker_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.worker_permissions (id, worker_id, laundry_id, can_view_customers, can_create_customers, can_view_customer_balances, can_record_payments, can_record_pickups, can_view_orders, can_process_orders, can_assign_orders, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workers (id, laundry_id, branch_id, name, phone, role, pin, is_active, created_at, updated_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name) FROM stdin;
1	1	1	Babajide Danjuma	08094864290	admin	1234	t	2026-06-07 05:28:34.820738	2026-06-07 05:28:34.820738	\N	\N	\N	\N
2	1	1	Musa Nwosu	08062401793	worker	5678	t	2026-06-07 05:28:34.824176	2026-06-07 05:28:34.824176	\N	\N	\N	\N
3	1	1	Ifeoma Nwachukwu	08066557097	worker	2222	t	2026-06-07 05:28:34.827641	2026-06-07 05:28:34.827641	\N	\N	\N	\N
4	1	1	Gbenga Nwosu	08078509133	worker	3333	t	2026-06-07 05:28:34.831472	2026-06-07 05:28:34.831472	\N	\N	\N	\N
5	1	2	Ibrahim Bello	08098265483	admin	4444	t	2026-06-07 05:28:34.835549	2026-06-07 05:28:34.835549	\N	\N	\N	\N
6	1	2	Amaka Eze	08031125304	worker	5555	t	2026-06-07 05:28:34.838875	2026-06-07 05:28:34.838875	\N	\N	\N	\N
7	1	2	Ibrahim Nwosu	08057174826	worker	6666	t	2026-06-07 05:28:34.842352	2026-06-07 05:28:34.842352	\N	\N	\N	\N
8	1	2	Ifeoma Musa	08014387402	worker	7777	t	2026-06-07 05:28:34.845555	2026-06-07 05:28:34.845555	\N	\N	\N	\N
9	1	3	Zainab Lawal	08058695441	admin	8888	t	2026-06-07 05:28:34.849816	2026-06-07 05:28:34.849816	\N	\N	\N	\N
10	1	3	Halima Abubakar	08018966384	worker	9999	t	2026-06-07 05:28:34.852784	2026-06-07 05:28:34.852784	\N	\N	\N	\N
11	1	3	Babajide Bello	08027755698	worker	1111	t	2026-06-07 05:28:34.855498	2026-06-07 05:28:34.855498	\N	\N	\N	\N
12	1	3	Ngozi Eze	08072122953	worker	2468	t	2026-06-07 05:28:34.858433	2026-06-07 05:28:34.858433	\N	\N	\N	\N
13	1	4	Olu Okonkwo	08032698716	admin	1357	t	2026-06-07 05:28:34.862003	2026-06-07 05:28:34.862003	\N	\N	\N	\N
14	1	4	Adaeze Babatunde	08011614620	worker	9876	t	2026-06-07 05:28:34.866234	2026-06-07 05:28:34.866234	\N	\N	\N	\N
15	1	4	Tobi Okafor	08087074435	worker	5432	t	2026-06-07 05:28:34.869636	2026-06-07 05:28:34.869636	\N	\N	\N	\N
16	1	4	Gbenga Bello	08095622125	worker	1122	t	2026-06-07 05:28:34.872411	2026-06-07 05:28:34.872411	\N	\N	\N	\N
17	1	5	Sule Danjuma	08073434714	admin	3344	t	2026-06-07 05:28:34.875863	2026-06-07 05:28:34.875863	\N	\N	\N	\N
18	1	5	Sule Adeyemi	08067127128	worker	5566	t	2026-06-07 05:28:34.879573	2026-06-07 05:28:34.879573	\N	\N	\N	\N
19	1	5	Yusuf Alabi	08021257292	worker	7788	t	2026-06-07 05:28:34.88279	2026-06-07 05:28:34.88279	\N	\N	\N	\N
20	1	5	Sule Nwachukwu	08022103365	worker	9900	t	2026-06-07 05:28:34.88578	2026-06-07 05:28:34.88578	\N	\N	\N	\N
\.


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_id_seq', 5, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batches_id_seq', 1, false);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branches_id_seq', 5, true);


--
-- Name: conversation_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_messages_id_seq', 1, false);


--
-- Name: conversation_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_participants_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 200, true);


--
-- Name: device_heartbeats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_heartbeats_id_seq', 8, true);


--
-- Name: discount_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discount_approvals_id_seq', 137, true);


--
-- Name: expenditures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenditures_id_seq', 120, true);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 8, true);


--
-- Name: laundries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.laundries_id_seq', 1, true);


--
-- Name: message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_templates_id_seq', 2, true);


--
-- Name: notification_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_events_id_seq', 1, false);


--
-- Name: notification_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_messages_id_seq', 1, false);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 5, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 1000, true);


--
-- Name: payment_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_records_id_seq', 820, true);


--
-- Name: pickup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pickup_records_id_seq', 1, false);


--
-- Name: platform_admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_admins_id_seq', 1, false);


--
-- Name: price_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.price_adjustments_id_seq', 139, true);


--
-- Name: provider_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.provider_configs_id_seq', 1, false);


--
-- Name: schema_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schema_snapshots_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 10, true);


--
-- Name: subscription_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_logs_id_seq', 1, false);


--
-- Name: worker_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.worker_permissions_id_seq', 1, false);


--
-- Name: workers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workers_id_seq', 20, true);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: batches batches_batch_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_batch_code_unique UNIQUE (batch_code);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: conversation_messages conversation_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_pkey PRIMARY KEY (id);


--
-- Name: conversation_participants conversation_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: device_heartbeats device_heartbeats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_pkey PRIMARY KEY (id);


--
-- Name: discount_approvals discount_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_pkey PRIMARY KEY (id);


--
-- Name: expenditures expenditures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenditures
    ADD CONSTRAINT expenditures_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (key);


--
-- Name: laundries laundries_owner_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laundries
    ADD CONSTRAINT laundries_owner_email_unique UNIQUE (owner_email);


--
-- Name: laundries laundries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laundries
    ADD CONSTRAINT laundries_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_events notification_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_pkey PRIMARY KEY (id);


--
-- Name: notification_messages notification_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_messages
    ADD CONSTRAINT notification_messages_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_id_unique UNIQUE (order_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_records payment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_pkey PRIMARY KEY (id);


--
-- Name: payment_records payment_records_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: pickup_records pickup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_pkey PRIMARY KEY (id);


--
-- Name: platform_admins platform_admins_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_admins
    ADD CONSTRAINT platform_admins_email_unique UNIQUE (email);


--
-- Name: platform_admins platform_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_admins
    ADD CONSTRAINT platform_admins_pkey PRIMARY KEY (id);


--
-- Name: price_adjustments price_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments
    ADD CONSTRAINT price_adjustments_pkey PRIMARY KEY (id);


--
-- Name: provider_configs provider_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_configs
    ADD CONSTRAINT provider_configs_pkey PRIMARY KEY (id);


--
-- Name: receipt_number_counters receipt_number_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_number_counters
    ADD CONSTRAINT receipt_number_counters_pkey PRIMARY KEY (date_part);


--
-- Name: schema_snapshots schema_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_snapshots
    ADD CONSTRAINT schema_snapshots_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: subscription_logs subscription_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_logs
    ADD CONSTRAINT subscription_logs_pkey PRIMARY KEY (id);


--
-- Name: worker_permissions worker_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_pkey PRIMARY KEY (id);


--
-- Name: worker_permissions worker_permissions_worker_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_worker_id_unique UNIQUE (worker_id);


--
-- Name: workers workers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_pkey PRIMARY KEY (id);


--
-- Name: alerts_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_category_idx ON public.alerts USING btree (category);


--
-- Name: alerts_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_idx ON public.alerts USING btree (created_at);


--
-- Name: alerts_fingerprint_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_fingerprint_idx ON public.alerts USING btree (fingerprint);


--
-- Name: alerts_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_laundry_id_idx ON public.alerts USING btree (laundry_id);


--
-- Name: alerts_severity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_severity_idx ON public.alerts USING btree (severity);


--
-- Name: alerts_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_idx ON public.alerts USING btree (status);


--
-- Name: audit_log_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_action_idx ON public.audit_log USING btree (action);


--
-- Name: audit_log_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_created_at_idx ON public.audit_log USING btree (created_at);


--
-- Name: audit_log_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_laundry_id_idx ON public.audit_log USING btree (laundry_id);


--
-- Name: audit_log_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_order_id_idx ON public.audit_log USING btree (order_id);


--
-- Name: conv_messages_conversation_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conv_messages_conversation_idx ON public.conversation_messages USING btree (conversation_id);


--
-- Name: conv_messages_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conv_messages_created_at_idx ON public.conversation_messages USING btree (created_at);


--
-- Name: conv_messages_direction_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conv_messages_direction_idx ON public.conversation_messages USING btree (direction);


--
-- Name: conv_messages_laundry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conv_messages_laundry_idx ON public.conversation_messages USING btree (laundry_id);


--
-- Name: conv_participants_conv_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conv_participants_conv_idx ON public.conversation_participants USING btree (conversation_id);


--
-- Name: conv_participants_worker_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conv_participants_worker_idx ON public.conversation_participants USING btree (worker_id);


--
-- Name: conversations_assigned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_assigned_idx ON public.conversations USING btree (assigned_worker_id);


--
-- Name: conversations_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_customer_id_idx ON public.conversations USING btree (customer_id);


--
-- Name: conversations_last_msg_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_last_msg_idx ON public.conversations USING btree (last_message_at);


--
-- Name: conversations_laundry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_laundry_idx ON public.conversations USING btree (laundry_id);


--
-- Name: conversations_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_phone_idx ON public.conversations USING btree (customer_phone);


--
-- Name: conversations_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_status_idx ON public.conversations USING btree (status);


--
-- Name: customers_branch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_branch_id_idx ON public.customers USING btree (branch_id);


--
-- Name: customers_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_deleted_at_idx ON public.customers USING btree (deleted_at);


--
-- Name: customers_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_laundry_id_idx ON public.customers USING btree (laundry_id);


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: device_heartbeats_laundry_device_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX device_heartbeats_laundry_device_uniq ON public.device_heartbeats USING btree (laundry_id, device_id);


--
-- Name: expenditures_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenditures_created_at_idx ON public.expenditures USING btree (created_at);


--
-- Name: expenditures_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenditures_laundry_id_idx ON public.expenditures USING btree (laundry_id);


--
-- Name: idempotency_keys_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_keys_created_at_idx ON public.idempotency_keys USING btree (created_at);


--
-- Name: notif_events_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_events_created_at_idx ON public.notification_events USING btree (created_at);


--
-- Name: notif_events_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_events_customer_id_idx ON public.notification_events USING btree (customer_id);


--
-- Name: notif_events_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_events_event_type_idx ON public.notification_events USING btree (event_type);


--
-- Name: notif_events_laundry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_events_laundry_idx ON public.notification_events USING btree (laundry_id);


--
-- Name: notif_events_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_events_order_id_idx ON public.notification_events USING btree (order_id);


--
-- Name: notif_events_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_events_status_idx ON public.notification_events USING btree (status);


--
-- Name: notif_messages_channel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_channel_idx ON public.notification_messages USING btree (channel);


--
-- Name: notif_messages_event_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_event_id_idx ON public.notification_messages USING btree (event_id);


--
-- Name: notif_messages_laundry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_laundry_idx ON public.notification_messages USING btree (laundry_id);


--
-- Name: notif_messages_provider_msg_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_provider_msg_id_idx ON public.notification_messages USING btree (provider_message_id);


--
-- Name: notif_messages_queued_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_queued_at_idx ON public.notification_messages USING btree (queued_at);


--
-- Name: notif_messages_recipient_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_recipient_idx ON public.notification_messages USING btree (recipient_phone);


--
-- Name: notif_messages_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_status_idx ON public.notification_messages USING btree (status);


--
-- Name: notif_messages_template_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_messages_template_id_idx ON public.notification_messages USING btree (template_id);


--
-- Name: notif_templates_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_templates_active_idx ON public.notification_templates USING btree (is_active);


--
-- Name: notif_templates_channel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_templates_channel_idx ON public.notification_templates USING btree (channel);


--
-- Name: notif_templates_laundry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_templates_laundry_idx ON public.notification_templates USING btree (laundry_id);


--
-- Name: notif_templates_trigger_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notif_templates_trigger_idx ON public.notification_templates USING btree (event_trigger);


--
-- Name: orders_branch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_branch_id_idx ON public.orders USING btree (branch_id);


--
-- Name: orders_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_created_at_idx ON public.orders USING btree (created_at);


--
-- Name: orders_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_customer_id_idx ON public.orders USING btree (customer_id);


--
-- Name: orders_laundry_branch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_laundry_branch_idx ON public.orders USING btree (laundry_id, branch_id);


--
-- Name: orders_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_laundry_id_idx ON public.orders USING btree (laundry_id);


--
-- Name: orders_laundry_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_laundry_status_idx ON public.orders USING btree (laundry_id, status);


--
-- Name: orders_payment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_payment_status_idx ON public.orders USING btree (payment_status);


--
-- Name: orders_processing_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_processing_due_idx ON public.orders USING btree (processing_due_at);


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: payment_records_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_deleted_at_idx ON public.payment_records USING btree (deleted_at);


--
-- Name: payment_records_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_laundry_id_idx ON public.payment_records USING btree (laundry_id);


--
-- Name: payment_records_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_order_id_idx ON public.payment_records USING btree (order_id);


--
-- Name: payment_records_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_recorded_at_idx ON public.payment_records USING btree (recorded_at);


--
-- Name: pickup_records_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pickup_records_laundry_id_idx ON public.pickup_records USING btree (laundry_id);


--
-- Name: pickup_records_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pickup_records_order_id_idx ON public.pickup_records USING btree (order_id);


--
-- Name: provider_configs_laundry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX provider_configs_laundry_idx ON public.provider_configs USING btree (laundry_id);


--
-- Name: provider_configs_laundry_provider_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX provider_configs_laundry_provider_uidx ON public.provider_configs USING btree (laundry_id, provider);


--
-- Name: sub_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sub_logs_created_at_idx ON public.subscription_logs USING btree (created_at);


--
-- Name: sub_logs_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sub_logs_laundry_id_idx ON public.subscription_logs USING btree (laundry_id);


--
-- Name: workers_branch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_branch_id_idx ON public.workers USING btree (branch_id);


--
-- Name: workers_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_deleted_at_idx ON public.workers USING btree (deleted_at);


--
-- Name: workers_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_laundry_id_idx ON public.workers USING btree (laundry_id);


--
-- Name: workers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_phone_idx ON public.workers USING btree (phone);


--
-- Name: alerts alerts_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: batches batches_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: branches branches_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: conversation_messages conversation_messages_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_messages conversation_messages_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_assigned_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_assigned_worker_id_workers_id_fk FOREIGN KEY (assigned_worker_id) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: customers customers_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: customers customers_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: device_heartbeats device_heartbeats_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: device_heartbeats device_heartbeats_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: device_heartbeats device_heartbeats_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: discount_approvals discount_approvals_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: discount_approvals discount_approvals_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: discount_approvals discount_approvals_requested_by_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_requested_by_workers_id_fk FOREIGN KEY (requested_by) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: expenditures expenditures_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenditures
    ADD CONSTRAINT expenditures_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: expense_categories expense_categories_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: message_templates message_templates_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: notification_events notification_events_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: notification_events notification_events_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: notification_events notification_events_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: notification_events notification_events_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_events
    ADD CONSTRAINT notification_events_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: notification_messages notification_messages_event_id_notification_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_messages
    ADD CONSTRAINT notification_messages_event_id_notification_events_id_fk FOREIGN KEY (event_id) REFERENCES public.notification_events(id) ON DELETE SET NULL;


--
-- Name: notification_messages notification_messages_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_messages
    ADD CONSTRAINT notification_messages_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: notification_messages notification_messages_template_id_notification_templates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_messages
    ADD CONSTRAINT notification_messages_template_id_notification_templates_id_fk FOREIGN KEY (template_id) REFERENCES public.notification_templates(id) ON DELETE SET NULL;


--
-- Name: notification_templates notification_templates_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: notification_templates notification_templates_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_service_id_services_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_service_id_services_id_fk FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: orders orders_assigned_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_assigned_worker_id_workers_id_fk FOREIGN KEY (assigned_worker_id) REFERENCES public.workers(id);


--
-- Name: orders orders_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- Name: orders orders_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: orders orders_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: orders orders_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: payment_records payment_records_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: pickup_records pickup_records_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: pickup_records pickup_records_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: pickup_records pickup_records_processed_by_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_processed_by_workers_id_fk FOREIGN KEY (processed_by) REFERENCES public.workers(id);


--
-- Name: price_adjustments price_adjustments_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments
    ADD CONSTRAINT price_adjustments_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: price_adjustments price_adjustments_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments
    ADD CONSTRAINT price_adjustments_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: provider_configs provider_configs_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_configs
    ADD CONSTRAINT provider_configs_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: services services_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: subscription_logs subscription_logs_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_logs
    ADD CONSTRAINT subscription_logs_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: worker_permissions worker_permissions_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: worker_permissions worker_permissions_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE CASCADE;


--
-- Name: workers workers_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: workers workers_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

