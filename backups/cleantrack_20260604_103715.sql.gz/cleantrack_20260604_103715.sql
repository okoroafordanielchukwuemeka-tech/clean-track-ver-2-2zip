--
-- PostgreSQL database dump
--

\restrict b40cXwIp5nNvsyguvBJVVje5Hw1dKTRn5eHoSZ68kZXUqXyj0Qq4IurpdmAMDOW

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workers DROP CONSTRAINT IF EXISTS workers_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.workers DROP CONSTRAINT IF EXISTS workers_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.price_adjustments DROP CONSTRAINT IF EXISTS price_adjustments_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.price_adjustments DROP CONSTRAINT IF EXISTS price_adjustments_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_processed_by_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_customer_id_customers_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_batch_id_batches_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_assigned_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_service_id_services_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.expense_categories DROP CONSTRAINT IF EXISTS expense_categories_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.expenditures DROP CONSTRAINT IF EXISTS expenditures_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_requested_by_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_worker_id_workers_id_fk;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_laundry_id_laundries_id_fk;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_laundry_id_laundries_id_fk;
DROP INDEX IF EXISTS public.workers_phone_idx;
DROP INDEX IF EXISTS public.workers_laundry_id_idx;
DROP INDEX IF EXISTS public.workers_deleted_at_idx;
DROP INDEX IF EXISTS public.workers_branch_id_idx;
DROP INDEX IF EXISTS public.pickup_records_order_id_idx;
DROP INDEX IF EXISTS public.pickup_records_laundry_id_idx;
DROP INDEX IF EXISTS public.payment_records_recorded_at_idx;
DROP INDEX IF EXISTS public.payment_records_order_id_idx;
DROP INDEX IF EXISTS public.payment_records_laundry_id_idx;
DROP INDEX IF EXISTS public.payment_records_deleted_at_idx;
DROP INDEX IF EXISTS public.orders_status_idx;
DROP INDEX IF EXISTS public.orders_processing_due_idx;
DROP INDEX IF EXISTS public.orders_payment_status_idx;
DROP INDEX IF EXISTS public.orders_laundry_status_idx;
DROP INDEX IF EXISTS public.orders_laundry_id_idx;
DROP INDEX IF EXISTS public.orders_laundry_branch_idx;
DROP INDEX IF EXISTS public.orders_customer_id_idx;
DROP INDEX IF EXISTS public.orders_created_at_idx;
DROP INDEX IF EXISTS public.orders_branch_id_idx;
DROP INDEX IF EXISTS public.idempotency_keys_created_at_idx;
DROP INDEX IF EXISTS public.expenditures_laundry_id_idx;
DROP INDEX IF EXISTS public.expenditures_created_at_idx;
DROP INDEX IF EXISTS public.device_heartbeats_laundry_device_uniq;
DROP INDEX IF EXISTS public.customers_phone_idx;
DROP INDEX IF EXISTS public.customers_laundry_id_idx;
DROP INDEX IF EXISTS public.customers_deleted_at_idx;
DROP INDEX IF EXISTS public.customers_branch_id_idx;
DROP INDEX IF EXISTS public.audit_log_order_id_idx;
DROP INDEX IF EXISTS public.audit_log_laundry_id_idx;
DROP INDEX IF EXISTS public.audit_log_created_at_idx;
DROP INDEX IF EXISTS public.audit_log_action_idx;
ALTER TABLE IF EXISTS ONLY public.workers DROP CONSTRAINT IF EXISTS workers_pkey;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_worker_id_unique;
ALTER TABLE IF EXISTS ONLY public.worker_permissions DROP CONSTRAINT IF EXISTS worker_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_pkey;
ALTER TABLE IF EXISTS ONLY public.receipt_number_counters DROP CONSTRAINT IF EXISTS receipt_number_counters_pkey;
ALTER TABLE IF EXISTS ONLY public.price_adjustments DROP CONSTRAINT IF EXISTS price_adjustments_pkey;
ALTER TABLE IF EXISTS ONLY public.pickup_records DROP CONSTRAINT IF EXISTS pickup_records_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_receipt_number_unique;
ALTER TABLE IF EXISTS ONLY public.payment_records DROP CONSTRAINT IF EXISTS payment_records_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_order_id_unique;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.message_templates DROP CONSTRAINT IF EXISTS message_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.laundries DROP CONSTRAINT IF EXISTS laundries_pkey;
ALTER TABLE IF EXISTS ONLY public.laundries DROP CONSTRAINT IF EXISTS laundries_owner_email_unique;
ALTER TABLE IF EXISTS ONLY public.idempotency_keys DROP CONSTRAINT IF EXISTS idempotency_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.expense_categories DROP CONSTRAINT IF EXISTS expense_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.expenditures DROP CONSTRAINT IF EXISTS expenditures_pkey;
ALTER TABLE IF EXISTS ONLY public.discount_approvals DROP CONSTRAINT IF EXISTS discount_approvals_pkey;
ALTER TABLE IF EXISTS ONLY public.device_heartbeats DROP CONSTRAINT IF EXISTS device_heartbeats_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_pkey;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_pkey;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_batch_code_unique;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS public.workers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.worker_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.services ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.price_adjustments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pickup_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payment_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.order_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.message_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.laundries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expense_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expenditures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.discount_approvals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.device_heartbeats ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.branches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.batches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.workers_id_seq;
DROP TABLE IF EXISTS public.workers;
DROP SEQUENCE IF EXISTS public.worker_permissions_id_seq;
DROP TABLE IF EXISTS public.worker_permissions;
DROP SEQUENCE IF EXISTS public.services_id_seq;
DROP TABLE IF EXISTS public.services;
DROP TABLE IF EXISTS public.receipt_number_counters;
DROP SEQUENCE IF EXISTS public.price_adjustments_id_seq;
DROP TABLE IF EXISTS public.price_adjustments;
DROP SEQUENCE IF EXISTS public.pickup_records_id_seq;
DROP TABLE IF EXISTS public.pickup_records;
DROP SEQUENCE IF EXISTS public.payment_records_id_seq;
DROP TABLE IF EXISTS public.payment_records;
DROP SEQUENCE IF EXISTS public.orders_id_seq;
DROP TABLE IF EXISTS public.orders;
DROP SEQUENCE IF EXISTS public.order_items_id_seq;
DROP TABLE IF EXISTS public.order_items;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.message_templates_id_seq;
DROP TABLE IF EXISTS public.message_templates;
DROP SEQUENCE IF EXISTS public.laundries_id_seq;
DROP TABLE IF EXISTS public.laundries;
DROP TABLE IF EXISTS public.idempotency_keys;
DROP SEQUENCE IF EXISTS public.expense_categories_id_seq;
DROP TABLE IF EXISTS public.expense_categories;
DROP SEQUENCE IF EXISTS public.expenditures_id_seq;
DROP TABLE IF EXISTS public.expenditures;
DROP SEQUENCE IF EXISTS public.discount_approvals_id_seq;
DROP TABLE IF EXISTS public.discount_approvals;
DROP SEQUENCE IF EXISTS public.device_heartbeats_id_seq;
DROP TABLE IF EXISTS public.device_heartbeats;
DROP SEQUENCE IF EXISTS public.customers_id_seq;
DROP TABLE IF EXISTS public.customers;
DROP SEQUENCE IF EXISTS public.branches_id_seq;
DROP TABLE IF EXISTS public.branches;
DROP SEQUENCE IF EXISTS public.batches_id_seq;
DROP TABLE IF EXISTS public.batches;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    laundry_id integer,
    actor_id integer,
    actor_type text NOT NULL,
    actor_name text NOT NULL,
    action text NOT NULL,
    order_id integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batches (
    id integer NOT NULL,
    laundry_id integer,
    batch_code text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    order_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batches_id_seq OWNED BY public.batches.id;


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    name text NOT NULL,
    address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text
);


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    full_name text NOT NULL,
    phone text NOT NULL,
    address text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: device_heartbeats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_heartbeats (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    branch_id integer,
    worker_id integer,
    actor_type text DEFAULT 'worker'::text NOT NULL,
    worker_name text,
    device_id text NOT NULL,
    pending_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    conflict_count integer DEFAULT 0 NOT NULL,
    recovery_count integer DEFAULT 0 NOT NULL,
    is_online boolean DEFAULT true NOT NULL,
    app_version text,
    last_synced_at timestamp without time zone,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: device_heartbeats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_heartbeats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_heartbeats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_heartbeats_id_seq OWNED BY public.device_heartbeats.id;


--
-- Name: discount_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discount_approvals (
    id integer NOT NULL,
    laundry_id integer,
    order_id integer NOT NULL,
    requested_by integer,
    requested_by_name text NOT NULL,
    original_amount numeric(10,2) NOT NULL,
    requested_discount numeric(10,2) NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    resolved_by text,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: discount_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.discount_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: discount_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.discount_approvals_id_seq OWNED BY public.discount_approvals.id;


--
-- Name: expenditures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenditures (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    category text NOT NULL,
    amount numeric(12,2) NOT NULL,
    notes text,
    is_recurring boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expenditures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenditures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenditures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenditures_id_seq OWNED BY public.expenditures.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    key text NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    status_code integer DEFAULT 0 NOT NULL,
    response_body text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: laundries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.laundries (
    id integer NOT NULL,
    business_name text NOT NULL,
    owner_email text NOT NULL,
    password_hash text NOT NULL,
    phone text,
    is_active boolean DEFAULT true NOT NULL,
    subscription_tier text DEFAULT 'free'::text NOT NULL,
    standard_turnaround_hours integer DEFAULT 72 NOT NULL,
    express_turnaround_hours integer DEFAULT 24 NOT NULL,
    premium_turnaround_hours integer DEFAULT 48 NOT NULL,
    business_profile jsonb DEFAULT '{}'::jsonb,
    branding_settings jsonb DEFAULT '{}'::jsonb,
    operational_settings jsonb DEFAULT '{}'::jsonb,
    automation_settings jsonb DEFAULT '{}'::jsonb,
    dashboard_preferences jsonb DEFAULT '{}'::jsonb,
    discount_settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: laundries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.laundries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: laundries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.laundries_id_seq OWNED BY public.laundries.id;


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_templates (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    name text NOT NULL,
    subject text,
    body text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_templates_id_seq OWNED BY public.message_templates.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    laundry_id integer NOT NULL,
    target_type text DEFAULT 'owner'::text NOT NULL,
    target_worker_id integer,
    event_type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    related_order_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    service_id integer,
    service_type text NOT NULL,
    name text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    quantity_picked_up integer DEFAULT 0 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    customer_id integer,
    order_id text NOT NULL,
    customer_name text NOT NULL,
    phone text NOT NULL,
    address text,
    service_type text DEFAULT 'standard'::text NOT NULL,
    shirts integer DEFAULT 0 NOT NULL,
    trousers integer DEFAULT 0 NOT NULL,
    shirts_picked_up integer DEFAULT 0 NOT NULL,
    trousers_picked_up integer DEFAULT 0 NOT NULL,
    additional_notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_status text DEFAULT 'unpaid'::text NOT NULL,
    price numeric(10,2),
    extra_charge numeric(10,2),
    discount numeric(10,2),
    amount_paid numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    verified_shirts integer,
    verified_trousers integer,
    is_verified boolean DEFAULT false NOT NULL,
    batch_id integer,
    assigned_worker_id integer,
    processing_due_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_records (
    id integer NOT NULL,
    order_id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    receipt_number text,
    amount numeric(10,2) NOT NULL,
    method text DEFAULT 'cash'::text NOT NULL,
    notes text,
    remaining_balance numeric(10,2) NOT NULL,
    recorded_by text,
    worker_id integer,
    recorded_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text,
    deletion_reason text
);


--
-- Name: payment_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_records_id_seq OWNED BY public.payment_records.id;


--
-- Name: pickup_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pickup_records (
    id integer NOT NULL,
    laundry_id integer,
    order_id integer NOT NULL,
    shirts_picked_up integer DEFAULT 0 NOT NULL,
    trousers_picked_up integer DEFAULT 0 NOT NULL,
    item_pickups json,
    notes text,
    processed_by integer,
    recorded_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: pickup_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pickup_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pickup_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pickup_records_id_seq OWNED BY public.pickup_records.id;


--
-- Name: price_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_adjustments (
    id integer NOT NULL,
    order_id integer NOT NULL,
    laundry_id integer,
    type text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text NOT NULL,
    applied_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: price_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.price_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: price_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.price_adjustments_id_seq OWNED BY public.price_adjustments.id;


--
-- Name: receipt_number_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_number_counters (
    date_part text NOT NULL,
    counter integer DEFAULT 0 NOT NULL
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    laundry_id integer,
    name text NOT NULL,
    category text NOT NULL,
    standard_price numeric(10,2) NOT NULL,
    express_price numeric(10,2),
    premium_price numeric(10,2),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: worker_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worker_permissions (
    id integer NOT NULL,
    worker_id integer NOT NULL,
    laundry_id integer NOT NULL,
    can_view_customers boolean DEFAULT true NOT NULL,
    can_create_customers boolean DEFAULT false NOT NULL,
    can_view_customer_balances boolean DEFAULT false NOT NULL,
    can_record_payments boolean DEFAULT false NOT NULL,
    can_record_pickups boolean DEFAULT true NOT NULL,
    can_view_orders boolean DEFAULT true NOT NULL,
    can_process_orders boolean DEFAULT true NOT NULL,
    can_assign_orders boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: worker_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.worker_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: worker_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.worker_permissions_id_seq OWNED BY public.worker_permissions.id;


--
-- Name: workers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workers (
    id integer NOT NULL,
    laundry_id integer,
    branch_id integer,
    name text NOT NULL,
    phone text,
    role text DEFAULT 'worker'::text NOT NULL,
    pin text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by_id integer,
    deleted_by_type text,
    deleted_by_name text
);


--
-- Name: workers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workers_id_seq OWNED BY public.workers.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches ALTER COLUMN id SET DEFAULT nextval('public.batches_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: device_heartbeats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats ALTER COLUMN id SET DEFAULT nextval('public.device_heartbeats_id_seq'::regclass);


--
-- Name: discount_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals ALTER COLUMN id SET DEFAULT nextval('public.discount_approvals_id_seq'::regclass);


--
-- Name: expenditures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenditures ALTER COLUMN id SET DEFAULT nextval('public.expenditures_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: laundries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laundries ALTER COLUMN id SET DEFAULT nextval('public.laundries_id_seq'::regclass);


--
-- Name: message_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates ALTER COLUMN id SET DEFAULT nextval('public.message_templates_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payment_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records ALTER COLUMN id SET DEFAULT nextval('public.payment_records_id_seq'::regclass);


--
-- Name: pickup_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records ALTER COLUMN id SET DEFAULT nextval('public.pickup_records_id_seq'::regclass);


--
-- Name: price_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments ALTER COLUMN id SET DEFAULT nextval('public.price_adjustments_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: worker_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions ALTER COLUMN id SET DEFAULT nextval('public.worker_permissions_id_seq'::regclass);


--
-- Name: workers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers ALTER COLUMN id SET DEFAULT nextval('public.workers_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, laundry_id, actor_id, actor_type, actor_name, action, order_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batches (id, laundry_id, batch_code, status, order_count, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, laundry_id, name, address, created_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, laundry_id, branch_id, full_name, phone, address, notes, created_at, last_activity_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name) FROM stdin;
\.


--
-- Data for Name: device_heartbeats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_heartbeats (id, laundry_id, branch_id, worker_id, actor_type, worker_name, device_id, pending_count, failed_count, conflict_count, recovery_count, is_online, app_version, last_synced_at, last_seen_at, created_at) FROM stdin;
\.


--
-- Data for Name: discount_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_approvals (id, laundry_id, order_id, requested_by, requested_by_name, original_amount, requested_discount, reason, status, resolved_by, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: expenditures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenditures (id, laundry_id, category, amount, notes, is_recurring, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, laundry_id, name, is_default, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idempotency_keys (key, status, status_code, response_body, created_at) FROM stdin;
\.


--
-- Data for Name: laundries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.laundries (id, business_name, owner_email, password_hash, phone, is_active, subscription_tier, standard_turnaround_hours, express_turnaround_hours, premium_turnaround_hours, business_profile, branding_settings, operational_settings, automation_settings, dashboard_preferences, discount_settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_templates (id, laundry_id, name, subject, body, is_default, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, laundry_id, target_type, target_worker_id, event_type, title, message, severity, is_read, related_order_id, created_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, service_id, service_type, name, quantity, quantity_picked_up, unit_price, total_price, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, laundry_id, branch_id, customer_id, order_id, customer_name, phone, address, service_type, shirts, trousers, shirts_picked_up, trousers_picked_up, additional_notes, status, payment_status, price, extra_charge, discount, amount_paid, verified_shirts, verified_trousers, is_verified, batch_id, assigned_worker_id, processing_due_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_records (id, order_id, laundry_id, branch_id, receipt_number, amount, method, notes, remaining_balance, recorded_by, worker_id, recorded_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name, deletion_reason) FROM stdin;
\.


--
-- Data for Name: pickup_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pickup_records (id, laundry_id, order_id, shirts_picked_up, trousers_picked_up, item_pickups, notes, processed_by, recorded_by, created_at) FROM stdin;
\.


--
-- Data for Name: price_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_adjustments (id, order_id, laundry_id, type, amount, reason, applied_by, created_at) FROM stdin;
\.


--
-- Data for Name: receipt_number_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipt_number_counters (date_part, counter) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, laundry_id, name, category, standard_price, express_price, premium_price, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: worker_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.worker_permissions (id, worker_id, laundry_id, can_view_customers, can_create_customers, can_view_customer_balances, can_record_payments, can_record_pickups, can_view_orders, can_process_orders, can_assign_orders, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workers (id, laundry_id, branch_id, name, phone, role, pin, is_active, created_at, updated_at, deleted_at, deleted_by_id, deleted_by_type, deleted_by_name) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batches_id_seq', 1, false);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branches_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: device_heartbeats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_heartbeats_id_seq', 1, false);


--
-- Name: discount_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discount_approvals_id_seq', 1, false);


--
-- Name: expenditures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenditures_id_seq', 1, false);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 1, false);


--
-- Name: laundries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.laundries_id_seq', 1, false);


--
-- Name: message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_templates_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: payment_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_records_id_seq', 1, false);


--
-- Name: pickup_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pickup_records_id_seq', 1, false);


--
-- Name: price_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.price_adjustments_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 1, false);


--
-- Name: worker_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.worker_permissions_id_seq', 1, false);


--
-- Name: workers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workers_id_seq', 1, false);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: batches batches_batch_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_batch_code_unique UNIQUE (batch_code);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: device_heartbeats device_heartbeats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_pkey PRIMARY KEY (id);


--
-- Name: discount_approvals discount_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_pkey PRIMARY KEY (id);


--
-- Name: expenditures expenditures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenditures
    ADD CONSTRAINT expenditures_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (key);


--
-- Name: laundries laundries_owner_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laundries
    ADD CONSTRAINT laundries_owner_email_unique UNIQUE (owner_email);


--
-- Name: laundries laundries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.laundries
    ADD CONSTRAINT laundries_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_id_unique UNIQUE (order_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_records payment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_pkey PRIMARY KEY (id);


--
-- Name: payment_records payment_records_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: pickup_records pickup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_pkey PRIMARY KEY (id);


--
-- Name: price_adjustments price_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments
    ADD CONSTRAINT price_adjustments_pkey PRIMARY KEY (id);


--
-- Name: receipt_number_counters receipt_number_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_number_counters
    ADD CONSTRAINT receipt_number_counters_pkey PRIMARY KEY (date_part);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: worker_permissions worker_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_pkey PRIMARY KEY (id);


--
-- Name: worker_permissions worker_permissions_worker_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_worker_id_unique UNIQUE (worker_id);


--
-- Name: workers workers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_pkey PRIMARY KEY (id);


--
-- Name: audit_log_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_action_idx ON public.audit_log USING btree (action);


--
-- Name: audit_log_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_created_at_idx ON public.audit_log USING btree (created_at);


--
-- Name: audit_log_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_laundry_id_idx ON public.audit_log USING btree (laundry_id);


--
-- Name: audit_log_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_order_id_idx ON public.audit_log USING btree (order_id);


--
-- Name: customers_branch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_branch_id_idx ON public.customers USING btree (branch_id);


--
-- Name: customers_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_deleted_at_idx ON public.customers USING btree (deleted_at);


--
-- Name: customers_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_laundry_id_idx ON public.customers USING btree (laundry_id);


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: device_heartbeats_laundry_device_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX device_heartbeats_laundry_device_uniq ON public.device_heartbeats USING btree (laundry_id, device_id);


--
-- Name: expenditures_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenditures_created_at_idx ON public.expenditures USING btree (created_at);


--
-- Name: expenditures_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenditures_laundry_id_idx ON public.expenditures USING btree (laundry_id);


--
-- Name: idempotency_keys_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_keys_created_at_idx ON public.idempotency_keys USING btree (created_at);


--
-- Name: orders_branch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_branch_id_idx ON public.orders USING btree (branch_id);


--
-- Name: orders_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_created_at_idx ON public.orders USING btree (created_at);


--
-- Name: orders_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_customer_id_idx ON public.orders USING btree (customer_id);


--
-- Name: orders_laundry_branch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_laundry_branch_idx ON public.orders USING btree (laundry_id, branch_id);


--
-- Name: orders_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_laundry_id_idx ON public.orders USING btree (laundry_id);


--
-- Name: orders_laundry_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_laundry_status_idx ON public.orders USING btree (laundry_id, status);


--
-- Name: orders_payment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_payment_status_idx ON public.orders USING btree (payment_status);


--
-- Name: orders_processing_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_processing_due_idx ON public.orders USING btree (processing_due_at);


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: payment_records_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_deleted_at_idx ON public.payment_records USING btree (deleted_at);


--
-- Name: payment_records_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_laundry_id_idx ON public.payment_records USING btree (laundry_id);


--
-- Name: payment_records_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_order_id_idx ON public.payment_records USING btree (order_id);


--
-- Name: payment_records_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_records_recorded_at_idx ON public.payment_records USING btree (recorded_at);


--
-- Name: pickup_records_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pickup_records_laundry_id_idx ON public.pickup_records USING btree (laundry_id);


--
-- Name: pickup_records_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pickup_records_order_id_idx ON public.pickup_records USING btree (order_id);


--
-- Name: workers_branch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_branch_id_idx ON public.workers USING btree (branch_id);


--
-- Name: workers_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_deleted_at_idx ON public.workers USING btree (deleted_at);


--
-- Name: workers_laundry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_laundry_id_idx ON public.workers USING btree (laundry_id);


--
-- Name: workers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workers_phone_idx ON public.workers USING btree (phone);


--
-- Name: audit_log audit_log_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: batches batches_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: branches branches_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: customers customers_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: customers customers_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: device_heartbeats device_heartbeats_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: device_heartbeats device_heartbeats_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: device_heartbeats device_heartbeats_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_heartbeats
    ADD CONSTRAINT device_heartbeats_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: discount_approvals discount_approvals_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: discount_approvals discount_approvals_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: discount_approvals discount_approvals_requested_by_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_approvals
    ADD CONSTRAINT discount_approvals_requested_by_workers_id_fk FOREIGN KEY (requested_by) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: expenditures expenditures_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenditures
    ADD CONSTRAINT expenditures_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: expense_categories expense_categories_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: message_templates message_templates_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_service_id_services_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_service_id_services_id_fk FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: orders orders_assigned_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_assigned_worker_id_workers_id_fk FOREIGN KEY (assigned_worker_id) REFERENCES public.workers(id);


--
-- Name: orders orders_batch_id_batches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_batch_id_batches_id_fk FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- Name: orders orders_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: orders orders_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: orders orders_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: payment_records payment_records_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: payment_records payment_records_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_records
    ADD CONSTRAINT payment_records_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE SET NULL;


--
-- Name: pickup_records pickup_records_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: pickup_records pickup_records_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: pickup_records pickup_records_processed_by_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pickup_records
    ADD CONSTRAINT pickup_records_processed_by_workers_id_fk FOREIGN KEY (processed_by) REFERENCES public.workers(id);


--
-- Name: price_adjustments price_adjustments_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments
    ADD CONSTRAINT price_adjustments_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: price_adjustments price_adjustments_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_adjustments
    ADD CONSTRAINT price_adjustments_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: services services_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: worker_permissions worker_permissions_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- Name: worker_permissions worker_permissions_worker_id_workers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_permissions
    ADD CONSTRAINT worker_permissions_worker_id_workers_id_fk FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE CASCADE;


--
-- Name: workers workers_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: workers workers_laundry_id_laundries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_laundry_id_laundries_id_fk FOREIGN KEY (laundry_id) REFERENCES public.laundries(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict b40cXwIp5nNvsyguvBJVVje5Hw1dKTRn5eHoSZ68kZXUqXyj0Qq4IurpdmAMDOW

